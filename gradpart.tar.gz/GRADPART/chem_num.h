

#ifndef CHEM_NUM_H

#include "typedefs.h"
#include "chem.h"
#include "mbf.h"
#include "can_num.h"
#include "bitvec.h"

class CHEM_NUM : public CAN_NUM
{
 protected:
  VEKTOR < short >   typ_nr;
  //Typnummern der Atome

 public:
                     CHEM_NUM();
                     CHEM_NUM(int _dim);
  void               Init(int _dim);
  void               FREE();
  void               Init(Molecule& molecule);
  void               SetMAX_VAL(int m) { MAX_VAL = m; }

  USHORT             GetNumber(USHORT a)
                      { return(loes[a]); } 
};


#define CHEM_NUM_H
#endif



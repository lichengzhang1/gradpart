#include "orddnk.h"
#include "defs.h"


ORDDNK::ORDDNK() : ORDTREU_SP_Z_SUMS()
{ return; }


ORDDNK::~ORDDNK()
{ return; }


void ORDDNK::Init(KOORD_BASE *_VATER)
{
 int i,j;

 s = young_part.Used()-1;
 if(s == 0)
  {
   if(! GROUP_IS_ID)
    {
     OP_AUT.Init(OP_G.Dim());
     OP_AUT=OP_G;
     AUT_IS_ID=0;
    }
   else
     AUT_IS_ID=1;
   IS_FIRST=1;
   VATER=_VATER;
   return;
  }

 Anz()=0;
 for(i=1;i <= s;i++)
  Anz()+=young_part[i];

 GetIS_NULL_REP()=0; 
 SetROWWISE_NUMBERING();

 if(! GROUP_IS_ID)
  {
   OP_AUT.Init(OP_G.Dim());
   G.Init(s+OP_G.Dim());
   AUT.Init(s+OP_G.Dim());
   LABRA_TG D(s);
   G.DirProd(OP_G,D); 
  }

 ORDTREU_SP_Z_SUMS::Init(_VATER);

 for(i=1;i<=s;i++)
  s_p[i]=i+OP_G_DIM;
 Inv_sz().ReAlloc(OP_G_DIM+s);
 for(i=1;i<=z;i++)
  Inv_sz()[z_p[i]]=i;
 for(i=1;i<=s;i++)
  Inv_sz()[s_p[i]]=i;

 for(i=1;i<=s;i++)
  {
   Sp_U_Gr()[i]=young_part[i];
   Sp_O_Gr()[i]=young_part[i];
  }
 for(i=1;i<=z;i++)
  {
   Zei_U_Gr()[i]=0;
   Zei_O_Gr()[i]=1;
  }

 if(VERBOSE)
  {
   printf("Nach ORDDNK::Init\n");
   printf("s=%d z=%d anz=%d GROUP_IS_ID=%d\n",
	  s,z,Anz(),GROUP_IS_ID);
   printf("young_part=\n");
   young_part.PrintUsed(0);
   fflush(stdout);
  }

}



void ORDDNK::Init(int alone)
{
 int i,j;

 s = young_part.Used()-1;
 if(s == 0)
  {
   if(! GROUP_IS_ID)
    {
     OP_AUT.Init(OP_G.Dim());
     OP_AUT=OP_G;
     AUT_IS_ID=0;
    }
   else
     AUT_IS_ID=1;
   IS_FIRST=1;
   VATER=NULL;
   return;
  }
 Anz()=0;
 for(i=1;i <= s;i++)
  Anz()+=young_part[i];
 GetIS_NULL_REP()=0; 
 SetROWWISE_NUMBERING();
 if(! GROUP_IS_ID)
  {
   OP_AUT.Init(OP_G.Dim());
   G.Init(s+OP_G.Dim());
   AUT.Init(s+OP_G.Dim());
   LABRA_TG D(s);
   G.DirProd(OP_G,D); 
  }

 ORDTREU_SP_Z_SUMS::Init(alone);

 for(i=1;i<=s;i++)
  s_p[i]=i+OP_G_DIM;
 Inv_sz().ReAlloc(OP_G_DIM+s);
 for(i=1;i<=z;i++)
  Inv_sz()[z_p[i]]=i;
 for(i=1;i<=s;i++)
  Inv_sz()[s_p[i]]=i;

 for(i=1;i<=s;i++)
  {
   Sp_U_Gr()[i]=young_part[i];
   Sp_O_Gr()[i]=young_part[i];
  }
 for(i=1;i<=z;i++)
  {
   Zei_U_Gr()[i]=0;
   Zei_O_Gr()[i]=1;
  }

 if(alone == 1)
  {
   ZIEL=1;
   for(i=z;i > young_part[young_part.Used()];i--)
    ZIEL*=i;
   for(i=1;i < young_part.Used();i++)
    {
     for(j=2;j <= young_part[i];j++)
      {
       L1=j;
       ZIEL/=L1;
      } 
    }
   L1=0;
  }
}





int ORDDNK::NextRep()
{
 int i,j,ret;

 if(s == 0)
  {
   if(IS_FIRST)
    {
     IS_FIRST=0;
     if(VATER != NULL)
      {
       for(i=1;i<=z;i++)
        if(! VATER->Set(z_p[i],OP_G_DIM+1,1))
         {
          for(j=1;j<i;j++)
           VATER->Del(z_p[j],OP_G_DIM+1);
          return(0);
         }	
      }
     return(1);
    }
   else
    {
     if(VATER != NULL)
      for(j=1;j<=z;j++)
       VATER->Del(z_p[j],OP_G_DIM+1); 
     return(0);
    }
  }

 if((StandAlone == 1)&&(ZIEL == L1))
  return(0);
 ret=ORDTREU::NextRep();

 if(StandAlone==1)
  {
   L2=G.Ordnung();
   L2/=AUT.Ordnung();
   L1+=L2;
  }

 return(ret);
}




short ORDDNK::GetErg(int i)
{
 #ifdef DEBUG_TG
  if((i < 1) || (i > z))
   {
    FatalMess("Wrong parameter in ORDDNK::GetErg\n");
    exit(0);
   }
 #endif

 int j;

 for(j=1;j<=s;j++)
  {
   if(K[i][j]==1)
    return(j);
  }
 return(s+1);
}





void ORDDNK::BerechneAut()
{
 int i,j;


 ORDTREU::BerechneAut();

 AUT.CycleId();

 for(i=1;i<=OP_G.Dim();i++)
  OP_AUT.pi(i)=AUT.pi(i);

 for(i=1;i<=OP_G.Dim();i++)
  {
   OP_AUT.HV(i)=AUT.HV(i);
   if(AUT.HV(i) != i)
    {
     for(j=1;j<=OP_G.Dim();j++)
      {
       OP_AUT.KM(i)[j]=AUT.KM(i)[j];
       OP_AUT.EM(i)[j]=AUT.EM(i)[j];
      }
    }
  }
}






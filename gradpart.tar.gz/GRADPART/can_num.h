#ifndef CAN_NUM_H

#include <iostream.h>
#include "array.t"
#include "defs.h"
#include "list.t"
#include "permut.t"
#include "labra.h"


class CAN_NUM
{
 protected:

  ARRAY < VEKTOR < char > >              matrix;
  ARRAY < VEKTOR < short > >             NewNBlist;
  ARRAY < ARRAY < VEKTOR < short > > >   klassen;
  ARRAY < VEKTOR < short > >             dummy;
  VEKTOR < short >                       du2,du3;
  short                                  dim;
  PERMUT < short >                       loes;
  ARRAY < PERMUT < short > >             eins_el;   
  ARRAY < VEKTOR < short > >             new_eins_el;   
  char                                   is_first;
  char                                   MAX_VAL;

  VEKTOR < short >                       num_length;
  VEKTOR < short >                       new_num_length;
  int                                    AUT_TRANS_NR;
  ARRAY < PERMUT < short > >             auts;
  VEKTOR < short >                       aut_trans_nr;
  LABRA_TG                               AUT;  
  char                                   AUT_IS_ID;

  void                         iteriere_klassen(int tiefe);
  int                          backtrack(int tiefe);
  int                          is_groesser(int tiefe);
  void                         print_klassen(int tiefe);
  void                         BerechneNewNB();
  void                         BerechneAutGruppe();

 public:
                               CAN_NUM() { MAX_VAL=1; dim = 0; }
                               CAN_NUM(int _dim);
  void                         Init(int _dim);
  void                         FREE();       
  void                         Init(ARRAY < VEKTOR < short > >& NBlist);
  void                         Run();
  ARRAY < VEKTOR < short > >&  GetNewNBlist() 
                                { return(NewNBlist); }  
  LABRA_TG&                    GetAUT() { return(AUT); }
  char&                        GetAUT_IS_ID() { return(AUT_IS_ID); }
};





class HASH_INFO
{
 public:
                                HASH_INFO() 
                                 { name=NULL; }
                                ~HASH_INFO();

  ARRAY < VEKTOR < short > >    NB_List;
  char                          **name;

  void                          operator=(HASH_INFO& H);  
  int                      operator==(HASH_INFO& H);
  void                          Read(char *filename,int start);
  int                      Append(char *filename);
  void                          SchreibeBinaer(FILE *fp,char *z);
  void                          LeseBinaer(FILE *fp,char *z);
};



class CAN_HASH
{
 protected:
  int                                  anz;
  LIST_BASE < VEKTOR < char > >             **simpletafel;
  LIST_BASE < HASH_INFO >                   **hashtafel;
  LIST_BASE < int >                    **HDDtafel; 
  HASH_INFO                                 dummy; 
  int                                  schon_da_nr;  
  char                                      HDD_SAVE;
  //==1, if the HASH_INFO-structs are saved to the harddisk
  //==0, otherwise
  short                                     file_nr;
  char                                      file_nr_flag;                                     
  char                                      SIMPLE_GRAPHS;

 public:
                 CAN_HASH();
                 CAN_HASH(int _anz);
                 ~CAN_HASH();
  void           Init(int _anz);
  void           FREE(); 
                         
  int       Insert(ARRAY < VEKTOR < short > >& NBList);
  int       Insert(HASH_INFO& H,int nr);
  //return value ==
  //          1, if vek has been inserted
  //          0, if vek already has been stored     
  //         -1, if harddisk is full          

  void           SetFileNr(short nr)
                  { file_nr_flag = 1; file_nr = nr; }
  void           ClearHDD();
  char&          GetHDD_SAVE() { return(HDD_SAVE); }
  int       GetEquNr() { return(schon_da_nr); }   
  void           SetSimpleGraphs() { SIMPLE_GRAPHS = 1; }
};




#define CAN_NUM_H
#endif



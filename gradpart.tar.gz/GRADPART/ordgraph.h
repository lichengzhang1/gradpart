#ifndef MULGRAPH_H

#include "labra.h"
#include "div.h"


class MULTGRAPH
{
 protected:


  char   ONLY_CANDS;
  PERMUT < short >  z_p;
  ARRAY < VEKTOR < short > > s_p;

  int zaehler;

  GRAPH_PART                  a_GRAPH_PART;

  int                    maxgrad;
  //maximal degree

  VEKTOR < short >            partition;
  //degree partition

  int                    edge_anz; 
  int                    edge_soll; 

  int                    max_val;
  //maximal valency

  int                    dim;
  //number of vertices 

  int                    dim_gr_0;
  //number of vertices of degree > 0

  LABRA_TG                    AUT;
  //automorphism group of a representative

  char                        AUT_IS_ID;

  int                    LOESUNG_ANZ;

  int                    KAND_ANZ;

  char                        IS_REGULAR; 

  char                        ZSHG;

  char                        ENABLE_AUT;

  int                    girth;

  BITVEK                      BV1;
  ARRAY < VEKTOR < short > >  BV;
  ARRAY < VEKTOR < short > >  nblist;
  //internal neighbourhood-list 

  ARRAY < VEKTOR < short > >  NBlist;
  //neighbourhood-list of dimension dim

  ARRAY < VEKTOR < short > >  NBwert;

  VEKTOR < short >            kr_anz;
  //kr_anz[i+1] == number of rings after inserting
  //the first i edges

  int                    eins_kr_l;
  //length of the ring that contains 1

  ARRAY < BITVEK >            Zshg_vec; 
  //connection-component of 1

  ARRAY < VEKTOR < char > >   K;
  //adjacency-matrix

  int                    ZURUECK_Z;
  int                    ZURUECK_SP;
  //contains the position to which we can
  //go back after a negative MinTest

  double                      min_time;

  VEKTOR < short >            platz_zei;
  VEKTOR < short >            platz_sp;
  //contains rows and columns of the entries != 0

  VEKTOR < short >            platz_wert;
  //contains the values of the entries != 0 

  VEKTOR < short >            z_soll;
  //z_soll[i] 1's have to be set in row i

  VEKTOR < short >            z_sum;
  //z_sum[i] 1's have been set in row i until now

  short                       z_idx;
  short                       sp_idx;
  //(z_idx,sp_idx) is the current position in the matrix

  ARRAY < VEKTOR < short > >  lambda_blocks;   
  //these are the partitions used for constructing only
  //semi-canonic candidates.

  short                       last_comp_lambda; 

  char                        is_first;
  
  VEKTOR < short >            test_ind;
  VEKTOR < short >            test_bis;
  //counting variables used in MinTest

  ARRAY < VEKTOR < short > >  MinInds;  

  PERMUT < short >            inv_trans;
  //permutation used in MinTest to indicate the matrix

  ARRAY < VEKTOR < short > >  transpos_left;
  ARRAY < VEKTOR < short > >  transpos_right;
  //Here the used transpositions in MinTest are stored.
  //When we go up in the recursion tree, we have to divide
  //inv_trans by the corresponding transpositions.

  ARRAY < VEKTOR < short > >  auts;
  //array of automorphisms used to build AUT. 

  VEKTOR < short >            auts_trans_nr;

  int                    NextInd();
  //computes the next valid position for inserting a edge.

  int                    IsErlaubt(int wert);
  void                        Del();
  void                        BerechneNextLambda(int zeile);       
  int                    MinTest();
  void                        MalTranspos(int l,int r);
  void                        BerechneZURUECK(int tiefe,int min_gr);
  int                    Abstand(int a,int b);
  int                    IsMaxAbstand(int a,int b,int l);
  int                    GirthCheck(int l);
  int                    Lambda(int i,int j);
  void                        BerechneAut();
  int                    PartitionCheck(int z_m,int sp_m);
  int                    ZshgTest(int wert);
  int                    RingTest();
  void                        NotiereNBlist();

 public:
                              MULTGRAPH() { return; }
                              ~MULTGRAPH();
   
  void                        Init();
  void                        FREE();
  int                         NextRep();  
  void                        PrintLoesung();

  ARRAY < VEKTOR < short > >& GetNBlist() { return(NBlist); }
  ARRAY < VEKTOR < short > >& GetNBwert() { return(NBwert); }
  int                         GetErg(int i,int j);
  int                         GetZ_SP_SUM(int i);
  VEKTOR < short >&           GetPARTITION() 
                               { return(partition); }
  int&                        GetMAXGRAD()
                               { return(maxgrad); }
  int&                        GetMAXVAL()
                               { return(max_val); }
  LABRA_TG&                   GetAUT()
                               { return(AUT); }
  char                        GetAUT_IS_ID()
                               { return(AUT_IS_ID); }
  char&                       GetENABLE_AUT()
                               { return(ENABLE_AUT); }
  int                         GetKand() 
                               { return(KAND_ANZ); }
  int                         GetLoesung()
                               { return(LOESUNG_ANZ); } 
  char&                       GetZSHG()
                               { return(ZSHG); }
  int&                        GetGirth()
                               { return(girth); }
  int&                        GetDim()
                               { return(dim); }
  double                      GetTicks()
                               { return(min_time); }
  void                        ResetTicks()
                               { min_time = 0.0; }
  void  SetONLY_CANDS(PERMUT < short >& P);
         

};




#define MULTGRAPH_H
#endif



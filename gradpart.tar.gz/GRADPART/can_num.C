#include <unistd.h>
#include "can_num.h"



void CAN_NUM::BerechneNewNB()
{
 int i,j,k;

 for(i=1;i<=dim;i++)
  NewNBlist[i].Used()=0;

 for(i=1;i<=dim;i++)
  {
   for(j=i+1;j<=dim;j++)
    {
     if(matrix[loes[i]][loes[j]] == 1)
      NewNBlist[i][++NewNBlist[i].Used()]=j; 
    }
  }
}



void CAN_NUM::FREE()
{
 matrix.FREE();
 NewNBlist.FREE();
 klassen.FREE();
 dummy.FREE();
 loes.FREE();
 eins_el.FREE();  
 new_eins_el.FREE();

 num_length.FREE();
 new_num_length.FREE();
 auts.FREE();
 aut_trans_nr.FREE();
 
 dim = 0;
}



void CAN_NUM::Init(int _dim)
{
 if((dim > 0)&&(dim != _dim))
  FREE();
 dim=_dim;
 matrix.REALLOC(dim,dim);
 NewNBlist.REALLOC(dim,dim);
 
 VEKTOR < short > memdim(dim);
 for(int i=1;i<=dim;i++)
  memdim[i]=dim;
 klassen.REALLOC(dim,memdim,dim);

 dummy.REALLOC(dim,dim);
 loes.ReAlloc(dim);
 eins_el.REALLOC(dim,dim);
 new_eins_el.REALLOC(dim,dim);

 num_length.ReAlloc(dim);
 new_num_length.ReAlloc(dim);
 aut_trans_nr.ReAlloc(20);
 auts.REALLOC(10,dim);
 AUT.Init(dim);
 
}



CAN_NUM::CAN_NUM(int _dim)
{
 MAX_VAL = 1;
 Init(_dim);
}



void CAN_NUM::Init(ARRAY < VEKTOR < short > >& NBlist)
{
 int i,j,k,l,m,n;
 VEKTOR < short > grade(dim);

 //nur schlichte Graphen
 MAX_VAL = 1;
 grade.Clear();
 for(i=1;i<=dim;i++)
  matrix[i].Clear();

 for(i=1;i<=dim;i++)
  {
   for(j=1;j<=NBlist[i].Used();j++)
    {
     matrix[i][NBlist[i][j]]=1;
     matrix[NBlist[i][j]][i]=1;
    }
  }

 for(i=1;i<=dim;i++)
  {
   for(j=1;j<=dim;j++)
    if(matrix[i][j] == 1)
     grade[i]++;
  }


 //erste Klassifikation nach dem Grad
 klassen[1].Used()=0;
 eins_el[1].Used()=0;
 new_eins_el[1].Used()=0;
 i=0;
 n=0;
 while(n < dim)
  {
   //search vertices of degree i
   m=0;
   for(j=1;j<=dim;j++)
    {
     if(grade[j] == i)
      {
       n++;
       if(m==0)
        {
         klassen[1].Used()++;
         klassen[1][klassen[1].Used()].Used()=0;
        }
       k=klassen[1].Used();
       klassen[1][k][++klassen[1][k].Used()]=j;
       if(i==0)
        {
         eins_el[1][++eins_el[1].Used()]=klassen[1][k][1];
         klassen[1].Used()--;
        }
       else
        m=1; 
      }
    }
   if((m == 1)&&(klassen[1][k].Used() == 1)&&(i > 0))
    {
     eins_el[1][++eins_el[1].Used()]=klassen[1][k][1];
     new_eins_el[1][++new_eins_el[1].Used()]=klassen[1][k][1];
     klassen[1].Used()--;
    }
   i++;
  }
}





void CAN_NUM::Run()
{
 int j;

// printf("Run\n");

 auts.Used() = 0;
 AUT_TRANS_NR = 10000;
 is_first=1;
 iteriere_klassen(1);
 if(klassen[1].Used() == 0)
  {
   for(j=1;j<=dim;j++)
    loes[j]=eins_el[1][j];
  }
 else
  backtrack(1);

// printf("fertig\n");

 if(MAX_VAL == 1)
  BerechneNewNB();

 BerechneAutGruppe(); 
}




void CAN_NUM::print_klassen(int tiefe)
{
 int i,j,k;

 printf("tiefe=%d\n",tiefe);
 for(i=1;i<=klassen[tiefe].Used();i++)
  {
   printf("{");
   for(j=1;j<=klassen[tiefe][i].Used();j++)
    {
     printf("%d",klassen[tiefe][i][j]);
     if(j < klassen[tiefe][i].Used())
      printf(",");
    }
   printf("}");
  }
 printf("\n");

 printf("eins_el=\n");
 for(i=1;i<=eins_el[tiefe].Used();i++)
  printf("%d ",eins_el[tiefe][i]);
 printf("\n");

 printf("new_eins_el=\n");
 for(i=1;i<=new_eins_el[tiefe].Used();i++)
  printf("%d ",new_eins_el[tiefe][i]);
 printf("\n");

}




void CAN_NUM::iteriere_klassen(int tiefe)
{
 int i,j,k,l,new_anz,flag;

 NEUES_EINSEL:
 while(new_eins_el[tiefe].Used() > 0)
  {
   for(i=1;i<=dim;i++)
    dummy[i].Used()=0;
   i=new_eins_el[tiefe][new_eins_el[tiefe].Used()--];

   new_anz=0;
   for(j=1;j<=klassen[tiefe].Used();j++)
    {
     for(k=0;k <= MAX_VAL;k++)
      {
       flag=0;
       for(l=1;l<=klassen[tiefe][j].Used();l++)
        {
         if(matrix[i][klassen[tiefe][j][l]] == k)
          {
           if(flag == 0)
            { flag=1; new_anz++; }
           dummy[new_anz][++dummy[new_anz].Used()] =
             klassen[tiefe][j][l];
          }
        }
      }
    }
   klassen[tiefe].Used()=0;
   for(j=1;j<=dim;j++)
    klassen[tiefe][j].Used()=0;
   for(j=1;j <= new_anz;j++)
    {
     if(dummy[j].Used() == 1)
      {
       new_eins_el[tiefe][++new_eins_el[tiefe].Used()]=dummy[j][1];
       eins_el[tiefe][++eins_el[tiefe].Used()]=dummy[j][1];
      }
     else
      {
       k = ++klassen[tiefe].Used();
       klassen[tiefe][k].Used()=dummy[j].Used();
       klassen[tiefe][klassen[tiefe].Used()].Swap(dummy[j]);
      }
    }
  }

 NEUER_VERGLEICH:
 if(MAX_VAL==1)
  {
   du2.ReAlloc(dim);
   du3.ReAlloc(dim); 
   for(i=1;i<=klassen[tiefe].Used();i++)
    {
     for(int io=1;io <= klassen[tiefe].Used();io++)
      {
       new_anz=0;
       for(j=1;j<=dim;j++)
        dummy[j].Used()=0;
       du3.Used() = 0;
       for(j=1;j<=klassen[tiefe][i].Used();j++)
        {
         //zaehle, wieviele Nachbarn klassen[tiefe][i][j] 
         //in Klasse Nr. io hat
         du2[j]=0;
         for(k=1;k<=klassen[tiefe][io].Used();k++)
          if(matrix[klassen[tiefe][i][j]][klassen[tiefe][io][k]]==1) 
           du2[j]++;
         char schon = 0;
         for(k=1;k<=du3.Used();k++)
          if(du3[k]==du2[j])
           { schon=1; break; }
         if(schon==0)
          du3[++du3.Used()] = du2[j]; 
        }
       if(du3.Used() > 1)
        {
         du3.Sort();
         for(k=1;k <= du3.Used();k++)
          {
           flag=0;  
           for(l=1;l<=klassen[tiefe][i].Used();l++)
            {
             if(du2[l]==du3[k])
              {
               if(flag == 0)
                { flag=1; new_anz++; }
               dummy[new_anz][++dummy[new_anz].Used()] =
                 klassen[tiefe][i][l];
              }
            }
          }
         for(k=1;k<=klassen[tiefe].Used();k++)
          {
           if(k != i)
            {
             new_anz++;
             dummy[new_anz].Used() = klassen[tiefe][k].Used();
             dummy[new_anz].Swap(klassen[tiefe][k]);
            }
          }

         klassen[tiefe].Used()=0;
         for(j=1;j<=dim;j++)
          klassen[tiefe][j].Used()=0;
         for(j=1;j <= new_anz;j++)
          {
           if(dummy[j].Used() == 1)
            {
             new_eins_el[tiefe][++new_eins_el[tiefe].Used()]=dummy[j][1];
             eins_el[tiefe][++eins_el[tiefe].Used()]=dummy[j][1];
            }
           else
            { 
             k = ++klassen[tiefe].Used();
             klassen[tiefe][k].Used()=dummy[j].Used();
             klassen[tiefe][klassen[tiefe].Used()].Swap(dummy[j]);
            }
          }
        if(new_eins_el[tiefe].Used() > 0)
         goto NEUES_EINSEL;
        else
         goto NEUER_VERGLEICH;
       } //if(du3.Used() > 1)
     }
   }
 }

 new_num_length[tiefe] = eins_el[tiefe].Used(); 
}






int CAN_NUM::backtrack(int tiefe)
{
 int ret,i,j,k,l,n;

 //printf("\rb=%d",tiefe);fflush(stdout);
// print_klassen(tiefe);

 //suche kleinste Klasse
 i=1;
 for(j=1;j<=klassen[tiefe].Used();j++)
  if(klassen[tiefe][j].Used() < klassen[tiefe][i].Used())
   i=j;

 for(j=1;j<=klassen[tiefe][i].Used();j++)
  { 
   if((j > 1)&&(tiefe < AUT_TRANS_NR))
    AUT_TRANS_NR = tiefe;
   klassen[tiefe+1].Used()=0;
   eins_el[tiefe+1].Used()=eins_el[tiefe].Used();
   for(k=1;k<=eins_el[tiefe].Used();k++)
    eins_el[tiefe+1][k]=eins_el[tiefe][k];
   for(k=1;k < i;k++)
    {
     klassen[tiefe+1].Used()++;
     klassen[tiefe+1][k].Used()=klassen[tiefe][k].Used();
     for(l=1;l <= klassen[tiefe][k].Used();l++)
      klassen[tiefe+1][k][l]=klassen[tiefe][k][l];
    }       
   if(klassen[tiefe][i].Used() == 2)
    {
     new_eins_el[tiefe+1].Used()=2;
     new_eins_el[tiefe+1][1]=klassen[tiefe][i][j];
     new_eins_el[tiefe+1][2]=klassen[tiefe][i][2-j+1];
     eins_el[tiefe+1][++eins_el[tiefe+1].Used()]=klassen[tiefe][i][j];
     eins_el[tiefe+1][++eins_el[tiefe+1].Used()]=klassen[tiefe][i][2-j+1];
    }
   else
    {
     new_eins_el[tiefe+1].Used()=1;
     new_eins_el[tiefe+1][1]=klassen[tiefe][i][j];
     eins_el[tiefe+1][++eins_el[tiefe+1].Used()]=klassen[tiefe][i][j];
    }
   n=i;
   k=0;
   if(klassen[tiefe][i].Used() > new_eins_el[tiefe+1].Used())
    {
     klassen[tiefe+1].Used()++;
     klassen[tiefe+1][n].Used()=klassen[tiefe][i].Used()-1;
     for(l=1;l<=klassen[tiefe][i].Used();l++)
      {
       if(l != j)
        klassen[tiefe+1][n][++k]=klassen[tiefe][i][l];
      }
     n++;
    }
   for(k=i+1;k<=klassen[tiefe].Used();k++)
    {
     klassen[tiefe+1].Used()++;
     klassen[tiefe+1][n].Used()=klassen[tiefe][k].Used();
     for(l=1;l<=klassen[tiefe][k].Used();l++)
      klassen[tiefe+1][n][l]=klassen[tiefe][k][l];
     n++;
    }

   iteriere_klassen(tiefe+1);

   if(klassen[tiefe+1].Used() == 0)
    {
     if(is_first == 1)
      {
       //erste Numerierung gefunden 
       for(k=1;k<=dim;k++)
        loes[k]=eins_el[tiefe+1][k];
       is_first=0; 
       for(k=1;k<=tiefe+1;k++)
        num_length[k] = new_num_length[k];
      }
     else
      {
       ret = is_groesser(tiefe+1);
       if(ret==0)
        {
         //Automorphismus gefunden
//printf("auto\n");
         if(auts.Used()==auts.Dim())
          {
           auts.REALLOC(auts.Dim()+5,dim);
           aut_trans_nr.ReAlloc(auts.Dim());
          }
         auts.Used()++;
         auts[auts.Used()] = loes;
         auts[auts.Used()].Inv();
         auts[auts.Used()] *= eins_el[tiefe+1];
         aut_trans_nr[auts.Used()] = AUT_TRANS_NR;
         if(tiefe > AUT_TRANS_NR)
          return(1);
        }
       if(ret==1)
        {
         for(k=1;k<=dim;k++)
          loes[k]=eins_el[tiefe+1][k];
         AUT_TRANS_NR = 10000;
         //bisher notierte Automorphismen verwerfen
//printf("besser\n");
         auts.Used() = 0;
         for(k=1;k<=tiefe+1;k++)
          num_length[k] = new_num_length[k];
        }
      }
    }
   else
    {
     if(is_first == 1)
       backtrack(tiefe+1);
     else
      {
       if(is_groesser(tiefe+1) >= 0)
        {
         if((backtrack(tiefe+1)==1) && (tiefe > AUT_TRANS_NR))
          return(1);
        } 
      }
    }
  }
 return(0); 
}



void CAN_NUM::BerechneAutGruppe()
{
 int i,j,k,l;
 PERMUT < short > pe;

 AUT_IS_ID = 1;

 pe.Init(dim);
 pe=loes;
 pe.Inv();

 for(i=1;i<=dim;i++)
  AUT.HV(i)=i;
 for(i=1;i<=dim;i++)
  {
   AUT.pi(i)=loes[i];
   AUT.pi_i(loes[i])=i;
  }
 for(i=1;i<=auts.Used();i++)
  {
   j = num_length[aut_trans_nr[i]]+1;
   //auts[i] transportiert j
   k = auts[i][loes[j]];
   if(AUT.HV(pe[k]) == pe[k])
    {
     AUT.HV(pe[k]) = j;
     AUT.KM(k) = auts[i];
    }
  }
 AUT.update_eckenmarken(); 
 for(i=1;i<=dim;i++)
  if(AUT.HV(i) != i)
   { AUT_IS_ID=0; break; }
}




int CAN_NUM::is_groesser(int tiefe)
{
 int i,j,k;

 for(i=1;i<=eins_el[tiefe].Used();i++)
  {
   for(j=1;j<i;j++)
    {
     if(matrix[loes[j]][loes[i]] > matrix[eins_el[tiefe][j]][eins_el[tiefe][i]])
      return(-1);
     if(matrix[loes[j]][loes[i]] < matrix[eins_el[tiefe][j]][eins_el[tiefe][i]])
      return(1);
    }
  }
 return(0);
}




/*****************************************************************/


void HASH_INFO::operator=(HASH_INFO& H)
{
 int i,j,k;

 if(name != NULL)
  {
   for(i=1;i<=NB_List.Used();i++)
    delete[] name[i];  
   delete[] name;
   NB_List.FREE();
  }
 NB_List = H.NB_List;
 if(H.name != NULL)
  {
   name = new char*[NB_List.Used()+1];
   if(name==NULL)
    {
     FatalMess("memory exceeded in HASH_INFO::operator=\n");
     exit(0);
    } 
   for(i=1;i<=NB_List.Used();i++)
    {
     name[i] = new char[20];
     if(name[i] == NULL)
      {
       FatalMess("memory exceeded in HASH_INFO::operator=\n");
       exit(0);
      }  
     strcpy(name[i],H.name[i]);
    }
  }
 else
  name=NULL;
}


//fuer kurze strings
void HASH_INFO::SchreibeBinaer(FILE *fp,char *z)
{
 int i,j;

 i = 0;
 while(z[i] != '\0')
  i++;
 //z[0],...,z[i-1] 
 fprintf(fp,"%c",i-1);
 for(j=0;j<=i-1;j++)
  fprintf(fp,"%c",(unsigned char)(z[j]));
}



void HASH_INFO::LeseBinaer(FILE *fp,char *z)
{
 unsigned char i,j,k;

 fscanf(fp,"%c",&i);
 for(j=0;j<=i;j++)
  {
   fscanf(fp,"%c",&k);
   z[j] = k;
  }
 z[i+1] = '\0'; 
}



int HASH_INFO::Append(char *filename)
{
 FILE *fp;
 unsigned char i,j,k;


 fp = fopen(filename,"ab");
 if(fp == NULL)
   return(-1);
 fseek(fp,0,SEEK_END);
 if(fprintf(fp,"%c",(unsigned char)(NB_List.Used())) < 0) return(-1);
 for(i=1;i<=NB_List.Used();i++)
   SchreibeBinaer(fp,name[i]);
  
 for(i=1;i<=NB_List.Used();i++)
  {
   if(fprintf(fp,"%c",(unsigned char)(NB_List[i].Used())) < 0) return(-1);
   for(j=1;j<=NB_List[i].Used();j++)
     if(fprintf(fp,"%c",(unsigned char)(NB_List[i][j])) < 0) return(-1);
  } 
 fclose(fp);
 return(1);
}


void HASH_INFO::Read(char *filename,int start)
{
 FILE *fp;
 unsigned char i,j,k,ret;

 fp = fopen(filename,"rb");
 if(fp == NULL)
  {
   char nachr[1000];
   sprintf(nachr,"couldn't open %s\n",filename);
   FatalMess(nachr);
   exit(0);
  }
 ret=fseek(fp,start,SEEK_SET);
 if(ret != 0)
  {
   FatalMess("error in fseek \n");
   exit(0);
  }
 ret=fscanf(fp,"%c",&j);
 if(ret != 1)
  {
   FatalMess("couldn't read dim\n");
   exit(0);
  }

 if(NB_List.Used() != j)
  {
   if(name != NULL)
    {
     for(i=1;i<=NB_List.Used();i++)
      delete[] name[i];  
     delete[] name;
     NB_List.FREE();
    }
   NB_List.REALLOC(j,2*j);
   NB_List.Used()=j;
   name = new char*[NB_List.Used()+1];
   if(name==NULL)
    {
     FatalMess("memory exceeded in HASH_INFO::operator=\n");
     exit(0);
    } 
   for(i=1;i<=NB_List.Used();i++)
    {
     name[i] = new char[20];
     if(name[i] == NULL)
      {
       FatalMess("memory exceeded in HASH_INFO::operator=\n");
       exit(0);
      }  
    }
  }  
 
 for(i=1;i<=NB_List.Used();i++)
   LeseBinaer(fp,name[i]);

 for(i=1;i<=NB_List.Used();i++)
  {
   fscanf(fp,"%c",&j);
   NB_List[i].Used() = j;
   for(k=1;k<=NB_List[i].Used();k++)
    {
     ret=fscanf(fp,"%c",&j);
     if(ret != 1)
      {
       char nachr[1000];
       sprintf(nachr,"couldn't read NB_List[%d][%d]\n",i,k);
       FatalMess(nachr);
       exit(0); 
      } 
     NB_List[i][k] = j;
    }
  }
 fclose(fp);
}






int HASH_INFO::operator==(HASH_INFO& H)
{
 int i,j,k;

 if(NB_List.Used() != H.NB_List.Used())
  return(0);
 for(i=1;i<=NB_List.Used();i++)
  {
   if(NB_List[i].Used() != H.NB_List[i].Used())
    return(0);
   for(j=1;j<=NB_List[i].Used();j++)
    if(NB_List[i][j] != H.NB_List[i][j])
     return(0); 
  } 
 if(name != NULL)
  {
   if(H.name == NULL)
    return(0);
   for(i=1;i<=NB_List.Dim();i++)
    if(strcmp(name[i],H.name[i]))
     return(0);
  }
 else
  {
   if(H.name != NULL)
    return(0); 
  }

 return(1);
}




HASH_INFO::~HASH_INFO()
{
 int i;

 if(name != NULL)
  {
   for(i=1;i<=NB_List.Dim();i++)
    delete[] name[i];
   delete[] name;
  }
}



/****************************************************************/



CAN_HASH::CAN_HASH()
{
 anz = 0;
 simpletafel=NULL;
 hashtafel=NULL;
 HDDtafel = NULL;
 SIMPLE_GRAPHS = 0;
}


CAN_HASH::CAN_HASH(int _anz)
{
 anz = 0;
 simpletafel=NULL;
 hashtafel=NULL;
 HDDtafel = NULL;
 SIMPLE_GRAPHS = 0;
 Init(_anz);
}



void CAN_HASH::Init(int _anz)
{
 FREE();
 anz=_anz;
 file_nr_flag = 0;
 if(HDD_SAVE)
  {
   HDDtafel=new LIST_BASE<int>*[anz+1];
   if(HDDtafel == NULL)
    {
     FatalMess("memory exceeded\n");
     exit(0);
    }
   for(int i=1;i<=anz;i++)
    {
     HDDtafel[i] = new LIST_BASE < int >;
     if(HDDtafel[i] == NULL)
      {
       FatalMess("memory exceeded\n");
       exit(0);
      }
    }
  }
 else
  {
   if(SIMPLE_GRAPHS)
    {
     simpletafel=new LIST_BASE< VEKTOR < char > >*[anz+1];
     if(simpletafel == NULL)
      {
       FatalMess("memory exceeded\n");
       exit(0);
      }
     for(int i=1;i<=anz;i++)
      {
       simpletafel[i] = new LIST_BASE < VEKTOR < char > >;
       if(simpletafel[i] == NULL)
        {
         FatalMess("memory exceeded\n");
         exit(0);
		} 
      }
	}
   else
    {
     hashtafel=new LIST_BASE<HASH_INFO>*[anz+1];
     if(hashtafel == NULL)
      {
       FatalMess("memory exceeded\n");
       exit(0);
      }
     for(int i=1;i<=anz;i++)
      {
       hashtafel[i] = new LIST_BASE < HASH_INFO >;
       if(hashtafel[i] == NULL)
        {
         FatalMess("memory exceeded\n");
         exit(0);
		} 
      }
    }
  }
}


void CAN_HASH::FREE()
{
 if(simpletafel)
   { 
    for(int i=1;i<=anz;i++)
     delete simpletafel[i];
    delete[] simpletafel; 
    simpletafel=NULL; 
   }
 if(hashtafel)
   { 
    for(int i=1;i<=anz;i++)
     delete hashtafel[i];
    delete[] hashtafel; 
    hashtafel=NULL; 
   }
 if(HDDtafel)
   { 
    for(int i=1;i<=anz;i++)
     delete HDDtafel[i];
    delete[] HDDtafel; 
    HDDtafel=NULL;
   }
 anz=0;
}


CAN_HASH::~CAN_HASH() 
{
 if(simpletafel)
   { 
    for(int i=1;i<=anz;i++)
     delete simpletafel[i];
    delete[] simpletafel; 
    simpletafel=NULL; 
   }
 if(hashtafel)
   { 
    for(int i=1;i<=anz;i++)
     delete hashtafel[i];
    delete[] hashtafel; 
    hashtafel=NULL; 
   }
 if(HDDtafel)
   { 
    for(int i=1;i<=anz;i++)
     delete HDDtafel[i];
    delete[] HDDtafel; 
    HDDtafel=NULL;
   }
 anz=0;
}



int CAN_HASH::Insert(ARRAY < VEKTOR < short > >& NBList)
{
 int i,j,k,l;
 int mal[10];
 char filename[100];
 VEKTOR < char > NBListKompr;

 NBListKompr.Used() = 0;
 i = 0;
 for(j=1;j<=NBList.Dim();j++)
  i += (1+NBList[j].Used());
 NBListKompr.Init(i);
 i=0;
 for(j=1;j<=NBList.Dim();j++)
  {
   NBListKompr[++NBListKompr.Used()] = NBList[j].Used();  
   for(k=1;k<=NBList[j].Used();k++)
     NBListKompr[++NBListKompr.Used()] = NBList[j][k];
  }	 

 mal[0]=234L;mal[1]=1906L;mal[2]=26438L;mal[3]=45L;mal[4]=123456L;
 mal[5]=98385L;mal[6]=3L;mal[7]=34100L;mal[8]=111L;mal[9]=99L;

 l=0;
 i=0;
 for(j=1;j<=NBList.Dim();j++)
  {
   for(k=1;k<=NBList[j].Used();k++)
    {
     i+=NBList[j][k]*mal[l % 10];
     l++;
    }
  }
 if(i < 0)i = -i;
 i = i % anz;
 i++;
 // 1 <= i <= anz

 simpletafel[i]->Start();
 WEITER:
 while(! simpletafel[i]->IsLast())
  {
   VEKTOR<char>& N_V=simpletafel[i]->GetNext(schon_da_nr);
   if(! (NBListKompr==N_V))
    goto WEITER; 
   return(0);
  }
 simpletafel[i]->Insert(NBListKompr,1);
 return(1);
}


int CAN_HASH::Insert(HASH_INFO& H,int nr)
{
 int i,j,k,l;
 int mal[10];
 char filename[100];

 if(file_nr_flag==0)
  strcpy(filename,"HASHTEMP.dat");
 else
  sprintf(filename,"HASHTEMP%d.dat",file_nr);
  
 mal[0]=234L;mal[1]=1906L;mal[2]=26438L;mal[3]=45L;mal[4]=123456L;
 mal[5]=98385L;mal[6]=3L;mal[7]=34100L;mal[8]=111L;mal[9]=99L;

 l=0L;
 i=0L;
 for(j=1;j<=H.NB_List.Dim();j++)
  {
   for(k=1;k<=H.NB_List[j].Used();k++)
    {
     i+=H.NB_List[j][k]*mal[l % 10L];
     l++;
    }
  }
 if(i < 0)i = -i;
 i = i % anz;
 i++;
 // 1 <= i <= anz

 if(HDD_SAVE==0)
  {
   hashtafel[i]->Start();
   WEITER:
   while(! hashtafel[i]->IsLast())
    {
     HASH_INFO& N_V=hashtafel[i]->GetNext(schon_da_nr);
     if(! (H==N_V))
      goto WEITER; 
     return(0);
    }
   hashtafel[i]->Insert(H,nr);
   return(1);
  }
 else
  {
   HDDtafel[i]->Start();
   HDD_WEITER:
   while(! HDDtafel[i]->IsLast())
    {
     j = HDDtafel[i]->GetNext(schon_da_nr);
     dummy.Read(filename,j);
     if(! (dummy==H)) 
      goto HDD_WEITER;
     return(0);
    }
   FILE *fp;
   fp = fopen(filename,"ab");
   fseek(fp,0,SEEK_END);
   k = ftell(fp);
   HDDtafel[i]->Insert(k,nr);
   fclose(fp);
   return(H.Append(filename));  
  }
} 



void CAN_HASH::ClearHDD()
{
 char filename[100];

 if(file_nr_flag==0)
  strcpy(filename,"HASHTEMP.dat");
 else
  sprintf(filename,"HASHTEMP%d.dat",file_nr);

 if(HDD_SAVE)
  unlink(filename);
}

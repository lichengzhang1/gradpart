#ifndef ORDHASH_H
#define ORDHASH_H

#include <stdio.h>
#include "vector.t"
#include "defs.h"


//This is a class to hash vectors of short.
//We decide, that these vectors must have minimal
//length of 11.
 
class ORDHASH
{
 private:
  VEKTOR<short>    einsindex;

  VEKTOR<short>    v;
  //this vector has length HASH_LENGTH. 

  short            inf_length;
  //Lenght of the vectors to store

  int              inf_max;
  //maximal number of vectors to store

  int              inf_anz;
  //number of currently stored vectors

  VEKTOR<int>      collision_table;
  //This is used to follow the list of vectors
  //in case of a collision.
  //collision_table must have length of at
  //least inf_max. 

  short&    IsUsed(int i)
             {
              return(v[(i-1)*(inf_length+2)+1]);
             }

  int&      Next(int i)
             {
              return(collision_table[i]);
             }

  short&    HoleTiefe(int i)
             {
              return(v[(i-1)*(inf_length+2)+2]);
             }
 
  //1 <= j <= HoleTiefe(i)
  short&    HoleMinInd(int i,int j)
             {
              return(v[(i-1)*(inf_length+2)+2+j]);
             }

  //HoleTiefe(i)+1 <= j <= eins_anz
  short&    HoleEinsInd(int i,int j)
             {
              return(v[(i-1)*(inf_length+2)+2+j]);
             }

  void FuegeEin(int minrek_tiefe,VEKTOR<short>& Ind,
                   VEKTOR<short>& places,int i);

  int IsGleich(int minrek_tiefe,VEKTOR<short>& Ind,
                   VEKTOR<short>& places,int i);
 public:
            ORDHASH() { return; } 

  void      Init(int veclength,VEKTOR<short>& einsen);

  int       Insert(int minrek_tiefe,VEKTOR<short>& Ind,
                   VEKTOR<short>& places);
  //return value =
  // = 0, if the vector composed out of Ind and places
  //      was not stored before. In this case the new 
  //      vector is inserted.
  // = 1, otherwise

};


#endif

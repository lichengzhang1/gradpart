#include <stdio.h>
#include "ordtreu.h"
#include "ordSpZ.h"
#include "sims.h"
#include "ordConj.h"



//ORDHASH a_HASH;

#define NB_ALLOC_CR 5


int conj_classes(int deg, int nb_gen, int *gen, 
	int f_verbose, int f_very_verbose, 
	int *nb_classes, int **class_reps, ARRAY < LABRA_TG >& Stab)
{
 int i,j;
 int anz;
 int grad;
 char START_AT_BEGINNING=1;
 int *cr, *cr1, alloc_cr = 0;

 LABRA_TG G;

 grad = deg;
 
 G.Init(grad);

 G.InitErz(nb_gen, gen);


 anz=0;
 G.ConjStart();
 
 G.GetORD().GetPRINT_SOLUTIONS() = 0;
 G.GetORD().GetPRINT_ANZ_CANDIDATES() = f_very_verbose;
 G.GetORD().GetPRINT_CANDIDATES() = 0;
 
 
 while(G.NextConjClass())
 { 
  if (f_very_verbose) {
    printf("\n");
    G.GetConjRep().Print(0);
    }
  if (f_verbose) {
   if (((anz + 1) % 10) == 0)
     printf(",");
   else
     printf(".");
   if ((anz + 1) % 50 == 0) {
    printf("\n");
    fflush(stdout);
    }
   fflush(stdout);
   }

		 	/* reallocate the array of representatives if needed: */
		 	if (alloc_cr == 0 || anz >= alloc_cr) {
		 		cr1 = (int *) malloc((alloc_cr + NB_ALLOC_CR) * 
		 				deg * sizeof(int));
		 		for (i = 0; i < alloc_cr * deg; i++) {
		 				cr1[i] = cr[i];
		 			}
		 		if (alloc_cr)
		 			free(cr);
		 		cr = cr1;
		 		cr1 = NULL;
		 		alloc_cr += NB_ALLOC_CR;
		 		}
		 		
		 	/* get the new representative as a permutation: */
		 	for (j = 0; j < deg; j++) {
		 		cr[anz * deg + j] = G.GetConjRep()[j + 1];
		 		}
  Stab.ReAlloc(Stab.Dim()+1);
  Stab.Add(Stab.Dim(),deg);
  Stab[Stab.Dim()]=G.GetORD().AutGruppe();
  
  if (f_very_verbose) {
    printf("ORDNUNG=\n");
    Stab[Stab.Dim()].Ordnung().Print(0);
    }

  anz++;
 }
 
	*class_reps = cr;
	*nb_classes = anz;
 if (f_verbose) {
   fprintf(stderr,"\nANZAHL=%d\n",anz);
   }

 return 1;
}

#if 0
main(int argc, char* argv[])
{
 int i, j;
 int deg = 6, *gen = NULL, nb_gen = 2;
 int nb_cr, *cr;

  gen = (int *) malloc(nb_gen * deg * sizeof(int));
  for (i = 0; i < nb_gen; i++) {
  	for (j = 0; j < deg; j++) {
  		gen[i * deg + j] = j + 1;
  		}
  	}
  for (j = 0; j < deg; j++) {
  	if (j < deg - 1)
	  	gen[0 * deg + j] = j + 2;
	  else
	  	gen[0 * deg + j] = 1;
  	}
  gen[1 * deg + 0] = 2;
  gen[1 * deg + 1] = 1;

  conj_classes(deg, nb_gen, gen, 1, 1, &nb_cr, &cr);
	
  free(gen);
 return(0);
}
#endif






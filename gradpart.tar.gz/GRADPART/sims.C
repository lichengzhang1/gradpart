#include "sims.h"




void SIMS::Init(int _grad)
{

 #ifdef DEBUG_TG
  if(_grad < 1)
   {
    FatalMess("SIMS-Init mit grad < 1 !!\n");
    exit(0);
   }
 #endif

 if(_grad < grad)
  return;

 grad=_grad;
 basis.ReAlloc(grad);
 if(grad > 1)
  transv.ReAlloc(grad-1); 

}



void SIMS::FREE()
{
 transv.FREE();
 basis.FREE();
}


SIMS::SIMS(int _grad)
{
 #ifdef DEBUG_TG
  if(_grad < 1)
   {
    FatalMess("SIMS-Konstruktor mit grad < 1 !!\n");
    exit(0);
   }
 #endif

 grad=_grad;

 //Hat die Permutationsgruppe Grad grad, so haben wir grad-1
 //Transversalen

 if(grad > 1)
  transv.Init(grad-1);
 basis.Init(grad);
}

//Mit der Notation der Diplomarbeit gilt:
//Zurueckgegeben wird die Transversale von G^i / G^(i+1).
//=> i darf also Werte zwischen 1 und grad-1 annehmen


ARRAY <PERMUT <short> >& SIMS::operator[](int i)
{
 #ifdef DEBUG_TG
  if((i < 1) || (i > grad-1))
   {
    FatalMess("SIMS::operator[] mit falschem Index\n");
    exit(0);
   }
 #endif

 return(transv[i]);
}


void SIMS::operator=(LABRA_TG &G)
{
 int i,j,k,l,m;

 #ifdef DEBUG_TG
  if(grad != G.Dim())
   {
    FatalMess("SIMS-operator= with different dimensions\n");
    exit(0);   
   }
 #endif

 for(i=1;i<=grad;i++)
  basis[i]=G.pi(i);

 for(i=1;i<=grad-1;i++)
  {
   if(! transv.IsAlloc(i))
    transv.Add(i,3);
   transv[i].Used()=0;
   if(! transv[i].IsAlloc(1))
    transv[i].Add(1,grad);
   transv[i].Used()++;
   transv[i][1].Id();
   //Durchlaufe pi(i+1),pi(i+2),...
   for(j=i+1;j<=grad;j++)
    {
     l=j;
     m=0;
     while(G.HV(l) != l)
      {
       if(G.HV(l) == i)
        {
         m=1;
         break;
        }
       l=G.HV(l); 
      }
     if(m == 1)
      {
       transv[i].Used()++;
       if(transv[i].Dim() < transv[i].Used())
        transv[i].ReAlloc(transv[i].Dim()+3); 
       if(! transv[i].IsAlloc(transv[i].Used()))
        transv[i].Add(transv[i].Used(),grad);
       if(G.HV(i) != i)
        { 
         transv[i][transv[i].Used()]=G.EM(basis[i]);
         transv[i][transv[i].Used()].Inv();
        }
       else
        transv[i][transv[i].Used()].Id();

       if(G.HV(j) != j)
        transv[i][transv[i].Used()]*=G.EM(basis[j]);
      } 
    }
  }
}


void SIMS::Scan()
{
 basis.Scan();
 transv.Scan();
}



LANGZAHL* SIMS::Ordnung()
{
 LANGZAHL *L;

 L=new LANGZAHL(1);
 if(L == NULL)
  {
   FatalMess("Kein Speicher bei SIMS::Ordnung\n");
   exit(0);
  } 

 for(int i=1;i <= grad-1;i++)
  (*L)*=transv[i].Used();  

 return(L);
}




void SIMS::Print()
{
 int i,j;

 printf("BASIS=\n");
 basis.Print(0);
 printf("SIMSKETTE=\n");
 for(i=1;i<grad;i++)
  {
   printf("Transversale Nr.%d\n",i);
   for(j=1;j<=transv[i].Used();j++)
    transv[i][j].Print(4);
  }

 fflush(stdout);
}





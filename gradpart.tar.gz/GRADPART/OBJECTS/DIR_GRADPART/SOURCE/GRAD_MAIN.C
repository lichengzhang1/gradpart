#include "../../../gradmain.h"
#include <string.h>

IMPL_DATA a_IMPL;


main(int argc, char* argv[])
{
 GRAD_MAIN a_MAIN;

// printf("\n");
 a_MAIN.StartConstr(argc,argv);
} 




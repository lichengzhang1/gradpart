#include "../../impldata.h"


//int SPLIT_KLEIN,SHIFT_PARTITIONS;

main()
{
 IMPL_DATA   imp;
 LANGZAHL    L1,L2,L3,L4;
 FILE        *fp;
 char        name[100];       
 int i;
 

 fp=NULL;
 while(fp == NULL)
  fp = fopen("./ERG/GESAMT","r"); 
 L1.Scan(fp);
 fclose(fp);

 L1.Print(stdout,0);
 printf(" Loesungen gespeichert\n");
 printf("Welche soll berechnet werden ?\n");
 L2.Scan(stdin);

 if(L2 > L1)
  {
   fprintf(stderr,"zu gross\n");
   exit(0);
  } 
 if(L2 < 1)
  {
   fprintf(stderr,"zu klein\n");
   exit(0);
  } 


 fp=NULL;
 while(fp == NULL)
  fp = fopen("./ERG/ANZAHLEN","r"); 
 i=0;
 while(1)
  {
   L4=L3;
   L3.Scan(fp);
   i++;
   if(L3 >= L2)
    break; 
  }
  
 if(i > 1)
   L2-=L4;

 sprintf(name,"./ERG/dat%d",i);
 fp=NULL;
 while(fp == NULL)
  fp=fopen(name,"r");
 imp.ReadInput(fp);
 fclose(fp);

 imp.Comp_Rep(L2);
 imp.GetNewGraph().Plaziere();
}



#ifndef SIMS_H

#include <unistd.h>
#include "array.t"
#include "vector.t"
#include "permut.t"
#include "langzahl.h"
#include "labra.h"


class SIMS
{
 private:
  ARRAY< ARRAY <PERMUT <short > > >   transv;
  PERMUT<short>			      basis;
  short				      grad;
 public:
                             SIMS() { grad=0; }
		             SIMS(int _grad);

  void                       FREE();
  void                       Init(int _grad); 
  PERMUT<short>&             Base() { return(basis); }

  void                       operator=(LABRA_TG &G);
  ARRAY <PERMUT <short> >&   operator[](int i);
  //Referenz auf die i-te Transversale als Permutationsarray

  void		             Scan();
  LANGZAHL* 		     Ordnung();
  void		             Print();
  int		             Dim() { return(grad); }
};


#define SIMS_H
#endif

#include "math.h"
#include "XDraw.h"


XmStringCharSet gp_cs = "ISOLatin1";
char *the_font = /* "fixed" */ "-misc-fixed-*-*-*-*-15-*-*-*-*-*-*-*" ;

XmFontList fontlist;

#define W_INCH 12
#define H_INCH 6


int main(int argc, char **argv)
{
 int argc1 = (int) argc;
 int i;
 GP_DIAL *dial;
 dial = gl_gp_dial;
 FILE *indicator;
 imp=NULL;
 xcoords=ycoords=NULL;
 vertex_nr=0;
 split_tree_visible=0;
 SplitNr=-1;

 if(argc != 2)
  {
   FatalMess("wrong syntax:\n Type: draw.out 'ergdir'\n");
   exit(0);
  }

 indicator=fopen("Z","w");
 fprintf(indicator,"Draw in action\n");
 fclose(indicator);

 wnd_toplevel = 
  XtVaAppInitialize(&gl_app,"XDRAW",NULL,0,&argc,
                    argv,NULL,
                    NULL);
 XmFontListEntry entry1;

 entry1 = XmFontListEntryLoad(XtDisplay(wnd_toplevel),
          "-*-courier-*-r-*--12-*",XmFONT_IS_FONT,"TAG1");
 fontlist = XmFontListAppendEntry(NULL,entry1);
 XmFontListEntryFree(&entry1);


 GetColors();
 CreateWidgets();

 strcpy(ergdir,argv[1]);
 Lese_anz_und_degree_part(1);

 XtRealizeWidget(wnd_toplevel);
 XtAppMainLoop(gl_app);

 return(0);
}


void Lese_anz_und_degree_part(int datnr)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 char hilf[500]; 
 char *anz; 
 XmString str = (XmString) NULL;
 int i,j,k;

 if(imp != NULL)
  {
   delete imp;
   imp=NULL;
  }

 strcpy(hilf,"./");
 strcat(hilf,ergdir);
 strcat(hilf,"/GESAMT");

 i=0;
 fp=NULL;
 while(fp == NULL)
  {
   i++;
   fp = fopen(hilf,"r");
   if(i == 1000)
    {
     FatalMess("draw.out: Bad directory !!\n");
     exit(0);
    }
  }
 L1.Scan(fp);
 fclose(fp);

 anz = L1.StrPrint(); 

 sprintf(hilf,"Number of stored graphs: %s",anz);
 str=XmStringCreateLocalized(hilf);
 XtVaSetValues(dial->anz_label,
        XmNlabelString,str,
        NULL);
 XmStringFree(str); 
 delete anz;

 //now read degree-partition

 sprintf(hilf,"./%s/dat%d",ergdir,datnr);
 fp=NULL;
 i=0;
 while(fp == NULL)
  {
   if(i==3000)
    {
     char hilf3[300];
     sprintf(hilf3,"Can't open %s",hilf);
     ErrorMessage(hilf3); 
     exit(0);
    }
   fp = fopen(hilf,"r");
   i++;
  }

  
 imp=new IMPL_DATA;
 (*imp).ReadInput(fp);
 fclose(fp);


 if(xcoords==NULL)
  {
   xcoords=new short[(*imp).GetGraph().Dim()+1];
   if(xcoords==NULL)
    {
     FatalMess("mwmory exceeede in XDraw\n");
     exit(0);
    }  
   ycoords=new short[(*imp).GetGraph().Dim()+1];
   if(ycoords==NULL)
    {
     FatalMess("mwmory exceeede in XDraw\n");
     exit(0);
    }  
  }

 short *grade;
 grade=new short[(*imp).GetGraph().Dim()+1];
 for(i=1;i<=(*imp).GetGraph().Dim();i++)
  grade[i]=0;
 if(grade==NULL)
  {
   FatalMess("memory exceeded in XDraw.C::Lese_anz_und_degree_part\n");
   exit(0);
  }
 for(i=1;i<=(*imp).GetGraph().Dim();i++)
  {
   for(j=1;j<=(*imp).GetGraph().GetNBList()[i].Used();j++)
    {
     grade[i] += (*imp).GetGraph().GetNBWert()[i][j];
     grade[(*imp).GetGraph().GetNBList()[i][j]] += 
                 (*imp).GetGraph().GetNBWert()[i][j];
    }
  } 

 int maxgrad=0;
 short partition[500];
 for(i=0;i<500;i++)
  partition[i]=0;

 for(i=1;i<=(*imp).GetGraph().Dim();i++)
  {
   partition[grade[i]]++;
   if(grade[i] > maxgrad)
    maxgrad=grade[i];
  } 


 char hilf2[50];
 strcpy(hilf,"degree partition: ");
 for(j=0;j<=maxgrad;j++)
  {
   if(partition[j] > 0)
    {
     sprintf(hilf2,"%dx%d ",partition[j],j);
     strcat(hilf,hilf2);
    }
  }

 str=XmStringCreateLocalized(hilf);
 XtVaSetValues(dial->dp_label,
        XmNlabelString,str,
        XmNfontList,fontlist,
        NULL);
 XmStringFree(str);
 delete[] grade;
}



void GetColors()
{

 Colormap cmap = DefaultColormapOfScreen(XtScreen(wnd_toplevel));
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,AppCol,
                       &exact,&Appcolor))
  {
   FatalMess("Couldn't XAlloc Appcolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,FrameCol,
                       &exact,&Framecolor))
  {
   FatalMess("Couldn't XAlloc Framecolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,SelectCol,
                       &exact,&Selectcolor))
  {
   FatalMess("Couldn't XAlloc Selectcolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,ButtonCol,
                       &exact,&Buttoncolor))
  {
   FatalMess("Couldn't XAlloc Buttoncolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,ErrCol,
                       &exact,&ErrorColor))
  {
   FatalMess("Couldn't XAlloc Errorcolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,DrawBackCol,
                       &exact,&DrawBackColor))
  {
   FatalMess("Couldn't XAlloc Errorcolor!!\n");
  // exit(1);
  }
}



void Read(Widget W,XtPointer client_data,XtPointer call_data)
{
 XmTextVerifyCallbackStruct *cbs=
  (XmTextVerifyCallbackStruct*) call_data;

 if(cbs->text->ptr == NULL)
  {
  // FatalMess("nothing typed\n");
   return;
  }

 int i;
 for(i=0;i<cbs->text->length;i++)
  {
   if(! isdigit(cbs->text->ptr[i]))
    {
     cbs->doit=False;
     ErrorMessage(3);
     return;
    }
  }

}



void redraw(Widget drawing_a, void *client_data_, void *call_data)
{
 XtPointer client_data = (XtPointer) client_data_;
 XmDrawingAreaCallbackStruct *cbs = (XmDrawingAreaCallbackStruct *)call_data;

 XCopyArea(cbs->event->xexpose.display, pixmap, cbs->window, gc,
        0, 0, width, height, 0, 0);
}



void set_color(Widget widget, void *client_data, void *call_data)
{
     String color = (String) client_data;

    Display *dpy = XtDisplay(widget);
    Colormap cmap = DefaultColormapOfScreen(XtScreen(widget));
    XColor col, unused;
    
    if (!XAllocNamedColor(dpy, cmap, color, &col, &unused)) {
        char buf[32];
        FatalMess("Couldn't XAlloc Color\n");
        sprintf(buf, "Can't alloc %s", color);
        XtWarning(buf);
        return;
    }
    XSetForeground(dpy, gc, col.pixel);
}




void CreateWidgets()
{
 int i,j;
 GP_DIAL *dial;
 XmString str = (XmString) NULL;
 
 gl_gp_dial = (GP_DIAL *) malloc(sizeof(GP_DIAL));
 if (gl_gp_dial == NULL)
  {
   printf("i_km_dlg() no memory for gp_dial\n");
   fflush(stdout);
  }
 dial = gl_gp_dial;

 gp_fnt = XLoadQueryFont(XtDisplay(wnd_toplevel), the_font);
 gp_font1 = XmFontListCreate(gp_fnt, gp_cs);
 gp_curfont = gp_font1;


 dial->all_form = 
  XtVaCreateManagedWidget("all_form",
            xmFormWidgetClass,wnd_toplevel, 
            XmNbuttonFontList,fontlist,
            NULL);

 gcv.foreground = WhitePixelOfScreen(XtScreen(dial->all_form));
 gc = XCreateGC(XtDisplay(dial->all_form),
                RootWindowOfScreen(XtScreen(dial->all_form)), 
                GCForeground, &gcv);


 dial->input_form =  
  XtVaCreateManagedWidget("input_form",
            xmFormWidgetClass,dial->all_form,
            XmNtopAttachment,XmATTACH_FORM,
            XmNleftAttachment,XmATTACH_FORM,
            XmNrightAttachment,XmATTACH_FORM,
            XmNfractionBase, 1000,
            XmNbackground,Appcolor.pixel,
            NULL);


 dial->dp_frame =
  XtVaCreateManagedWidget("dp_frame",xmFrameWidgetClass,
           dial->input_form,
           XmNtopAttachment,XmATTACH_FORM,
           XmNleftAttachment,XmATTACH_FORM,
           XmNrightAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_POSITION,
           XmNbottomPosition,250,
           XmNbackground,Framecolor.pixel,
           NULL);

 dial->dp_form =  
  XtVaCreateManagedWidget("dp_form",
            xmFormWidgetClass,dial->dp_frame,
            XmNbackground,Appcolor.pixel,
            NULL);


 str=XmStringCreateLocalized("degree partition: ");
 dial->dp_label =
  XtVaCreateManagedWidget("dp_label",
           xmLabelWidgetClass,dial->dp_form,
           XmNleftAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNlabelString, str,
           XmNbackground,Appcolor.pixel,
           XmNfontList,fontlist,
           NULL);
 XmStringFree(str);


 dial->anz_frame =
  XtVaCreateManagedWidget("anz_frame",xmFrameWidgetClass,
           dial->input_form,
           XmNtopAttachment,XmATTACH_POSITION,
           XmNtopPosition,250,
           XmNleftAttachment,XmATTACH_FORM,
           XmNrightAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_POSITION,
           XmNbottomPosition,500,
           XmNbackground,Framecolor.pixel,
           NULL);

 dial->anz_form =  
  XtVaCreateManagedWidget("anz_form",
            xmFormWidgetClass,dial->anz_frame,
            XmNbackground,Appcolor.pixel,
            NULL);


 str=XmStringCreateLocalized("Number of stored graphs: ");
 dial->anz_label =
  XtVaCreateManagedWidget("anz_label",
           xmLabelWidgetClass,dial->anz_form,
           XmNleftAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNlabelString, str,
           XmNbackground,Appcolor.pixel,
           XmNfontList,fontlist,
           NULL);
 XmStringFree(str);


 dial->select_frame =
  XtVaCreateManagedWidget("select_frame",xmFrameWidgetClass,
           dial->input_form,
           XmNtopAttachment,XmATTACH_POSITION,
           XmNtopPosition,500,
           XmNleftAttachment,XmATTACH_FORM,
           XmNrightAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_POSITION,
           XmNbottomPosition,750,
           XmNbackground,Framecolor.pixel,
           NULL);



 dial->select_form =  
  XtVaCreateManagedWidget("select_form",
            xmFormWidgetClass,dial->select_frame,
            XmNleftAttachment,XmATTACH_FORM,
            XmNrightAttachment,XmATTACH_FORM,
            XmNtopAttachment,XmATTACH_FORM,
            XmNbottomAttachment,XmATTACH_FORM,
            XmNbackground,Appcolor.pixel,
            NULL);

 str=XmStringCreateLocalized("Your selection: ");
 dial->select_label =
  XtVaCreateManagedWidget("select_label",
           xmLabelWidgetClass,dial->select_form,
           XmNlabelString, str,
           XmNleftAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNbackground,Appcolor.pixel,
           XmNfontList,fontlist,
           NULL); 
 XmStringFree(str);

 dial->number_text =
  XtVaCreateManagedWidget("number_text",
           xmTextFieldWidgetClass,dial->select_form,
           XmNtraversalOn,      True,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNrightAttachment,XmATTACH_FORM,
           XmNleftAttachment,XmATTACH_WIDGET,
           XmNleftWidget,dial->select_label,
           XmNbackground,Appcolor.pixel,
           XmNfontList,fontlist,
           NULL); 
 XtAddCallback(dial->number_text,XmNmodifyVerifyCallback,Read,
               NULL);


 dial->button_frame =
  XtVaCreateManagedWidget("button_frame",xmFrameWidgetClass,
           dial->input_form,
           XmNtopAttachment,XmATTACH_WIDGET,
           XmNtopWidget,dial->number_text,
           XmNleftAttachment,XmATTACH_FORM,
           XmNrightAttachment,XmATTACH_FORM,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNbackground,Framecolor.pixel,
           NULL);

 dial->button_fr_form =
  XtVaCreateManagedWidget("button_fr_form",xmFormWidgetClass,
           dial->button_frame,
           XmNfractionBase, 1000,
           XmNbackground,Appcolor.pixel,
           NULL);

 dial->quit_button =
  XtVaCreateManagedWidget("quit",xmPushButtonWidgetClass,
           dial->button_fr_form,
           XmNleftAttachment,XmATTACH_POSITION,
           XmNleftPosition,50,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbackground,Buttoncolor.pixel,
           NULL);

  XtAddCallback(dial->quit_button,
               XmNactivateCallback,
               quit_button_callback,
               NULL);



 str=XmStringCreateLocalized("depth: ");
 dial->depth_label =
  XtVaCreateManagedWidget("depth_label",
           xmLabelWidgetClass,dial->button_fr_form,
           XmNlabelString, str,
           XmNleftAttachment,XmATTACH_POSITION,
           XmNleftPosition,150,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbackground,Appcolor.pixel,
           XmNfontList,fontlist, 
           NULL);
 XmStringFree(str); 


 dial->draw_button =
  XtVaCreateManagedWidget("draw",xmPushButtonWidgetClass,
           dial->button_fr_form,
           XmNleftAttachment,XmATTACH_POSITION,
           XmNleftPosition,280,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbackground,Buttoncolor.pixel,
           NULL);

 XtAddCallback(dial->draw_button,
           XmNactivateCallback,
           draw_button_callback,
           NULL);


 dial->split_line_button =
  XtVaCreateManagedWidget("Hide Lines",xmPushButtonWidgetClass,
           dial->button_fr_form,
           XmNleftAttachment,XmATTACH_POSITION,
           XmNleftPosition,370,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbackground,Buttoncolor.pixel,
           NULL);
 
 XtAddCallback(dial->split_line_button,
               XmNactivateCallback,
               split_line_button_callback,
               NULL);
 SHOW_LINES=1;


 dial->split_tree_button =
  XtVaCreateManagedWidget("split-tree",xmPushButtonWidgetClass,
           dial->button_fr_form,
           XmNleftAttachment,XmATTACH_POSITION,
           XmNleftPosition,550,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbackground,Buttoncolor.pixel,
           NULL);
 
 XtAddCallback(dial->split_tree_button,
               XmNactivateCallback,
               split_tree_button_callback,
               NULL);


 dial->down_button =
  XtVaCreateManagedWidget("down",xmPushButtonWidgetClass,
           dial->button_fr_form,
           XmNleftAttachment,XmATTACH_POSITION,
           XmNleftPosition,800,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbackground,Buttoncolor.pixel,
           NULL);

 XtAddCallback(dial->down_button,
               XmNactivateCallback,
               down_button_callback,
               NULL);


 dial->up_button =
  XtVaCreateManagedWidget("up",xmPushButtonWidgetClass,
           dial->button_fr_form,
           XmNleftAttachment,XmATTACH_POSITION,
           XmNleftPosition,910,
           XmNbottomAttachment,XmATTACH_FORM,
           XmNtopAttachment,XmATTACH_FORM,
           XmNbackground,Buttoncolor.pixel,
           NULL);

 XtAddCallback(dial->up_button,
               XmNactivateCallback,
               up_button_callback,
               NULL);

 dial->draw_form =
  XtVaCreateManagedWidget("draw_form",
            xmFormWidgetClass,dial->all_form,
            XmNtopAttachment,XmATTACH_WIDGET,
            XmNtopWidget,dial->input_form,
            XmNleftAttachment,XmATTACH_FORM,
            XmNrightAttachment,XmATTACH_FORM,
            XmNbottomAttachment,XmATTACH_FORM,
            XmNbackground,Appcolor.pixel,
            NULL);


 dial->scroll_win =
  XtVaCreateManagedWidget("scroll_win",
        xmScrolledWindowWidgetClass, dial->draw_form,
        XmNscrollingPolicy,        XmAUTOMATIC,
        XmNscrollBarDisplayPolicy, XmAS_NEEDED,
        XmNtopAttachment,          XmATTACH_FORM,
        XmNbottomAttachment,       XmATTACH_FORM,
        XmNleftAttachment,         XmATTACH_FORM,
        XmNrightAttachment,        XmATTACH_FORM,
        NULL);

 actions.string = "draw";
 actions.proc = draw;
 XtAppAddActions(gl_app, &actions, 1);


 dial->draw_win =
  XtVaCreateManagedWidget("draw_win",
        xmDrawingAreaWidgetClass, dial->scroll_win,
        XmNtranslations, XtParseTranslationTable(translations),
        XmNunitType,     Xm1000TH_INCHES,
        XmNwidth,        W_INCH * 1000, 
        XmNheight,       H_INCH * 1000,
        XmNbackground,DrawBackColor.pixel,
        NULL);

  XtAddCallback(dial->draw_win, XmNexposeCallback, redraw, NULL);

  XtVaSetValues(dial->draw_win, XmNunitType, XmPIXELS, NULL);
  XtVaGetValues(dial->draw_win, XmNwidth, &width, XmNheight, &height, NULL);
  pixmap = XCreatePixmap(XtDisplay(dial->draw_win),
        RootWindowOfScreen(XtScreen(dial->draw_win)), width, height,
        DefaultDepthOfScreen(XtScreen(dial->draw_win)));
  set_color(dial->draw_win,"grey93",NULL);
  XFillRectangle(XtDisplay(dial->draw_win), pixmap, gc, 0, 0, width, height);

  XtVaSetValues(dial->scroll_win,
                XmNwidth,width+4,
                XmNheight,height+4,
                NULL);

  XtAddEventHandler(wnd_toplevel,StructureNotifyMask,False,
                    configure,NULL); 


 XtManageChild(dial->draw_win);
 XtManageChild(dial->scroll_win);
 XtManageChild(dial->draw_form);
 XtManageChild(dial->down_button);
 XtManageChild(dial->up_button);
 XtManageChild(dial->split_line_button);
 XtManageChild(dial->draw_button);
 XtManageChild(dial->depth_label);
 XtManageChild(dial->quit_button);
 XtManageChild(dial->button_fr_form);
 XtManageChild(dial->button_frame);
 XtManageChild(dial->number_text);
 XtManageChild(dial->select_label);
 XtManageChild(dial->select_form);
 XtManageChild(dial->select_frame);
 XtManageChild(dial->anz_label);
 XtManageChild(dial->anz_form);
 XtManageChild(dial->anz_frame);
 XtManageChild(dial->dp_label);
 XtManageChild(dial->dp_form);
 XtManageChild(dial->dp_frame);
 XtManageChild(dial->input_form);
 XtManageChild(dial->all_form);

 
 }



void configure(Widget shell,XtPointer client_data,
               XEvent *event,char *p)
{
 XConfigureEvent *cevent= (XConfigureEvent*) event;
 if(cevent->type != ConfigureNotify)
  return;
 XtVaSetValues(shell,
               XmNmaxWidth,cevent->width,
               XmNmaxHeight,cevent->height,
               NULL);
 XtRemoveEventHandler(shell,StructureNotifyMask,False,configure,NULL);

}



void ErrorMessage(int i)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

  dial->error_dialog_shell=
   XtCreateWidget("Input Error",
                  xmDialogShellWidgetClass,
                  wnd_toplevel,
                  NULL,0);
  str=XmStringCreateLocalized(err_string[i]);
  dial->error_dialog =
   XtVaCreateManagedWidget("error_dialog",xmMessageBoxWidgetClass,
                   dial->error_dialog_shell,
                   XmNdialogType,XmDIALOG_ERROR,
                   XmNbackground,ErrorColor.pixel,
                   XmNmessageString,str,
                   NULL);
   XmStringFree(str);

   XtManageChild(dial->error_dialog);
   XtManageChild(dial->error_dialog_shell);
   XtUnmanageChild(XmMessageBoxGetChild(dial->error_dialog,
                                        XmDIALOG_CANCEL_BUTTON));
   XtUnmanageChild(XmMessageBoxGetChild(dial->error_dialog,
                                        XmDIALOG_HELP_BUTTON));
   XtAddCallback(dial->error_dialog,XmNokCallback,
                 error_dialog_callback,NULL);
}



void ErrorMessage(char *mess)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

  dial->error_dialog_shell=
   XtCreateWidget("Input Error",
                  xmDialogShellWidgetClass,
                  wnd_toplevel,
                  NULL,0);
  str=XmStringCreateLocalized(mess);
  dial->error_dialog =
   XtVaCreateManagedWidget("error_dialog",xmMessageBoxWidgetClass,
                   dial->error_dialog_shell,
                   XmNdialogType,XmDIALOG_ERROR,
                   XmNbackground,ErrorColor.pixel,
                   XmNmessageString,str,
                   NULL);
   XmStringFree(str);

   XtManageChild(dial->error_dialog);
   XtManageChild(dial->error_dialog_shell);
   XtUnmanageChild(XmMessageBoxGetChild(dial->error_dialog,
                                        XmDIALOG_CANCEL_BUTTON));
   XtUnmanageChild(XmMessageBoxGetChild(dial->error_dialog,
                                        XmDIALOG_HELP_BUTTON));
   XtAddCallback(dial->error_dialog,XmNokCallback,
                 error_dialog_callback,NULL);
}



void error_dialog_callback(Widget w,
                 XtPointer client_data,
                 XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;

 XtDestroyWidget(dial->error_dialog);
 XtDestroyWidget(dial->error_dialog_shell);

}



void quit_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;

 unlink("Z");
 if(split_tree_visible)
  {
   split_tree_visible=0;
   for(int i=0;i<=tree_button_anz;i++)
    XtDestroyWidget(dial->tree_buttons[i]);
   delete[] dial->tree_buttons; 
   delete[] inf_point;
   XtDestroyWidget(dial->tree_draw_area);
   XtDestroyWidget(dial->tree_draw_scroll);
   XtDestroyWidget(dial->tree_draw_form);
   XtDestroyWidget(dial->w_scale);
   XtDestroyWidget(dial->h_scale);
   XtDestroyWidget(dial->scale_form);
   XtDestroyWidget(dial->tree_form);
   XtDestroyWidget(dial->split_tree_dialog);
  } 
 exit(0);
}


void up_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 if(TIEFE < MAXTIEFE)
  {
   TIEFE++;
   ZeichneGraphLocal();
   char he[30];
   sprintf(he,"depth: %d",TIEFE);
   XmString str = (XmString) NULL;
   str=XmStringCreateLocalized(he);
   XtVaSetValues(dial->depth_label,
       XmNlabelString,str,
       NULL);
   XmStringFree(str);
  }
}



void down_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 if(TIEFE > 1)
  {
   TIEFE--;
   ZeichneGraphLocal();
   char he[30];
   sprintf(he,"depth: %d",TIEFE);
   XmString str = (XmString) NULL;
   str=XmStringCreateLocalized(he);
   XtVaSetValues(dial->depth_label,
       XmNlabelString,str,
       NULL);
   XmStringFree(str);
  } 
}


void split_line_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

 if(SHOW_LINES==1)
  {
   SHOW_LINES=0;
   str=XmStringCreateLocalized("Show Lines");
   XtVaSetValues(dial->split_line_button,
       XmNlabelString,str,
       NULL);
   XmStringFree(str);
   ZeichneGraphLocal();
  }
 else
  {
   SHOW_LINES=1;
   str=XmStringCreateLocalized("Hide Lines");
   XtVaSetValues(dial->split_line_button,
       XmNlabelString,str,
       NULL);
   XmStringFree(str);
   ZeichneGraphLocal();
  }
}




void DrawTree(Widget drawing_a, void *client_data_, void *call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;
 int i,j,k,l,m,io,jo;
 Dimension w,h;

 if(split_tree_visible==0)
  {
   Dimension _w,_h;
   Position _j,_k;
   for(i=0;i<=tree_button_anz;i++)
    {
     XtVaGetValues(dial->tree_buttons[i],
                   XmNx,&_j,
                   XmNy,&_k,
                   NULL);
     io=(_w*_j) / old_tree_area_w;
     jo=(_h*_k) / old_tree_area_h;    
     if(io==0)io=1;
     if(jo==0)jo=1;
     for(j=0;j<i;j++)
      {
       Dimension D;
       Position P1,P2;
       XtVaGetValues(dial->tree_buttons[j],
                     XmNx,&P1,
                     XmNy,&P2,
                     XmNwidth,&D,
                     NULL);
       if(P2 ==  _k)             
        {
         if(P1 + D > _j)
          {
           k=P1+D+2;
           XtVaSetValues(dial->tree_buttons[i],
                         XmNx,k,NULL); 
          }
        }
      }
    } 
  }  

 XtVaGetValues(dial->tree_draw_area,
             XmNwidth,&w,
             XmNheight,&h, 
             NULL);
 XSetForeground(XtDisplay(dial->tree_draw_area),
                gc,WhitePixelOfScreen(XtScreen(dial->tree_draw_area)));
 XFillRectangle(XtDisplay(dial->tree_draw_area),
                XtWindow(dial->tree_draw_area),
                gc,0,0,w,h); 


 Dimension _w,_h;
 Position _j,_k;
 XtVaGetValues (dial->tree_draw_area,
                XmNwidth,&_w,
                XmNheight,&_h,
                NULL);
 for(i=0;i<=tree_button_anz;i++)
  {
   XtVaGetValues(dial->tree_buttons[i],
                 XmNx,&_j,
                 XmNy,&_k,
                 NULL);
   io=(_w*_j) / old_tree_area_w;
   jo=(_h*_k) / old_tree_area_h;    
   if(io==0)io=1;
   if(jo==0)jo=1;
   XtMoveWidget(dial->tree_buttons[i],
                (Position)io,
                (Position)jo);

  }
 old_tree_area_w=_w; 
 old_tree_area_h=_h; 

 Dimension x1,x2,y1,y2;
 Dimension i1,i2,i3,i4;
 set_color(dial->tree_draw_area,"black",NULL);
 for(i=1;i<=tree_button_anz;i++)
  {
   XtVaGetValues(dial->tree_buttons[tree_vater[i]],
                 XmNwidth,&i1, 
                 XmNheight,&i2, 
                 XmNx,&i3,
                 XmNy,&i4,
                 NULL);
   x1 = i3 + i1/2;
   y1 = i4 + i2;

   XtVaGetValues(dial->tree_buttons[i],
                 XmNwidth,&i1, 
                 XmNheight,&i2, 
                 XmNx,&i3,
                 XmNy,&i4,
                 NULL);
   x2 = i3 + i1/2;
   y2 = i4;

   XDrawLine(XtDisplay(dial->tree_draw_area),
           XtWindow(dial->tree_draw_area),gc,x1,y1,x2,y2);
 
  }
  

 split_tree_visible=1;	 
}



/*-------------------------------------------------------------
**	ValueCB		- callback for scales
*/
static void ValueCB (Widget w, XtPointer client_data, 
                     XtPointer call_data) 
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;
 int i;
    
    Arg args[5];	
    int	n ;		   
    int value ;
    Widget workarea = (Widget) client_data ;

    /* get the value out of the Scale */
    n = 0;
    XtSetArg (args[n], XmNvalue, &value);  n++;
    XtGetValues (w, args, n);

    n = 0;

    XtVaGetValues(workarea,
                  XmNheight,&old_tree_area_h,
                  XmNwidth,&old_tree_area_w,
                  NULL);

    if (strcmp(XtName(w), "w_scale") == 0 ) 
     { /* width scale */
	XtSetArg (args[n], XmNwidth, value);  n++;
	i=old_tree_area_w-value;
	if((i < 20)&&(i > -20))
	 return;
     } 
    else 
     {
	XtSetArg (args[n], XmNheight, value);  n++;
	i=old_tree_area_h-value;
	if((i < 20)&&(i > -20))
	 return;
     }
    XtSetValues (workarea, args, n);
    DrawTree(dial->tree_draw_area,NULL,NULL);
}




void split_tree_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;
 Arg args[15];
 static short degrees[500];
 static short dp[500];
 char s[200],s2[50];
 int n,i,j,k,l,m,io,jo;
 int maxtiefe;
 short last_x[100],last_nr[100];
 Dimension di1,di2;


 if(split_tree_visible==0)
  {
   n = 0;
   XtSetArg(args[n], XmNx, (Dimension) 100); n++;
   XtSetArg(args[n], XmNy, (Dimension) 100); n++;

   dial->split_tree_dialog =
    XtAppCreateShell("tree_dialog","TREE",
                     topLevelShellWidgetClass,
                     XtDisplay(dial->all_form),
                     args,n);
                     

   dial->tree_form=
    XtVaCreateManagedWidget("tree_form",xmFormWidgetClass,
		     dial->split_tree_dialog,
		     XmNtopAttachment,XmATTACH_FORM,
		     XmNleftAttachment,XmATTACH_FORM,
		     XmNrightAttachment,XmATTACH_FORM,
		     XmNbottomAttachment,XmATTACH_FORM,
		     XmNfractionBase, 100,
		     XmNbackground,Appcolor.pixel,
		     NULL);


   dial->scale_form=
     XtVaCreateManagedWidget("scale_form",xmFormWidgetClass,
		     dial->tree_form,
		     XmNtopAttachment,XmATTACH_FORM,
		     XmNleftAttachment,XmATTACH_FORM,
		     XmNrightAttachment,XmATTACH_FORM,
		     XmNfractionBase, 100,
		     XmNbackground,Appcolor.pixel,
		     NULL);

   dial->tree_draw_form=
    XtVaCreateManagedWidget("tree_draw_form",xmFormWidgetClass,
		     dial->tree_form,
		     XmNleftAttachment,XmATTACH_FORM,
		     XmNrightAttachment,XmATTACH_FORM,
		     XmNbottomAttachment,XmATTACH_FORM,
		     XmNtopAttachment,XmATTACH_WIDGET,
		     XmNtopWidget,dial->scale_form,
		     XmNbackground,DrawBackColor.pixel,
		     NULL);

   dial->tree_draw_scroll =
    XtVaCreateManagedWidget("tree_draw_scroll",
	  xmScrolledWindowWidgetClass, dial->tree_draw_form,
	  XmNscrollingPolicy,        XmAUTOMATIC,
	  XmNscrollBarDisplayPolicy, XmAS_NEEDED,
          XmNwidth,700, 
          XmNheight,700,
	  XmNtopAttachment,          XmATTACH_FORM,
	  XmNbottomAttachment,       XmATTACH_FORM,
	  XmNleftAttachment,         XmATTACH_FORM,
	  XmNrightAttachment,        XmATTACH_FORM,
	  NULL);

 dial->tree_draw_area =
  XtVaCreateManagedWidget("tree_draw_area",
        xmDrawingAreaWidgetClass, dial->tree_draw_scroll,
        XmNwidth,        1500, 
        XmNheight,       1000,
        XmNresizePolicy,XmRESIZE_NONE,
        NULL);
  old_tree_area_w=1500;
  old_tree_area_h=1000;
		
  XtAddCallback(dial->tree_draw_area, XmNexposeCallback, DrawTree, NULL);
		       
   str=XmStringCreateLocalized("width");
   n = 0;
   XtSetArg (args[n], XmNorientation, XmHORIZONTAL);  n++;
   XtSetArg (args[n], XmNshowValue, True);  n++;
   XtSetArg (args[n], XmNminimum, 500);  n++;
   XtSetArg (args[n], XmNmaximum, 5000);  n++;
   XtSetArg (args[n], XmNvalue, 1000);  n++;
   XtSetArg (args[n], XmNleftAttachment,XmATTACH_FORM); n++;
   XtSetArg (args[n], XmNrightAttachment,XmATTACH_FORM); n++;
   XtSetArg (args[n], XmNtopAttachment,XmATTACH_FORM); n++;
   XtSetArg (args[n], XmNbackground,Appcolor.pixel); n++;
   XtSetArg (args[n], XmNtitleString,str); n++;
   XtSetArg (args[n], XmNfontList,fontlist ); n++;
   dial->w_scale = XmCreateScale(dial->scale_form, "w_scale", args, n);
   XmStringFree(str);

   XtAddCallback(dial->w_scale,XmNvalueChangedCallback,ValueCB,
		 (XtPointer)dial->tree_draw_area);

   str=XmStringCreateLocalized("height");
   n = 0;
   XtSetArg (args[n], XmNorientation, XmHORIZONTAL);  n++;
   XtSetArg (args[n], XmNshowValue, True);  n++;
   XtSetArg (args[n], XmNminimum, 500);  n++;
   XtSetArg (args[n], XmNmaximum, 5000);  n++;
   XtSetArg (args[n], XmNvalue, 1000);  n++;
   XtSetArg (args[n], XmNleftAttachment,XmATTACH_FORM); n++;
   XtSetArg (args[n], XmNrightAttachment,XmATTACH_FORM); n++;
   XtSetArg (args[n], XmNbottomAttachment,XmATTACH_FORM); n++;
   XtSetArg (args[n], XmNtopAttachment,XmATTACH_WIDGET); n++;
   XtSetArg (args[n], XmNtopWidget,dial->w_scale); n++;
   XtSetArg (args[n], XmNbackground,Appcolor.pixel); n++;
   XtSetArg (args[n], XmNtitleString,str); n++;
   XtSetArg (args[n], XmNfontList,fontlist ); n++;
   dial->h_scale = XmCreateScale(dial->scale_form, "h_scale", args, n);
   XmStringFree(str);

   XtAddCallback(dial->h_scale,XmNvalueChangedCallback,ValueCB,
		 (XtPointer)dial->tree_draw_area);

   //buttons allokieren, positionieren und managen

   (*imp).GetNewGraph().GetSplitTree().wlrStart();
   maxtiefe=0;
   tree_button_length=0;
   while(! (*imp).GetNewGraph().GetSplitTree().IsLast())
    {
     SPLITINFO& SI=(*imp).GetNewGraph().GetSplitTree().Next();
     if(SI.tiefe > maxtiefe)
      maxtiefe=SI.tiefe; 
     tree_button_length++; 
    } 
   dial->tree_buttons = new Widget[tree_button_length+1];
   if(dial->tree_buttons==NULL)
    {
     FatalMess("memory exceeded in XDraw::DrawTree\n");
     exit(0);
    }

   tree_button_anz=-1;
   inf_point=new SPLITINFO*[tree_button_length+1];
   if(inf_point==NULL)
    {
     FatalMess("memory exceeded in XDraw::DrawTree\n");
     exit(0);
    }

   (*imp).GetNewGraph().GetSplitTree().wlrStart();
   while(! (*imp).GetNewGraph().GetSplitTree().IsLast())
    {
     SPLITINFO& SI=(*imp).GetNewGraph().GetSplitTree().Next();
     for(i=1;i<=SI.dim;i++)degrees[i]=0;
     m=0;
     for(i=1;i<=SI.dim;i++)
      {
       for(j=1;j<=SI.NBlist[i].Used();j++)
        {
         degrees[i]+=SI.NBwert[i][j];
         m=(degrees[i] > m)?degrees[i]:m;
         degrees[SI.NBlist[i][j]]+=SI.NBwert[i][j];
         m=(degrees[SI.NBlist[i][j]] > m)?degrees[SI.NBlist[i][j]]:m;
        }
      }  
     for(i=0;i<=m;i++)
      dp[i]=0;
     for(i=1;i<=SI.dim;i++)
      dp[degrees[i]]++;
     i=0;
     strcpy(s,"");
     for(j=0;j<=m;j++)
      {
       if(dp[j] > 0)
        {
         sprintf(s2,"%dx%d ",dp[j],j);
         strcat(s,s2);
        }
      }

     tree_button_anz++;
     inf_point[tree_button_anz]=&SI;

     XtVaGetValues (dial->tree_draw_area,
                    XmNwidth,&di1,
                    XmNheight,&di2,
                    NULL);

     k = ((int)((SI.tiefe * di2) / (maxtiefe+1.5)));
     if(SI.tiefe==1)
      {
       l = di1/3;
       last_x[1]=l;
       last_nr[1]=0;
       tree_vater[0]=0;
      } 
     else
      {
       l=last_x[SI.tiefe-1];
       tree_vater[tree_button_anz] = last_nr[SI.tiefe-1];
       SPLITINFO* SI2=(*imp).GetNewGraph().GetSplitTree().VaterVonNext();
       if(SI.first_col_nr==SI2->first_col_nr)
         l-=di2 /(SI.tiefe+2);  
       else
         l+=di2 /(SI.tiefe+2);  
       last_x[SI.tiefe]=l;
       last_nr[SI.tiefe]=tree_button_anz;
      }  
     dial->tree_buttons[tree_button_anz] =
       XtVaCreateManagedWidget(s,xmPushButtonWidgetClass,
           dial->tree_draw_area,
           XmNx,l,
           XmNy,k,
           XmNbackground,Buttoncolor.pixel,
           XmNfontList,fontlist,
           NULL);
     XtAddCallback(dial->tree_buttons[tree_button_anz],
                   XmNactivateCallback,
                   tree_button_callback,
                   (XtPointer)tree_button_anz);
     //tree_button_anz as client_data to identify the button
     XtManageChild(dial->tree_buttons[tree_button_anz]); 

    }
    
   XtManageChild(dial->tree_draw_area);
   XtManageChild(dial->tree_draw_scroll);
   XtManageChild(dial->tree_draw_form);
   XtManageChild(dial->w_scale);
   XtManageChild(dial->h_scale);
   XtManageChild(dial->scale_form);
   XtManageChild(dial->tree_form);
//   XtManageChild(dial->split_tree_dialog);

   XtRealizeWidget(dial->split_tree_dialog);

   str=XmStringCreateLocalized("close split-tree");
   XtVaSetValues(dial->split_tree_button,
                 XmNlabelString,str,
                 NULL);
   XmStringFree(str);
  }
 else
  {
   str=XmStringCreateLocalized("split-tree");
   XtVaSetValues(dial->split_tree_button,
                 XmNlabelString,str,
                 NULL);
   XmStringFree(str);
   split_tree_visible=0;
   for(i=0;i<=tree_button_anz;i++)
    XtDestroyWidget(dial->tree_buttons[i]);
   delete[] dial->tree_buttons; 
   delete[] inf_point;
   XtDestroyWidget(dial->tree_draw_area);
   XtDestroyWidget(dial->tree_draw_scroll);
   XtDestroyWidget(dial->tree_draw_form);
   XtDestroyWidget(dial->w_scale);
   XtDestroyWidget(dial->h_scale);
   XtDestroyWidget(dial->scale_form);
   XtDestroyWidget(dial->tree_form);
   XtDestroyWidget(dial->split_tree_dialog);
   SplitNr=-1;
  }
}



void tree_button_callback(Widget w,XtPointer client_data,   
                               XtPointer call_data)         
{
 int nr = (int)client_data;
 GP_DIAL *dial;
 dial = gl_gp_dial;

 TIEFE=inf_point[nr]->tiefe;
 char he[30];
 sprintf(he,"depth: %d",TIEFE);
 XmString str = (XmString) NULL;
 str=XmStringCreateLocalized(he);
 XtVaSetValues(dial->depth_label,
               XmNlabelString,str, NULL);
 XmStringFree(str);

 SplitNr=nr;
 ZeichneGraphLocal();
}



void draw_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 char *anz;

 anz=XmTextGetString(dial->number_text);
 if(strlen(anz)==0)
  {
   ErrorMessage(0);
   delete anz;
   return;
  }   
 L2.StrScan(anz);

 if(L2 > L1)
  {
   ErrorMessage(2L);
   delete anz;
   return;
  }
 if(L2 < 1)
  {
   ErrorMessage(1L);
   delete anz;
   return;
  }

 char mess[100];
 int i,j,k;
 i=0;
 fp=NULL;
 char in[200];
 strcpy(in,"./");
 strcat(in,ergdir);
 strcat(in,"/ANZAHLEN");
 while(fp == NULL)
  {
   if(i==1000)
    {
     sprintf(mess,"Can't open %s",in);
     ErrorMessage(mess);
     delete anz;
     return;
    }
   fp = fopen(in,"r");
   i++;
  }

 i=0;
 while(1)
  {
   L4=L3;
   L3.Scan(fp);
   i++;
   if(L3 >= L2)
    break;
  }

 if(i > 1)
   L2-=L4;
fclose(fp);

 Lese_anz_und_degree_part(i);
 (*imp).Comp_Rep(L2);
 (*imp).GetNewGraph().Plaziere(); 
 
 ZeichneGraph(1);
 TIEFE=1;

 char he[30];
 sprintf(he,"depth: %d",TIEFE);
 XmString str = (XmString) NULL;
 str=XmStringCreateLocalized(he);
 XtVaSetValues(dial->depth_label,
     XmNlabelString,str,
     NULL);
 XmStringFree(str);

 delete anz;
}





void ZeichneGraphLocal()
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 int i,j,k,l,m,x1,x2,y1,y2;
 char *flag;
 int nr=SplitNr;
 int vielf;
 double Lx,Ly,L;

 if(nr >= 0)
  {
   flag=new char[(*imp).GetNewGraph().Dim()+1];
   if(flag==NULL)
    {
     FatalMess("memory exceeded in ZeichneGraphLocal\n");
     exit(0);
    }
   for(i=1;i<=(*imp).GetNewGraph().Dim();i++)
    flag[i]=0;
   for(i=1;i<=inf_point[nr]->dim;i++)
    flag[inf_point[nr]->global_nr[i]]=1;
  }
 MAXTIEFE=(*imp).GetNewGraph().MaxTiefe();

 set_color(dial->draw_win,"grey93",NULL);
 XFillRectangle(XtDisplay(dial->draw_win),pixmap,gc,0,0,width,height);
 set_color(dial->draw_win,"black",NULL);
 k=(*imp).GetNewGraph().Dim();
 for(i=1;i<=k;i++)
  {
   for(j=1;j<=(*imp).GetNewGraph().GetNBList()[i].Used();j++)
    {
     l=(*imp).GetNewGraph().GetNBList()[i][j];
     vielf = (*imp).GetNewGraph().GetNBWert()[i][j];
     if((*imp).GetNewGraph().GetSplitTiefe()[i][l] >= TIEFE)
      {
       x1=xcoords[i];
       x2=xcoords[l];
       y1=ycoords[i];
       y2=ycoords[l];
       if(nr >= 0)
        {
         if((flag[i]) && (flag[l]))
          set_color(dial->draw_win,"orange",NULL);
         else
          set_color(dial->draw_win,"black",NULL);
        }
       Lx = y1-y2; Ly = x2-x1;
       L = Lx*Lx + Ly*Ly;
       L = sqrt(L);
       Lx = Lx*4/L;
       Ly = Ly*4/L;
       int start_x1,start_y1,start_x2,start_y2;
       if(vielf % 2 == 0)
        {
         start_x1 = x1 - (int)(((vielf/2 - 1)+0.5)*Lx); 
         start_x2 = x2 - (int)(((vielf/2 - 1)+0.5)*Lx); 
         start_y1 = y1 - (int)(((vielf/2 - 1)+0.5)*Ly); 
         start_y2 = y2 - (int)(((vielf/2 - 1)+0.5)*Ly); 
        }
       else
        {
         start_x1 = x1 - (int)(((vielf-1)/2)*Lx); 
         start_x2 = x2 - (int)(((vielf-1)/2)*Lx); 
         start_y1 = y1 - (int)(((vielf-1)/2)*Ly); 
         start_y2 = y2 - (int)(((vielf-1)/2)*Ly); 
        }      
       for(int _k=1;_k<=vielf;_k++)
        { 
         XDrawLine(XtDisplay(dial->draw_win),pixmap,gc,
                   (int)(start_x1+(_k-1)*Lx),
                   (int)(start_y1+(_k-1)*Ly),
                   (int)(start_x2+(_k-1)*Lx),
                   (int)(start_y2+(_k-1)*Ly)); 
        } 
      }
    }
  }

 for(i=1;i<=k;i++)
  {
   x1=xcoords[i];
   y1=ycoords[i];
   if(x1 > 3)
    x1-=3;
   else
    x1=0;
   if(y1 > 3)
    y1-=3;
   else
    y1=0;
   if(nr >= 0)
    {   
     if(flag[i])
      set_color(dial->draw_win,"orange",NULL);
     else
      set_color(dial->draw_win,"black",NULL);
    }
   XDrawArc(XtDisplay(dial->draw_win),pixmap,gc,x1,y1,6,6,0,23049);
   XFillArc(XtDisplay(dial->draw_win),pixmap,gc,x1,y1,6,6,0,23049);
  }

 if(SHOW_LINES)
  {
   set_color(dial->draw_win,"red",NULL);
   for(i=1;i<=(*imp).GetNewGraph().LineAnz();i++)
    {
     if((*imp).GetNewGraph().LineTiefe()[i] <= TIEFE+1)
      {
       x1=((*imp).GetNewGraph().SplLineX1()[i]*width)/1000;
       x2=((*imp).GetNewGraph().SplLineX2()[i]*width)/1000;
       y1=((*imp).GetNewGraph().SplLineY1()[i]*height)/1000;
       y2=((*imp).GetNewGraph().SplLineY2()[i]*height)/1000;
       XDrawLine(XtDisplay(dial->draw_win),pixmap,gc,x1,y1,x2,y2);
      }
    }
  } 


 XCopyArea(XtDisplay(dial->draw_win),pixmap,XtWindow(dial->draw_win),
           gc,0,0,width,height,0,0);
 if(SplitNr >= 0)
  delete[] flag;          
}




void ZeichneGraph(int tiefe)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 int i,j,k,l,m,x1,x2,y1,y2;
 int vielf;
 double Lx,Ly,L;

 MAXTIEFE=(*imp).GetNewGraph().MaxTiefe();

 set_color(dial->draw_win,"grey93",NULL);
 XFillRectangle(XtDisplay(dial->draw_win),pixmap,gc,0,0,width,height);
 set_color(dial->draw_win,"black",NULL);
 k=(*imp).GetNewGraph().Dim();
 for(i=1;i<=k;i++)
  {
   for(j=1;j<=(*imp).GetNewGraph().GetNBList()[i].Used();j++)
    {
     l=(*imp).GetNewGraph().GetNBList()[i][j];
     vielf = (*imp).GetNewGraph().GetNBWert()[i][j];
     if((*imp).GetNewGraph().GetSplitTiefe()[i][l] >= tiefe)
      {
       x1=((*imp).GetNewGraph().XCoord()[i]*width)/1000;
       x2=((*imp).GetNewGraph().XCoord()[l]*width)/1000;
       y1=((*imp).GetNewGraph().YCoord()[i]*height)/1000;
       y2=((*imp).GetNewGraph().YCoord()[l]*height)/1000;
       Lx = y1-y2; Ly = x2-x1;
       L = Lx*Lx + Ly*Ly;
       L = sqrt(L);
       Lx = Lx*4/L;
       Ly = Ly*4/L;
       int start_x1,start_y1,start_x2,start_y2;
       if(vielf % 2 == 0)
        {
         start_x1 = x1 - (int)(((vielf/2 - 1)+0.5)*Lx); 
         start_x2 = x2 - (int)(((vielf/2 - 1)+0.5)*Lx); 
         start_y1 = y1 - (int)(((vielf/2 - 1)+0.5)*Ly); 
         start_y2 = y2 - (int)(((vielf/2 - 1)+0.5)*Ly); 
        }
       else
        {
         start_x1 = x1 - (int)(((vielf-1)/2)*Lx); 
         start_x2 = x2 - (int)(((vielf-1)/2)*Lx); 
         start_y1 = y1 - (int)(((vielf-1)/2)*Ly); 
         start_y2 = y2 - (int)(((vielf-1)/2)*Ly); 
        }      
       for(int _k=1;_k<=vielf;_k++)
        { 
         XDrawLine(XtDisplay(dial->draw_win),pixmap,gc,
                   (int)(start_x1+(_k-1)*Lx),
                   (int)(start_y1+(_k-1)*Ly),
                   (int)(start_x2+(_k-1)*Lx),
                   (int)(start_y2+(_k-1)*Ly)); 
        } 
      }
    }
  }

 for(i=1;i<=k;i++)
  {
   x1=((*imp).GetNewGraph().XCoord()[i]*width)/1000;
   y1=((*imp).GetNewGraph().YCoord()[i]*height)/1000;
   if(x1 > 3)
    x1-=3;
   else
    x1=0;
   if(y1 > 3)
    y1-=3;
   else
    y1=0;
   xcoords[i]=x1; 
   ycoords[i]=y1; 
   XDrawArc(XtDisplay(dial->draw_win),pixmap,gc,x1,y1,6,6,0,23049);
   XFillArc(XtDisplay(dial->draw_win),pixmap,gc,x1,y1,6,6,0,23049);
  }

 if(SHOW_LINES)
  {
   set_color(dial->draw_win,"red",NULL);
   for(i=1;i<=(*imp).GetNewGraph().LineAnz();i++)
    {
     if((*imp).GetNewGraph().LineTiefe()[i] <= tiefe+1)
      {
       x1=((*imp).GetNewGraph().SplLineX1()[i]*width)/1000;
       x2=((*imp).GetNewGraph().SplLineX2()[i]*width)/1000;
       y1=((*imp).GetNewGraph().SplLineY1()[i]*height)/1000;
       y2=((*imp).GetNewGraph().SplLineY2()[i]*height)/1000;
       XDrawLine(XtDisplay(dial->draw_win),pixmap,gc,x1,y1,x2,y2);
      }
    }
  } 


 XCopyArea(XtDisplay(dial->draw_win),pixmap,XtWindow(dial->draw_win),
           gc,0,0,width,height,0,0);

}



//zum Veraendern der Koordinaten mit der Maus
void draw(Widget W,XEvent *event,String *args, unsigned int *num_args)
{
 XButtonEvent *bevent=(XButtonEvent*)event;
 int i,j1,j2,k;

 if(strcmp(args[0],"up")==0)
  {
   vertex_nr=0;
   return;
  }
 if(strcmp(args[0],"down")==0)
  {
   k=(*imp).GetNewGraph().Dim();
   for(i=1;i<=k;i++)
    {
     j1=xcoords[i]-bevent->x;
     j2=ycoords[i]-bevent->y;
     if(((j1 < 10)&&(j1 > -10))&&
        ((j2 < 10)&&(j2 > -10)))
       {
        //Knoten i angeklickt
        vertex_nr=i;
        return;
       }  
    }
  }
 if(strcmp(args[0],"motion")==0)
  {
   if(vertex_nr != 0)
    {
     //d.h. Knoten angeklickt
     j1=xcoords[vertex_nr]-bevent->x;
     j2=ycoords[vertex_nr]-bevent->y;
     if(j1 || j2)
       {
        xcoords[vertex_nr]=bevent->x;
        ycoords[vertex_nr]=bevent->y;
        ZeichneGraphLocal();
       }
    }
  }
}








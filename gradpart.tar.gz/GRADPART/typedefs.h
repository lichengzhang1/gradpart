//#ifdef AROM_LIB
typedef unsigned char       BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      USHORT;
typedef unsigned long       ULONG;
#define TRUE  1
#define FALSE 0
//#endif


#include "gradpart.h"
#include "defs.h"
#include "impldata.h"


extern IMPL_DATA a_IMPL;
GRADPART *ACTUAL_GRAD;


void GRADPART::Init()
{
 int i,j;

 if(0)
  {
   printf("GRADPART::Init, tiefe=%d ",TIEFE);
   if(GIRTH > 3)printf("GIRTH=%d a = ",GIRTH);
   if(TREES_ONLY)printf("TREES_ONLY, a = ");
   for(i=0;i<=a.Used();i++)
    printf("%d ",a[i]);
   printf("\n");	
   fflush(stdout);
  }
  
 if(VERBOSE)
  {
   printf("Hier GRADPART::Init mit tiefe=%d\n a = ",TIEFE);
   for(i=0;i<=a.Used();i++)
    printf("%d ",a[i]);
   printf("\n");
   if(ONLY_CONN_GRAPHS)
    printf("CONNECTED !!\n");
   if(IMP_IF_CONN)
    printf("IMP_IF_CONN !!\n"); 
  }

 m=a.Used();
 while(a[m] == 0)
  m--;

 dim=0;
 for(i=0;i<=m;i++)
  dim+=a[i];

 b.SetAb0();
 c.SetAb0();
 b.ReAlloc(m);
 c.ReAlloc(m);

 _H.ReAlloc(m);
 _T.ReAlloc(m);
 _HT.ReAlloc(m+1);
 Compute_H_T(); 

 c_i_j.SetAb0();
 b_i_j.SetAb0();
 c_i_j.REALLOC(m,m); 
 b_i_j.REALLOC(m,m); 
 for(i=0;i<=m;i++)
  {
   b_i_j[i].SetAb0();
   c_i_j[i].SetAb0();
  } 

 NBlist.REALLOC(dim,m);
 NBdummy.REALLOC(dim,m);
 NBwert.REALLOC(dim,m);
 NBrestr.REALLOC(dim,m+1);

 l_dim=0;
 for(i=1;i<=_H.Used();i++)
  l_dim+=a[_H[i]]; 

 r_dim=0;
 for(i=1;i<=_T.Used();i++)
  r_dim+=a[_T[i]]; 

 z_sums.ReAlloc(dim);
 first=1;
 first_split = 1;
 LOESUNG_ANZ=0;
 
 if(L_GRAD == NULL)
  L_GRAD=new GRADPART;
 if(L_GRAD == NULL)
  {
   FatalMess("no memory in GRADPART::Init\n");
   exit(0);
  } 
 if(R_GRAD == NULL)
  R_GRAD=new GRADPART;
 if(R_GRAD == NULL)
  {
   FatalMess("no memory in GRADPART::Init\n");
   exit(0);
  }

 SPLITS_UNTIL_NOW=0;
 PRINT_SPLITS_UNTIL_NOW=0;
}


GRADPART::GRADPART()
{
 dim=0;  L_GRAD=R_GRAD=NULL;
 ONLY_CRITICAL = 0;
}


GRADPART::~GRADPART()
{
 if(L_GRAD)delete L_GRAD;
 if(R_GRAD)delete R_GRAD;
}

void GRADPART::SetCRITICAL(int CR_GR)
{
 ONLY_CRITICAL = 1;
 CRITICAL_GRAD = CR_GR;
}




void GRADPART::FREE()
{
 a.FREE();
 b.FREE();
 c.FREE();
 _H.FREE();
 _T.FREE();
 _HT.FREE();
 c_i_j.FREE();
 b_i_j.FREE();
 L_MULT.FREE(); 
 R_MULT.FREE(); 
 if(L_GRAD != NULL)
  L_GRAD->FREE();
 if(R_GRAD != NULL)
  R_GRAD->FREE();
 DNK.FREE();
 KOORD.FREE();
 z_sums.FREE();
 I_Sum.FREE();
 if(L_GRAD)delete L_GRAD;
 if(R_GRAD)delete R_GRAD;
 L_GRAD=R_GRAD=NULL;
 l_impli.FREE();
 r_impli.FREE();
 NBlist.FREE();
 NBdummy.FREE();
 NBwert.FREE();
 NBrestr.FREE();
 H_VER_LAB.FREE();
}


void GRADPART::EnableSPLIT_MAX()
{
 SPLIT_MAX=1;
 SPLIT_MIDDLE=0;
 SPLIT_50_50=0;
}

 
void GRADPART::EnableSPLIT_MIDDLE()
{
 SPLIT_MAX=0;
 SPLIT_MIDDLE=1;
 SPLIT_50_50=0;
}


void GRADPART::EnableSPLIT_50_50()
{
 SPLIT_MAX=0;
 SPLIT_MIDDLE=0;
 SPLIT_50_50=1;
}



LABRA_TG& GRADPART::GetAUT()
{
 if((Is_H_Verteilung())||(TREES_ONLY==1))
  return(H_VER_LAB);
 else 
  return(KOORD.GetAut());
}


int GRADPART::ImplDurchlauf()
{
 if(GO_IMPL==0)
  return(0);

 if(TREES_ONLY)
   return(1);
 if(GIRTH > 3)
  {
   if((!Is_H_Verteilung())||(GIRTH_AND_IMPL == 0))
    return(0);
  }
 if(ONLY_CONN_GRAPHS)
  {
   if(CONN_AND_IMPL) return(1);
   else return(0); 
  }
 else
  { 
   if((IMP_IF_CONN==0)||
      ((IMP_IF_CONN==1)&&(CONN_AND_IMPL==1)))
    return(1);
   else
    return(0);
  } 
}


void GRADPART::Compute_H_T()
{
 int i,j,k;

 //Notice: _H and _T have to be in ascending order

 if(ONLY_CRITICAL)
  {
   _T.Used()=1;
   _T[1]=m;
   _H.Used()=0;
   for(i=0;i < m;i++)
    _H[++_H.Used()]=i;
   goto SPLIT_END;
  }

 if(TREES_ONLY)
  {
   _T.Used() = 1;
   _T[1]=1;
   _H.Used() = 0;
   for(i=0;i<=m;i++)
    if(i != _T[1])
     _H[++_H.Used()] = i;
   goto SPLIT_END;
  }   

 if((ONLY_CONN_GRAPHS)||(GIRTH > 3))
  {
   _T.Used() = 1;
   if(a[1] > 0)
    _T[1]=1;
   else
    {
     i=0;
     while(a[i]==0)i++;
     for(j=i+1;j<=m;j++)
      if((a[j] <= a[i])&&(a[j] > 0))
       i=j;
     _T[1] = i;  
    }  
   _H.Used() = 0;
   for(i=0;i<=m;i++)
    if(i != _T[1])
     _H[++_H.Used()] = i;
   goto SPLIT_END;
  }


 if(SPLIT_MAX)
  {
   _T.Used()=1;
   _T[1]=m;
   _H.Used()=0;
   for(i=0;i < m;i++)
    _H[++_H.Used()]=i;
  }

 if(SPLIT_MIDDLE)
  {
   i=j=m/2;
   while(1)
    {
     if(a[j] == 0)
      {
       if(j == i)    
        j++;
       else
        {
         if(j > i)
          j=2*i-j;
         else
          j=2*i-j+1;
        }
      }
     else
      {
       _T.Used()=1;
       _T[1]=j;

       _H.Used()=0;
       for(i=0;i <= m;i++)
        {
         if(i != j)
          _H[++_H.Used()]=i;
        }
       goto SPLIT_END;
      }
    }
  }

 if(SPLIT_50_50)
  {
   k=j=0;
   _T.Used()=0;
   _H.Used()=0;
   for(i=0;i<=m;i++)
    {
     if(j==0)goto J;
     if(k==0)goto K;
     if(((i%2==0)&&(j+a[i]<=dim/2+1))||
        ((i%2!=0)&&(k+a[i] > dim/2+1)))
      {
       J:
       _T[++_T.Used()]=i;
       j+=a[i];
      }
     else
      {
       K:
       _H[++_H.Used()]=i;
       k+=a[i];
      }
    }
  }

 SPLIT_END:

 _HT.Clear();
 for(i=1;i<=_H.Used();i++)
  _HT.Set(_H[i]+1);

 if(VERBOSE)
  {
   printf("_H= ");
   _H.PrintUsed(0);
   printf("_T= ");
   _T.PrintUsed(0);
  }

}



void GRADPART::SaveSplitTree()
{
 int i;

if(VERBOSE)
 printf("SaveSplitTree mit tiefe=%d\n",TIEFE);

 if(TIEFE == 1)
  a_IMPL.GetGraph().Init(l_dim,1);

 SPLITINFO *spl;
 spl=new SPLITINFO(dim);
 if(spl==NULL)
  {
   FatalMess("memory exceeded in GRADPART::SaveSplitTree\n");
   exit(0);
  }
 spl->tiefe=TIEFE;
 spl->first_col_nr=FIRST_COL_NR;
 spl->l_dim=l_dim;
 spl->is_split=1;
 spl->split_left.Used()=0;
 spl->split_left.ReAlloc(_H.Used());
 for(i=1;i<=_H.Used();i++)
  spl->split_left[++spl->split_left.Used()]=_H[i];
 spl->split_right.ReAlloc(_T.Used());
 spl->split_right.Used()=0;
 for(i=1;i<=_T.Used();i++)
  spl->split_right[++spl->split_right.Used()]=_T[i];
 a_IMPL.GetGraph().Insert(spl);

 if(! go_L_MULT)
  L_GRAD->SaveSplitTree();
 else
  {
   spl=new SPLITINFO(l_dim);
   if(spl==NULL)
    {
     FatalMess("memory exceeded in GRADPART::SaveSplitTree\n");
     exit(0);
    }
   spl->tiefe=TIEFE+1;
   spl->first_col_nr=FIRST_COL_NR;
   spl->is_split=0;
   a_IMPL.GetGraph().Insert(spl);
  }    

 if(! go_R_MULT)
  R_GRAD->SaveSplitTree();
 else
  {
   spl=new SPLITINFO(dim-l_dim);
   if(spl==NULL)
    {
     FatalMess("memory exceeded in GRADPART::SaveSplitTree\n");
     exit(0);
    }
   spl->tiefe=TIEFE+1;
   spl->first_col_nr=FIRST_COL_NR+l_dim;
   spl->is_split=0;
   a_IMPL.GetGraph().Insert(spl);
  }    
}



void GRADPART::InitNBRestr()
{
 int i,j,k,l;

 for(i=1;i<=dim;i++)
   NBrestr[i].Used()=0;
 NBrestr.Used()=dim;

 for(i=1;i<=l_dim;i++)
   for(j=1;j<=LeftNBList()[i].Used();j++)
    {
     k = LeftNBList()[i][j];
     NBrestr[i][++NBrestr[i].Used()] = k;
     NBrestr[k][++NBrestr[k].Used()] = i;
    }
 for(i=1;i<=r_dim;i++)
   for(j=1;j<=RightNBList()[i].Used();j++)
    {
     k = RightNBList()[i][j]+l_dim;
     NBrestr[l_dim+i][++NBrestr[l_dim+i].Used()] = k;
     NBrestr[k][++NBrestr[k].Used()] = l_dim+i;
    }
}



void GRADPART::NotiereErg()
{
 int i,j,k;

 if(VERBOSE)
  {
   printf("Hier NotiereErg mit TIEFE=%d \n",TIEFE);
   fflush(stdout);
  }

 if(TIEFE == 1)
  {
   if(ImplDurchlauf())
    {
     a_IMPL.ComputeFak();
     LOESUNG_ANZ+=a_IMPL.GetFak();
    }
   else
    LOESUNG_ANZ += 1;
  }

 for(i=1;i<=l_dim;i++)
   z_sums[i]=Left_Z_SUM(i) + KOORD.Get_z_soll()[i];

 for(i=1;i<=r_dim;i++)
   z_sums[i+l_dim]=Right_Z_SUM(i) + KOORD.Get_sp_soll()[i];

 if(! (Is_H_Verteilung() || TREES_ONLY))
  AUT_IS_ID=KOORD.GetAUT_IS_ID();

 for(i=1;i<=dim;i++)
  {
   NBlist[i].Used()=0;
   NBwert[i].Used()=0;
  } 
 NBlist.Used()=dim;
 NBwert.Used()=dim;

 for(i=1;i<=l_dim;i++)
  {
   for(j=1;j<=LeftNBList()[i].Used();j++)
    {
     NBlist[i][++NBlist[i].Used()] = LeftNBList()[i][j];
      NBwert[i][++NBwert[i].Used()] = LeftNBWert()[i][j];
    }  
  }

 for(i=1;i<=l_dim;i++)
  {
   for(j=1;j<=ConnList()[i].Used();j++)
    {
     NBlist[i][++NBlist[i].Used()] = ConnList()[i][j]+l_dim;
     if(Is_H_Verteilung() || TREES_ONLY)
      NBwert[i][++NBwert[i].Used()] = 1;
     else
      NBwert[i][++NBwert[i].Used()] = KOORD.GetConnWert()[i][j];
    } 
  }

 for(i=1;i<=r_dim;i++)
  {
   for(j=1;j<=RightNBList()[i].Used();j++)
    {
     NBlist[l_dim+i][++NBlist[l_dim+i].Used()] = RightNBList()[i][j]+l_dim;
     NBwert[l_dim+i][++NBwert[l_dim+i].Used()] = RightNBWert()[i][j];
    } 
  }

if(VERBOSE)
 {
  printf("z_sums=\n");
  for(i=1;i<=dim;i++)
   printf("%d ",z_sums[i]);
  printf("\n");
  printf("Hier NotiereErg ENDE\n");
  fflush(stdout);
 }
}


void GRADPART::DeleteImplData()
{
 if(ImplDurchlauf())
  a_IMPL.Del(FIRST_COL_NR,l_dim);
}


void GRADPART::NotiereImplData()
{
 int i,j,k,l,_i,_j;
 VEKTOR < short > dum;

 if(VERBOSE)
   printf("Hier NotiereIMPLData mit TIEFE=%d\n",TIEFE);

 if(ImplDurchlauf())
  {
   a_IMPL.Init(FIRST_COL_NR,l_dim);
   i=0;
   for(j=0;j<=m;j++)
    {
     if(c[j] != 0)
      {
       l=0;
       for(k=1;k<=l_dim;k++)
        if((Left_Z_SUM(k) == j)&&(l_impli[k] == 0))
         l++;
       if(l > 0)
        {
         i++;
         if(l < c[j])
          {
           if(VERBOSE)
            printf("c[%d]=%d l=%d i=%d p_i_j=%d\n",
                    j,c[j],l,i,DNK.Getp_i_j()[i].Used());
            
           dum.ReAlloc(DNK.Getp_i_j()[i].Used());
           for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
            dum[_i]=DNK.Getp_i_j()[i][_i];
           for(_i=1;_i<=DNK.Getp_i()[i];_i++)
            dum[DNK.GetErg(i,_i)]--;
           _j=0;
           for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
            if(dum[_i] > 0)
             _j++;
           if(_j > 1)
            { 
             if(VERBOSE)
              printf("impl-Schritt gefunden\n");
             
             a_IMPL.Set_n(c[j]-l);
             _j=0; 
             for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
              if(dum[_i] > 0)
               _j++;
             a_IMPL.Set_k(_j);
             _j=0; 
             for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
              if(dum[_i] > 0)
               {
                _j++;
                a_IMPL.Set_n_i(_j,dum[_i]);
               }
             a_IMPL.Set_ch_rows(1);
             a_IMPL.Set_ab(FIRST_COL_NR+l_dim);
             a_IMPL.Setr_dim(r_dim);
             _i=0;
             for(k=1;k<=l_dim;k++)
              {
               if((Left_Z_SUM(k) == j)&&(l_impli[k] == 1))
                {
                 _i++;
                 a_IMPL.Set_idx(_i,FIRST_COL_NR+k-1);
                } 
              }  
            }  
          }
        }
       else
        {
         if(VERBOSE)
          printf("c[%d]=%d l=0 -> alles implizit\n",j,c[j]);

         l=0;
         for(k=1;k<=_H.Used();k++)
          if((j <= _H[k])&&(c_i_j[_H[k]][_H[k]-j] > 0))
           l++; 
         if(l > 1)
          {
           if(VERBOSE)
            printf("impl-Schritt gefunden\n");
          a_IMPL.Set_n(c[j]);
          l=0;
          for(k=1;k<=_H.Used();k++)
           if((j <= _H[k])&&(c_i_j[_H[k]][_H[k]-j] > 0))
            l++; 
          a_IMPL.Set_k(l);
          l=0;
          for(k=1;k<=_H.Used();k++)
           {
            if((j <= _H[k])&&(c_i_j[_H[k]][_H[k]-j] > 0))
             {
              l++; 
              a_IMPL.Set_n_i(l,c_i_j[_H[k]][_H[k]-j]);
             }
           }   
          a_IMPL.Set_ch_rows(1);
          a_IMPL.Set_ab(FIRST_COL_NR+l_dim);
          a_IMPL.Setr_dim(r_dim);
          _i=0;
          for(k=1;k<=l_dim;k++)
           {
            if(Left_Z_SUM(k) == j)
              a_IMPL.Set_idx(++_i,FIRST_COL_NR+k-1);
           } 
         }  
       }
     }
   }
   for(j=0;j<=m;j++)
    {
     if(b[j] != 0)
      {
       l=0;
       for(k=1;k<=r_dim;k++)
        if((Right_Z_SUM(k) == j)&&(r_impli[k] == 0))
         l++;
       if(l > 0)
        {
         i++;
         if(l < b[j])
          {
           if(VERBOSE)
            printf("b[%d]=%d l=%d i=%d p_i_j=%d\n",
                    j,b[j],l,i,DNK.Getp_i_j()[i].Used());

           dum.ReAlloc(DNK.Getp_i_j()[i].Used());
           for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
            dum[_i]=DNK.Getp_i_j()[i][_i];
           for(_i=1;_i<=DNK.Getp_i()[i];_i++)
            dum[DNK.GetErg(i,_i)]--;
           _j=0;
           for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
            if(dum[_i] > 0)
             _j++;
           if(_j > 1)
            {  
             if(VERBOSE)
               printf("impl-Schritt gefunden\n");
             a_IMPL.Set_n(b[j]-l);
             _j=0; 
             for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
              if(dum[_i] > 0)
               _j++;
             a_IMPL.Set_k(_j);
             _j=0; 
             for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
              if(dum[_i] > 0)
               {
                _j++;
                a_IMPL.Set_n_i(_j,dum[_i]);
               }
             a_IMPL.Set_ch_rows(0);
             a_IMPL.Set_ab(FIRST_COL_NR+l_dim-1);
             a_IMPL.Setr_dim(r_dim);
             _i=0;
             for(k=1;k<=r_dim;k++)
              {
               if((Right_Z_SUM(k) == j)&&(r_impli[k] == 1))
                {
                 _i++;
                 a_IMPL.Set_idx(_i,FIRST_COL_NR+l_dim+k-1);
                } 
              }  
            }  
          }
        }
       else
        {
         if(VERBOSE)
          printf("b[%d]=%d l=0 -> alles implizit\n",j,b[j]);

         l=0;
         for(k=1;k<=_T.Used();k++)
         if((j <= _T[k])&&(b_i_j[_T[k]][_T[k]-j] > 0))
          l++; 
         if(l > 1)
          {
           if(VERBOSE)
            printf("impl-Schritt gefunden\n");
           a_IMPL.Set_n(b[j]);
           l=0;
           for(k=1;k<=_T.Used();k++)
            if((j <= _T[k])&&(b_i_j[_T[k]][_T[k]-j] > 0))
             l++; 
           a_IMPL.Set_k(l);
           l=0;
           for(k=1;k<=_T.Used();k++)
            {
             if((j <= _T[k])&&(b_i_j[_T[k]][_T[k]-j] > 0))
              {
               l++; 
               a_IMPL.Set_n_i(l,b_i_j[_T[k]][_T[k]-j]);
              }
            }   
           a_IMPL.Set_ch_rows(0);
           a_IMPL.Set_ab(FIRST_COL_NR+l_dim-1);
           a_IMPL.Setr_dim(r_dim);
           _i=0;
           for(k=1;k<=r_dim;k++)
            {
             if(Right_Z_SUM(k) == j)
              a_IMPL.Set_idx(++_i,FIRST_COL_NR+l_dim+k-1);
            }   
          } 
        }
      }
    }
  }
 if(VERBOSE)
   printf("Hier NotiereIMPLData-Ende mit TIEFE=%d\n",TIEFE);
}



int GRADPART::NextDnkRep()
{
 if(! ImplDurchlauf())
  return(DNK.NextRep());
 else
  { 
   if((LeftAUT_IS_ID())&&(RightAUT_IS_ID()))
    {
     if(first_DNK_rep)
      {
       first_DNK_rep=0;
       return(1);
      }
     else
      return(0); 
    }
   else
    return(DNK.NextRep()); 
  }
}


//evtl. kann CONN_AND_IMPL auf 1 gesetzt werden
void GRADPART::ComputeCONN_AND_IMPL()
{
 if((CONN_AND_IMPL == 0)&&(GO_IMPL)&&
    ((ONLY_CONN_GRAPHS==1)||
     ((ONLY_CONN_GRAPHS==0)&&(IMP_IF_CONN==1))))
  {
   //nur in diesen Faellen wird CONN_AND_IMPL abgefragt
   CONN_TEST a_conn;
   int i,j,k;
   for(i=1;i<=l_dim;i++)
    NBdummy[i].Used() = 0;
   for(i=1;i<=l_dim;i++)
    {
     for(j=1;j<=LeftNBList()[i].Used();j++)
      {
       k = LeftNBList()[i][j];
       NBdummy[i][++NBdummy[i].Used()] = k;
       NBdummy[k][++NBdummy[k].Used()] = i;
      }
    }
   if(a_conn.IsZshg(NBdummy,l_dim,0))
    {  
     for(i=1;i<=_T.Used();i++)
      if(b_i_j[_T[i]][0] > 0)   
       return;
     CONN_AND_IMPL = 1;
    }
  }
}


int GRADPART::NextRep()
{
 if(first==0)
  goto NEXT;

 while(NextSplit())
  {
   InitLeftData();
   NEXT_LEFT_REP:
   while(LeftNextRep())
    {
     if(ONLY_CRITICAL)LeftRepCRITICAL_flag=0;
     InitRightData();
     while(RightNextRep())
      {
       CONN_AND_IMPL = CONN_AND_IMPL_Sp;
       ComputeCONN_AND_IMPL();
       Init_DNK_Data();
       first_DNK_rep=1;
       while(NextDnkRep())
        {
         NotiereImplData();
         Init_KOORD_Data();
         if(IsValidDNK())
          {
           if(ONLY_CRITICAL)LeftRepCRITICAL_flag=1;
           NEXT:
           while(NextKoordRep())
            {
             if(CheckRestrictions())
              {
               NotiereErg();
               first=0;
               return(1);
              } 
            }
           DeleteImplData(); 
          }
        } 
       if((ONLY_CRITICAL)&&(LeftRepCRITICAL_flag==0))
        goto NEXT_LEFT_REP;
      }
    }
  }
 return(0);  
}




int GRADPART::IsValidDNK()
{
 if(ONLY_CRITICAL)
  {
   int i,j,k;
   int grad1,grad2;
   int v1,v2;
  
   for(i=1;i<=l_dim;i++)
    {
     for(j=1;j<=LeftNBList()[i].Used();j++)
      {
       v1 = i;
       v2 = LeftNBList()[i][j];
       grad1 = Left_Z_SUM(v1) + KOORD.Get_z_soll()[v1];
       grad2 = Left_Z_SUM(v2) + KOORD.Get_z_soll()[v2];
       if(KOORD.Get_z_soll()[v1] < CRITICAL_GRAD-grad2+1)
        return(0);
       if(KOORD.Get_z_soll()[v2] < CRITICAL_GRAD-grad1+1)
        return(0);
      } 
    }
  }
 return(1);
}



int GRADPART::Is_H_Verteilung()
{
 if((_T.Used()==1)&&(_T[1]==1)&&(b_i_j[1][0]==0))
  return(1);
 else
  return(0);
}



int GRADPART::NextKoordRep()
{
 int i,j,k,l,io,jo;

 if((Is_H_Verteilung())||(TREES_ONLY))
  {
   if(H_Verteil_Flag==1)
    {
     H_Verteil_Flag = 0;
     k = 1;
     for(i=1;i<=l_dim;i++)
      if(KOORD.Get_z_soll()[i] > k)
       k = KOORD.Get_z_soll()[i];
     I_ConnList.REALLOC(l_dim,k);
     k = 0;
     for(i=1;i<=l_dim;i++)
      {
       I_ConnList[i].Used() = 0;
       for(j=1;j<=KOORD.Get_z_soll()[i];j++)
        {
         while(KOORD.Get_sp_soll()[k+1] == 0)k++;
         I_ConnList[i][++I_ConnList[i].Used()] = ++k;
        } 
      }  
     //ConnList fuer I gefuellt
     AUT_IS_ID = 1;      
     if( ((LeftAUT_IS_ID())&&(RightAUT_IS_ID()))||
        (DNK.GetAUT_IS_ID() == 1))
      {
       //=> r_dim==1
       return(1);
      }
     else  
      {
       LABRA_TG& L1=H_VER_LAB;
       L1.Init(dim);
       LABRA_TG& L2=DNK.GetAut();
    
       for(i=1;i<=l_dim;i++)
        L1.pi(i) = L2.pi(i);
       for(i=l_dim+1;i<=dim;i++)
        L1.pi(i) = i;
       for(i=1;i<=l_dim;i++)
        {
         if(L2.HV(i) != i)
          {
           //teste, ob dieser Automorphismus auf H zu einem Automorphismus
           //auf dem Gesamtgraphen fortgesetzt werden kann.

           char setze_fort = 1;

           for(j=1;j<=l_dim;j++)
            {
             io = L2.KM(L1.pi(i))[j];
             if( I_ConnList[j].Used() != I_ConnList[io].Used()) 
              { setze_fort = 0; break; }
            } 

           if(setze_fort)
            {
             L1.HV(i) = L2.HV(i);
             AUT_IS_ID = 0;
             for(j=1;j<=l_dim;j++)
              L1.KM(L1.pi(i))[j] = L2.KM(L1.pi(i))[j];
             for(j=l_dim+1;j<=dim;j++)
              L1.KM(L1.pi(i))[j] = j;

             //Setze die Automorphismen von H auf T fort. 
             for(j=1;j<=l_dim;j++)
              {
               if(I_ConnList[j].Used() > 0)
                {
                 if(L1.KM(L1.pi(i))[j] != j)
                  {
                   for(k=1;k<=I_ConnList[j].Used();k++)
                    L1.KM(L1.pi(i))[l_dim+I_ConnList[j][k]] =
                     l_dim+I_ConnList[L1.KM(L1.pi(i))[j]][k];
                  }    
                } 
              } 
            }
           else
            L1.HV(i) = i;
          }
         else
          L1.HV(i) = i;
        }
       
       //diejenigen einwertigen Knoten, die an den gleichen Knoten
       //aus H gebunden sind, sind aequivalent.  		
       for(i=l_dim+1;i<=dim;i++)
        L1.HV(i) = i;
       for(i=1;i<=l_dim;i++)
        {
         if(I_ConnList[i].Used() > 1)
          {
           for(j=1;j < I_ConnList[i].Used();j++)
            {
             AUT_IS_ID = 0;
             k = I_ConnList[i][j];
             L1.HV(l_dim+k+1) = l_dim+k;
             L1.KM(l_dim+k+1).Id();
             L1.KM(l_dim+k+1)[l_dim+k] = l_dim+k+1;
             L1.KM(l_dim+k+1)[l_dim+k+1] = l_dim+k;
            }        
          }                        
        }
       if(! AUT_IS_ID)
        L1.update_eckenmarken();    
       //Automorphismengruppe berechnet

       return(1);
      } 
    }
   else
    return(0);
  }
 else
  {
   ACTUAL_GRAD = this; 
   int _i_ = KOORD.NextRep();
   return(_i_);
  }  
}



ARRAY < VEKTOR < short > >& GRADPART::ConnList()
{
 if((Is_H_Verteilung())||(TREES_ONLY))
  return(I_ConnList);
 else
  return(KOORD.GetConnList());
}



int GRADPART::CheckRestrictions()
{
 int i,j,k,_i,_j;
 

 if(ONLY_CONN_GRAPHS)
  {
   if(CONN_AND_IMPL == 1)
    return(1);
   else
    { 
     //zunaechst Zusammenhang erst im nachhinein testen
    
     for(i=1;i<=dim;i++)
      NBdummy[i].Used()=0;
     NBdummy.Used()=dim;

     for(i=1;i<=l_dim;i++)
      for(j=1;j<=LeftNBList()[i].Used();j++)
       {
        _i = LeftNBList()[i][j];
        NBdummy[i][++NBdummy[i].Used()] = _i;
        NBdummy[_i][++NBdummy[_i].Used()] = i;
       }

     for(i=1;i<=l_dim;i++)
      for(j=1;j<=ConnList()[i].Used();j++)
       {
        _i = ConnList()[i][j]+l_dim;
        NBdummy[i][++NBdummy[i].Used()] = _i;
        NBdummy[_i][++NBdummy[_i].Used()] = i;
       }
 
     for(i=1;i<=r_dim;i++)
      for(j=1;j<=RightNBList()[i].Used();j++)
       {
        _i = RightNBList()[i][j]+l_dim;
        NBdummy[l_dim+i][++NBdummy[l_dim+i].Used()] = _i;
        NBdummy[_i][++NBdummy[_i].Used()] = l_dim+i;
       }

     CONN_TEST a_conn;
     if(a_conn.IsZshg(NBdummy,dim,0))
      return(1);
     else
      return(0);
    }
  }
 else
  return(1);
}



void GRADPART::ComputePossibleSplits()
{
 POSSIBLE_SPLITS=0;
 while(NextSplit())
  {
   POSSIBLE_SPLITS++;
   first_split = 0;
   fprintf(stdout,"\r until now %d splits found",POSSIBLE_SPLITS);
   fflush(stdout);
//   printf("\n");
//   c.PrintAb0(0); 
  }
 fprintf(stdout,"\n");
 Init();
}




void GRADPART::InitLeftData()
{
 int i,j,k;

 i=0;
 while(c[i] == 0)i++;
 j=m;
 while(c[j] == 0)j--;
 if((i==j)||(l_dim < SPLIT_MIN))
  {
   //use L_MULT
   go_L_MULT=1;
   L_MULT.GetDim()=l_dim;
   L_MULT.GetENABLE_AUT()=1;
   L_MULT.GetMAXGRAD()=j;
   L_MULT.GetMAXVAL()=MAX_VAL;
   L_MULT.GetPARTITION().ReAlloc((j < 1)?1:j);
   for(k=1;k<=j;k++)
    L_MULT.GetPARTITION()[k]=c[k];
   if(ONLY_CONN_GRAPHS)
    {
     if((_T.Used()==1)&&(_T[1]==1))
      L_MULT.GetZSHG()=1;
     else
      L_MULT.GetZSHG()=0;
    }
   else
    L_MULT.GetZSHG()=0;
   if(TREES_ONLY)
    L_MULT.GetGirth()=l_dim+1;
   else
    L_MULT.GetGirth()=GIRTH;
   L_MULT.Init();
   L_MULT.ResetTicks();
  }
 else
  {
   //use L_GRAD
   go_L_MULT=0;
   
     if((L_GRAD->GetDim() > 0)&&(L_GRAD->GetDim() != l_dim))
      L_GRAD->FREE();
     L_GRAD->GetPart().ReAlloc((j < 1)?1:j);
     L_GRAD->GetPart().Used()=j;
     L_GRAD->GetPart().SetAb0();
     L_GRAD->GetTIEFE()=TIEFE+1;
     L_GRAD->GetMAXVAL()=MAX_VAL;
     L_GRAD->GetGO_IMPL()=GO_IMPL;
     L_GRAD->GetGIRTH() = GIRTH;
     L_GRAD->GetTREES_ONLY() = TREES_ONLY;
     if((GIRTH_AND_IMPL==0)||(! Is_H_Verteilung()))
      L_GRAD->GetGIRTH_AND_IMPL() = 0;
     else 
      L_GRAD->GetGIRTH_AND_IMPL() = 1;
     if(ONLY_CONN_GRAPHS)
      {
       if((_T[1]==1))
        L_GRAD->GetCONN()=1;
       else
        {
         L_GRAD->GetCONN()=0;
         L_GRAD->GetIMP_IF_CONN() = 1;      
        }
      }
     else
      {
       L_GRAD->GetCONN()=0;
       if(IMP_IF_CONN == 0)
        L_GRAD->GetIMP_IF_CONN() = 0;
       else
        { 
         L_GRAD->GetIMP_IF_CONN() = 1;
         for(k=1;k<=_T.Used();k++)
          if(b_i_j[_T[k]][0] > 0)
           {
            L_GRAD->GetGO_IMPL()=0;
            break; 
           }        
        }
      }
     L_GRAD->GetFIRST_COL_NR()=FIRST_COL_NR;
     for(k=0;k<=j;k++)
      L_GRAD->GetPart()[k]=c[k]; 
     if(SPLIT_MAX == 1)
      L_GRAD->EnableSPLIT_MAX(); 
     if(SPLIT_MIDDLE == 1)
      L_GRAD->EnableSPLIT_MIDDLE(); 
     if(SPLIT_50_50 == 1)
      L_GRAD->EnableSPLIT_50_50(); 
     L_GRAD->Init();

  }
}



void GRADPART::InitRightData()
{
 int i,j,k;

 i=0;
 while(b[i] == 0)i++;
 j=m;
 while(b[j] == 0)j--;
 if((i==j)||(r_dim < SPLIT_MIN))
  {
   //use R_MULT
   go_R_MULT=1;
   R_MULT.GetDim()=r_dim;
   R_MULT.GetENABLE_AUT()=1;
   R_MULT.GetMAXGRAD()=j;
   R_MULT.GetMAXVAL()=MAX_VAL;
   R_MULT.GetPARTITION().ReAlloc((j < 1)?1:j);
   for(k=1;k<=j;k++)
    R_MULT.GetPARTITION()[k]=b[k];
   R_MULT.GetZSHG()=0;
   R_MULT.GetGirth()=GIRTH;
   R_MULT.Init();
   R_MULT.ResetTicks();
  }
 else
  {
   //use R_GRAD
   go_R_MULT=0;
   if((R_GRAD->GetDim() > 0)&&(R_GRAD->GetDim() != r_dim))
    R_GRAD->FREE();
   R_GRAD->GetPart().ReAlloc((j < 1)?1:j);
   R_GRAD->GetPart().Used()=j;
   R_GRAD->GetPart().SetAb0();
   R_GRAD->GetTIEFE()=TIEFE+1;
   R_GRAD->GetMAXVAL()=MAX_VAL;
   if((ONLY_CONN_GRAPHS)||(GIRTH > 3)||(IMP_IF_CONN))
    R_GRAD->GetGO_IMPL()=0;
   else 
    R_GRAD->GetGO_IMPL()=GO_IMPL;
   R_GRAD->GetGIRTH() = GIRTH;
   R_GRAD->GetTREES_ONLY() = TREES_ONLY;
   R_GRAD->GetCONN()=0;
   R_GRAD->GetIMP_IF_CONN() = 0;
   R_GRAD->GetFIRST_COL_NR()=FIRST_COL_NR + l_dim;
   for(k=0;k<=j;k++)
    R_GRAD->GetPart()[k]=b[k]; 
   if(SPLIT_MAX == 1)
    R_GRAD->EnableSPLIT_MAX(); 
   if(SPLIT_MIDDLE == 1)
    R_GRAD->EnableSPLIT_MIDDLE(); 
   if(SPLIT_50_50 == 1)
    R_GRAD->EnableSPLIT_50_50(); 
   R_GRAD->Init();
  }
}


ARRAY < VEKTOR < short > >& GRADPART::LeftNBList()
{
 if(go_L_MULT)
  return(L_MULT.GetNBlist());
 else
  {
   return(L_GRAD->GetNBList());
  } 
}



ARRAY < VEKTOR < short > >& GRADPART::RightNBList()
{
 if(go_R_MULT)
  return(R_MULT.GetNBlist());
 else
  return(R_GRAD->GetNBList());
}


ARRAY < VEKTOR < short > >& GRADPART::LeftNBWert()
{
 if(go_L_MULT)
  return(L_MULT.GetNBwert());
 else
  return(L_GRAD->GetNBWert());
}



ARRAY < VEKTOR < short > >& GRADPART::RightNBWert()
{
 if(go_R_MULT)
  return(R_MULT.GetNBwert());
 else
  return(R_GRAD->GetNBWert());
}


int GRADPART::LeftNextRep()
{
 if(go_L_MULT)
  return(L_MULT.NextRep());
 else
  {
   return(L_GRAD->NextRep());
  } 
}



int GRADPART::RightNextRep()
{
 if(go_R_MULT)
  return(R_MULT.NextRep());
 else
  return(R_GRAD->NextRep());
}



char GRADPART::LeftAUT_IS_ID()
{
 if(go_L_MULT == 1)
  return(L_MULT.GetAUT_IS_ID());
 else
   return(L_GRAD->GetAUT_IS_ID());

}


char GRADPART::RightAUT_IS_ID()
{
 if(go_R_MULT == 1)
  return(R_MULT.GetAUT_IS_ID());
 else
  return(R_GRAD->GetAUT_IS_ID());
}


LABRA_TG& GRADPART::LeftAUT()
{
 if(go_L_MULT == 1)
  return(L_MULT.GetAUT());
 else
  {
   return(L_GRAD->GetAUT());
  } 
}


LABRA_TG& GRADPART::RightAUT()
{
 if(go_R_MULT == 1)
  return(R_MULT.GetAUT());
 else
  return(R_GRAD->GetAUT());
}



int GRADPART::GetZ_SP_SUM(int i)
{
 return(z_sums[i]);
}


int GRADPART::Left_Z_SUM(int i)
{
 if(go_L_MULT == 1)
  return(L_MULT.GetZ_SP_SUM(i));
 else
  {
   return(L_GRAD->GetZ_SP_SUM(i));
  } 
}


int GRADPART::Right_Z_SUM(int i)
{
 if(go_R_MULT == 1)
  return(R_MULT.GetZ_SP_SUM(i));
 else
  return(R_GRAD->GetZ_SP_SUM(i));
}


void GRADPART::Init_DNK_Data()
{
 int i,j,k,l;

 if(VERBOSE)
  {
   printf("GRADPART::Init_DNK_Data mit TIEFE=%d\n",TIEFE);
   printf("l_dim=%d r_dim=%d L_ID=%d R_ID=%d\n",l_dim,r_dim,
   LeftAUT_IS_ID(),RightAUT_IS_ID());
   printf("ImplDurchlauf=%d\n",ImplDurchlauf());
   if(! LeftAUT_IS_ID())
    {
     printf("LeftAUT=\n");
     LeftAUT().Print();
    }
  }

 if(! ImplDurchlauf())
  {
   DNK.GetZei()=dim;
   if(LeftAUT_IS_ID() && RightAUT_IS_ID())
    DNK.GetGROUP_IS_ID()=1;
   else
    {
     DNK.GetGROUP_IS_ID()=0;
     DNK.GetGroup().Init(dim);  
     if(LeftAUT_IS_ID())
      {
       LABRA_TG LA1(l_dim);
       DNK.GetGroup().DirProd(LA1,RightAUT());
      }
     if(RightAUT_IS_ID())
      {
       LABRA_TG LA2(r_dim);
       DNK.GetGroup().DirProd(LeftAUT(),LA2); 
      } 
     if((! LeftAUT_IS_ID())&&(! RightAUT_IS_ID()))
      DNK.GetGroup().DirProd(LeftAUT(),RightAUT());
    }
   DNK.GetPRINT_SOLUTIONS()=0;
   i=0;
   for(j=0;j<=m;j++)
    {
     if(c[j] != 0)i++;
     if(b[j] != 0)i++;
    }
   DNK.Getp_i().ReAlloc(i);
   DNK.Getp_i().Used()=i;
   DNK.Getp_i_j().ReAlloc(i);
   I_Sum.ReAlloc(i);
   DNK.Getp_i_idx().ReAlloc(i);
   i=0;
   for(j=0;j<=m;j++)
    {
     if(c[j] != 0)
      {
       DNK.Getp_i()[++i]=c[j];
       l=0;
       for(k=1;k<=_H.Used();k++)
        if((j <= _H[k])&&(c_i_j[_H[k]][_H[k]-j] > 0))
         l++; 
       if(! DNK.Getp_i_j().IsAlloc(i))
        DNK.Getp_i_j().Add(i,l);
       DNK.Getp_i_j()[i].ReAlloc(l);
       DNK.Getp_i_j()[i].Used()=l;
       if(! I_Sum.IsAlloc(i))
        I_Sum.Add(i,l);
       I_Sum[i].ReAlloc(l);
       l=0;
       for(k=1;k<=_H.Used();k++)
        if((j <= _H[k])&&(c_i_j[_H[k]][_H[k]-j] > 0))
         {
          DNK.Getp_i_j()[i][++l]=c_i_j[_H[k]][_H[k]-j];
          I_Sum[i][l]=_H[k]-j;
         }
       if(! DNK.Getp_i_idx().IsAlloc(i))
        DNK.Getp_i_idx().Add(i,DNK.Getp_i()[i]);
       DNK.Getp_i_idx()[i].ReAlloc(DNK.Getp_i()[i]);
       DNK.Getp_i_idx()[i].Used()=DNK.Getp_i()[i];
       l=0;
       for(k=1;k<=l_dim;k++)
        if(Left_Z_SUM(k) == j)
         DNK.Getp_i_idx()[i][++l]=k;
      }
    }
   for(j=0;j<=m;j++)
    {
     if(b[j] != 0)
      {
       DNK.Getp_i()[++i]=b[j];
       l=0;
       for(k=1;k<=_T.Used();k++)
        if((j <= _T[k])&&(b_i_j[_T[k]][_T[k]-j] > 0))
         l++; 
       if(! DNK.Getp_i_j().IsAlloc(i))
        DNK.Getp_i_j().Add(i,l);
       DNK.Getp_i_j()[i].ReAlloc(l);
       DNK.Getp_i_j()[i].Used()=l;
       if(! I_Sum.IsAlloc(i))
        I_Sum.Add(i,l);
       I_Sum[i].ReAlloc(l);
       l=0;
       for(k=1;k<=_T.Used();k++)
        if((j <= _T[k])&&(b_i_j[_T[k]][_T[k]-j] > 0))
         {
          DNK.Getp_i_j()[i][++l]=b_i_j[_T[k]][_T[k]-j];
          I_Sum[i][l]=_T[k]-j;
         }
       if(! DNK.Getp_i_idx().IsAlloc(i))
        DNK.Getp_i_idx().Add(i,DNK.Getp_i()[i]);
       DNK.Getp_i_idx()[i].ReAlloc(DNK.Getp_i()[i]);
       DNK.Getp_i_idx()[i].Used()=DNK.Getp_i()[i];
       l=0;
       for(k=1;k<=r_dim;k++)
        if(Right_Z_SUM(k) == j)
         DNK.Getp_i_idx()[i][++l]=k+l_dim;
      }
    }
   DNK.Init();
   DNK.BerechneAufteilung();
  }
 else 
  {
   DNK.GetZei()=dim;
   if(! (LeftAUT_IS_ID() && RightAUT_IS_ID()))
    {
     DNK.GetGROUP_IS_ID()=0;
     DNK.GetGroup().Init(dim);  
     if(LeftAUT_IS_ID())
      {
       LABRA_TG LA1(l_dim);
       DNK.GetGroup().DirProd(LA1,RightAUT());
      }
     if(RightAUT_IS_ID())
      {
       LABRA_TG LA2(r_dim);
       DNK.GetGroup().DirProd(LeftAUT(),LA2); 
      } 
     if((! LeftAUT_IS_ID())&&(! RightAUT_IS_ID()))
      DNK.GetGroup().DirProd(LeftAUT(),RightAUT());
    }
   DNK.GetPRINT_SOLUTIONS()=0;

   l_impli.ReAlloc(l_dim);
   l_impli.Clear();
   if(LeftAUT_IS_ID())
    ~l_impli;
   else
    {
     for(j=1;j<=l_dim;j++)
      if(LeftAUT().Stabilizes(j))
       l_impli.Set(j);
    } 
   for(j=1;j<=l_dim;j++)
    {
     if(l_impli[j]==0)
      {
       //wenn j nicht stabilisiert wird, dann koennen alle Zeilen
       //mit der gleichen Summe auch nicht implizit behandelt werden
       for(i=1;i<=l_dim;i++)
        {
         if( Left_Z_SUM(i) == Left_Z_SUM(j))
          l_impli.Reset(i);
        } 
      }
    }
   if(VERBOSE)
    {
     printf("l_impli=\n");
     l_impli.Print(0);
    }  
   i=0;
   for(j=0;j<=m;j++)
    {
     if(c[j] != 0)
      {
       l=0;
       for(k=1;k<=l_dim;k++)
        if((Left_Z_SUM(k) == j)&&(l_impli[k] == 0))
         l++;
       if(VERBOSE)
        printf("c[%d]=%d l=%d\n",j,c[j],l);  
       if(l > 0)
        {
         i++;  
         DNK.Getp_i().ReAlloc(i);
         DNK.Getp_i().Used()=i;
         DNK.Getp_i_j().ReAlloc(i);
         I_Sum.ReAlloc(i);
         DNK.Getp_i_idx().ReAlloc(i);
         DNK.Getp_i()[i]=l;
         l=0;
         for(k=1;k<=_H.Used();k++)
          if((j <= _H[k])&&(c_i_j[_H[k]][_H[k]-j] > 0))
           l++; 
         if(! DNK.Getp_i_j().IsAlloc(i))
          DNK.Getp_i_j().Add(i,l);
         DNK.Getp_i_j()[i].ReAlloc(l);
         DNK.Getp_i_j()[i].Used()=l;
         if(! I_Sum.IsAlloc(i))
          I_Sum.Add(i,l);
         I_Sum[i].ReAlloc(l);
         l=0;
         for(k=1;k<=_H.Used();k++)
          if((j <= _H[k])&&(c_i_j[_H[k]][_H[k]-j] > 0))
           {
            DNK.Getp_i_j()[i][++l]=c_i_j[_H[k]][_H[k]-j];
            I_Sum[i][l]=_H[k]-j;
           }
         if(! DNK.Getp_i_idx().IsAlloc(i))
          DNK.Getp_i_idx().Add(i,DNK.Getp_i()[i]);
         DNK.Getp_i_idx()[i].ReAlloc(DNK.Getp_i()[i]);
         DNK.Getp_i_idx()[i].Used()=DNK.Getp_i()[i];
         l=0;
         for(k=1;k<=l_dim;k++)
         if((Left_Z_SUM(k) == j)&&(l_impli[k] == 0))
          DNK.Getp_i_idx()[i][++l]=k;
        } 
      }
    }
   r_impli.ReAlloc(r_dim);
   r_impli.Clear();
   if(RightAUT_IS_ID())
    ~r_impli;
   else
    {
     for(j=1;j<=r_dim;j++)
      if(RightAUT().Stabilizes(j))
       r_impli.Set(j);
    } 
   for(j=1;j<=r_dim;j++)
    {
     if(r_impli[j]==0)
      {
       for(l=1;l<=r_dim;l++)
        {
         if( Right_Z_SUM(l) == Right_Z_SUM(j))
          r_impli.Reset(l);
        } 
      }
    }
   if(VERBOSE)
    {
     printf("r_impli=\n");
     r_impli.Print(0);
    }  
   for(j=0;j<=m;j++)
    {
     if(b[j] != 0)
      {
       l=0;
       for(k=1;k<=r_dim;k++)
        if((Right_Z_SUM(k) == j)&&(r_impli[k] == 0))
         l++; 
       if(VERBOSE)
        printf("b[%d]=%d l=%d\n",j,b[j],l);  
       if(l > 0)
        {  
         i++;  
         DNK.Getp_i().ReAlloc(i);
         DNK.Getp_i().Used()=i;
         DNK.Getp_i_j().ReAlloc(i);
         I_Sum.ReAlloc(i);
         DNK.Getp_i_idx().ReAlloc(i);
         DNK.Getp_i()[i]=l;
         l=0;
         for(k=1;k<=_T.Used();k++)
          if((j <= _T[k])&&(b_i_j[_T[k]][_T[k]-j] > 0))
           l++; 
         if(! DNK.Getp_i_j().IsAlloc(i))
          DNK.Getp_i_j().Add(i,l);
         DNK.Getp_i_j()[i].ReAlloc(l);
         DNK.Getp_i_j()[i].Used()=l;
         if(! I_Sum.IsAlloc(i))
          I_Sum.Add(i,l);
         I_Sum[i].ReAlloc(l);
         l=0;
         for(k=1;k<=_T.Used();k++)
          if((j <= _T[k])&&(b_i_j[_T[k]][_T[k]-j] > 0))
           {
            DNK.Getp_i_j()[i][++l]=b_i_j[_T[k]][_T[k]-j];
            I_Sum[i][l]=_T[k]-j;
           }
         if(! DNK.Getp_i_idx().IsAlloc(i))
          DNK.Getp_i_idx().Add(i,DNK.Getp_i()[i]);
         DNK.Getp_i_idx()[i].ReAlloc(DNK.Getp_i()[i]);
         DNK.Getp_i_idx()[i].Used()=DNK.Getp_i()[i];
         l=0;
         for(k=1;k<=r_dim;k++)
          if((Right_Z_SUM(k) == j)&&(r_impli[k] == 0))
           DNK.Getp_i_idx()[i][++l]=k+l_dim;
        } 
      }
    }
   if(! (LeftAUT_IS_ID() && RightAUT_IS_ID()))
    {
     DNK.Init();
     DNK.BerechneAufteilung();
    }  
  }
}




//Zeiger auf die Instanz von GRADPART, in der momentan I
//gefuellt wird.
//Wird gebraucht, um in KOORD Restriktionen zu testen.

static int Girth_Set(int z,int sp,int wert)
{
 return( ACTUAL_GRAD->GirthSet(z,sp,wert) );
}


static void Girth_Del(int z,int sp)
{
 ACTUAL_GRAD->GirthDel(z,sp);
}


static int Critical_Set(int z,int sp,int wert)
{
 return( ACTUAL_GRAD->CriticalSet(z,sp,wert) );
}


static void Critical_Del(int z,int sp)
{
 return;
}


int GRADPART::CriticalSet(int z,int sp,int wert)
{
 int i,j,k;

 i = Left_Z_SUM(z) + KOORD.Get_z_soll()[z];
 if(Right_Z_SUM(sp-l_dim) < CRITICAL_GRAD-i+1)
   return(0);
  
 return(1);
}


int GRADPART::GirthSet(int z,int sp,int wert)
{
 int i,j,k,l;

 a_search.Init(NBrestr,dim);
 i = a_search.Abstand(z,sp);
 if(i == -1)
  {
   NBrestr[z][++NBrestr[z].Used()] = sp;
   NBrestr[sp][++NBrestr[sp].Used()] = z;
   return(1);
  }
 if(i <= GIRTH-2)
   return(0); 
 else
  {
   NBrestr[z][++NBrestr[z].Used()] = sp;
   NBrestr[sp][++NBrestr[sp].Used()] = z;
   return(1); 
  }
}



void GRADPART::GirthDel(int z,int sp)
{
#ifdef DEBUG_TG
 if(NBrestr[z][NBrestr[z].Used()] != sp)
  {
   printf("FEHLER bei GirthDel\n");
   exit(0);
  } 
 if(NBrestr[sp][NBrestr[sp].Used()] != z)
  {
   printf("FEHLER bei GirthDel\n");
   exit(0);
  } 
#endif

 NBrestr[z].Used()--; 
 NBrestr[sp].Used()--;
}


 
void GRADPART::Init_KOORD_Data()
{
 int i,j,k,l,_i,_j;

 if(VERBOSE)
  {
   printf("GRADPART::Init_KOORD_Data mit DNK.GetAUT_IS_ID=%d TIEFE=%d\n",
   DNK.GetAUT_IS_ID(),TIEFE);
  }

 if(GIRTH > 3)
  InitNBRestr();

 if((Is_H_Verteilung())||(TREES_ONLY==1))
   H_Verteil_Flag=1;

 if(! ImplDurchlauf())
  {
   KOORD.GetSp()=r_dim;
   KOORD.GetZei()=l_dim;
   if(((LeftAUT_IS_ID())&&(RightAUT_IS_ID()))||
      (DNK.GetAUT_IS_ID() == 1))
    KOORD.GetGROUP_IS_ID()=1;
   else
    {
     KOORD.GetGROUP_IS_ID()=0;
     KOORD.GetGroup().Init(dim);
     KOORD.GetGroup()=DNK.GetAut();
    } 
   KOORD.Get_z_soll().ReAlloc(l_dim);
   KOORD.Get_sp_soll().ReAlloc(r_dim);
   for(i=1;i<=DNK.Getp_i().Used();i++)
    {
     if(DNK.Getp_i_idx()[i][1] <= l_dim)
      {
       for(j=1;j<=DNK.Getp_i()[i];j++)
        {
         KOORD.Get_z_soll()[DNK.Getp_i_idx()[i][j]]=
          I_Sum[i][DNK.GetErg(i,j)];
        }
      }
     else
      {
       for(j=1;j<=DNK.Getp_i()[i];j++)
        {
         KOORD.Get_sp_soll()[DNK.Getp_i_idx()[i][j]-l_dim]=
          I_Sum[i][DNK.GetErg(i,j)];
        }
      }
    }  
   KOORD.GetMAX_VAL() = MAX_VAL;
   KOORD.Init();
   if(GIRTH > 3)
    KOORD.SetRestr(&Girth_Set,&Girth_Del);
   if(ONLY_CRITICAL)
    {
     KOORD.SetRestr(&Critical_Set,&Critical_Del);
     KOORD.GetUNTERTEILE() = 0;
    } 
   KOORD.BerechneAufteilung();
   KOORD.GetPRINT_SOLUTIONS()=0;
  }
 else
  {
   VEKTOR < short > dum;

   KOORD.GetSp()=r_dim;
   KOORD.GetZei()=l_dim;
   if((LeftAUT_IS_ID())&&(RightAUT_IS_ID()))
    KOORD.GetGROUP_IS_ID()=1;
   else
    {
     if(DNK.GetAUT_IS_ID() == 1)
      KOORD.GetGROUP_IS_ID()=1;
     else
      {
       KOORD.GetGROUP_IS_ID()=0;
       KOORD.GetGroup().Init(dim);
       KOORD.GetGroup()=DNK.GetAut();
      } 
    }
   KOORD.Get_z_soll().ReAlloc(l_dim);
   KOORD.Get_sp_soll().ReAlloc(r_dim);
   i=0;
   for(j=0;j<=m;j++)
    {
     if(c[j] != 0)
      {
       l=0;
       for(k=1;k<=l_dim;k++)
        if((Left_Z_SUM(k) == j)&&(l_impli[k] == 0))
         l++;
       if(l > 0)
        {
         if(VERBOSE)
          printf("c[%d]=%d l=%d i=%d\n",j,c[j],l,i);
          
         i++;
         for(k=1;k<=DNK.Getp_i()[i];k++)
          { 
           KOORD.Get_z_soll()[DNK.Getp_i_idx()[i][k]]=
            I_Sum[i][DNK.GetErg(i,k)];
          }
         dum.ReAlloc(DNK.Getp_i_j()[i].Used());
         for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
          dum[_i]=DNK.Getp_i_j()[i][_i];
         for(_i=1;_i<=DNK.Getp_i()[i];_i++)
          dum[DNK.GetErg(i,_i)]--;
         for(k=1;k<=l_dim;k++)
          {
           if((Left_Z_SUM(k) == j)&&(l_impli[k] == 1))
            {
             _i=1;
             while(dum[_i] == 0)_i++;
             dum[_i]--;
             KOORD.Get_z_soll()[k]=I_Sum[i][_i];
            }
          }  
        }
       else
        {
         if(VERBOSE)
          printf("c[%d]=%d l=0\n",j,c[j]); 
         
         for(_i=1;_i<=_H.Used();_i++)
         if((j <= _H[_i])&&(c_i_j[_H[_i]][_H[_i]-j] > 0))
          {
           _j=c_i_j[_H[_i]][_H[_i]-j];
           l=_H[_i]-j;
           break;
          }
         for(k=1;k<=l_dim;k++)
          {
           if(Left_Z_SUM(k) == j)
            {
             if(_j == 0)
              {
               while(1)
                {
                 _i++;
                 if((j <= _H[_i])&&(c_i_j[_H[_i]][_H[_i]-j] > 0))
                  {
                   _j=c_i_j[_H[_i]][_H[_i]-j];
                   l=_H[_i]-j;
                   break;
                  }
                }
              }
             _j--;
             KOORD.Get_z_soll()[k]=l;
            }
          }  
        }
      }
    }

   for(j=0;j<=m;j++)
    {
     if(b[j] != 0)
      {
       l=0;
       for(k=1;k<=r_dim;k++)
        if((Right_Z_SUM(k) == j)&&(r_impli[k] == 0))
         l++;
       if(l > 0)
        {
         if(VERBOSE)
          printf("b[%d]=%d l=%d i=%d\n",j,b[j],l,i);
          
         i++;
         for(k=1;k<=DNK.Getp_i()[i];k++)
          {
           KOORD.Get_sp_soll()[DNK.Getp_i_idx()[i][k]-l_dim]=
            I_Sum[i][DNK.GetErg(i,k)];
          }
         dum.ReAlloc(DNK.Getp_i_j()[i].Used());
         for(_i=1;_i<=DNK.Getp_i_j()[i].Used();_i++)
          dum[_i]=DNK.Getp_i_j()[i][_i];
         for(_i=1;_i<=DNK.Getp_i()[i];_i++)
          dum[DNK.GetErg(i,_i)]--;
         for(k=1;k<=r_dim;k++)
          {
           if((Right_Z_SUM(k) == j)&&(r_impli[k] == 1))
            {
             _i=1;
             while(dum[_i] == 0)_i++;
             dum[_i]--;
             KOORD.Get_sp_soll()[k]=I_Sum[i][_i];
            }
          }  
        }
       else
        {
         if(VERBOSE)
          printf("b[%d]=%d l=0\n",j,b[j]); 
         
         for(_i=1;_i<=_T.Used();_i++)
         if((j <= _T[_i])&&(b_i_j[_T[_i]][_T[_i]-j] > 0))
          {
           _j=b_i_j[_T[_i]][_T[_i]-j];
           l=_T[_i]-j;
           break;
          }
         for(k=1;k<=r_dim;k++)
          {
           if(Right_Z_SUM(k) == j)
            {
             if(_j == 0)
              {
               while(1)
                {
                 _i++;
                 if((j <= _T[_i])&&(b_i_j[_T[_i]][_T[_i]-j] > 0))
                  {
                   _j=b_i_j[_T[_i]][_T[_i]-j];
                   l=_T[_i]-j;
                   break;
                  }
                }
              }
             _j--;
             KOORD.Get_sp_soll()[k]=l;
            }
          }  
        }
      }
    }
   KOORD.GetMAX_VAL() = MAX_VAL;
   if(! (Is_H_Verteilung() || TREES_ONLY))
    {
     KOORD.Init();
     if((GIRTH > 3)&&(!((_T.Used()==1)&&(_T[1]==1))))
      KOORD.SetRestr(&Girth_Set,&Girth_Del);
     KOORD.BerechneAufteilung();
    } 
   KOORD.GetPRINT_SOLUTIONS()=0;
  }
      
 if(VERBOSE)
  printf("ENDE\n");
}




int GRADPART::NextSplit()
{
 int best,max;
 int i,j,k,n,k_i,_r,o;


 if(first_split == 0)
  goto NEXT_SPLIT;
 l_ = _H.Used();
 r_ = _T.Used();
 PARTITION(_H[l_],1);                                     //(1)
 l_ind=l_;                                                //(2)
 while(l_ind <= l_)                                       //(3)
  {

   n=(l_ind == 1)?0:_H[l_ind];
   for(k=m;k >= n;k--)                                   //(4)
    {
     //compute c[k]
     i=l_; c[k]=0;
     while((i >= 1)&&(_H[i] >= k))
      {
       c[k]+=c_i_j[_H[i]][_H[i]-k];
       i--;
      } 
    }

   max=0;                                                //(5)
   for(k=m;k >= n;k--)       
    max+=c[k];
   best=1;                                               //(6)
   k=0;
   for(i=m;i >= n;i--)                                   //(7)
    {
     for(k_i = 1+k; k_i <= k+c[i]; k_i++)   
      d[k_i]=i;          
     k+=c[i];
    }

   if((_T.Used()==1)&&(_T[1]==1))
    {
     int i_,j_,k_;
     i_ = 0;
     for(j_=l_;j_ >= l_ind;j_--)
      for(k_=1;(k_ <= _H[j_])&&(k_ <= MAX_VAL*r_dim) ;k_++)
       i_ += k_ * c_i_j[_H[j_]][k_];
     if(i_ > r_dim)
     best = 0;
    } 

   if(best==1)
    {
     k=0; //left sum
     for(_r=1; _r <= max-1; _r++)                          //(9)
      {
       j=0; //right sum
       for(i=_r+1;i<=max;i++)
        j+=(MAX_VAL*_r < d[i])?MAX_VAL*_r:d[i];
       j+=MAX_VAL*_r*(_r-1)+(l_dim-max)*MAX_VAL*_r;
       k+=d[_r];
       if(k > j)
        {
         best=0;
         break;
        }
      }
    }
   if(best == 1)
    for(i=m;(i>=n)&&(i > MAX_VAL*(l_dim-1));i--)
     if(c[i] > 0)
      {
       best=0; 
       break;
      } 
   if(best == 0)                                         //(14)
    {
     NEXT_C:
     while(PARTITION(_H[l_ind],0) == 0)
      {
       l_ind++;
       if(l_ind > l_)
        return(0);
      }
    }                                                    //(20)
   else                                                  //(21)
    {
     if(l_ind > 1)                                       //(22)
      {
       l_ind--;
       PARTITION(_H[l_ind],1);
      }                                                  //(25)
     else                                                //(26)
      {
       j=0;
       for(k=1;k<=m;k++)
        j+=k*c[k];
       if((j % 2) == 0)                                   //(27)
        {
         i=0;
         for(j=1;j <= l_;j++)                             //(28)
          for(k=0;k <= _H[j];k++)
            for(n=1;n <= c_i_j[_H[j]][k];n++) 
              z[++i]=k;
         r_ind=r_;                                        //(29)
         PARTITION(_T[r_ind],1);                         //(30)
         while(r_ind <= r_)                               //(31)
          {
           n=(r_ind == 1)?0:_T[r_ind];
           for(k=m;k >= n;k--)                           //(32)
            {
             //compute b[k]
             i=r_; b[k]=0;
             while((i >= 1)&&(_T[i] >= k))
              {
               b[k]+=b_i_j[_T[i]][_T[i]-k];
               i--;
              }       
            }
           max=0;                                        //(33)
           for(k=m;k >= n;k--)
            max+=b[k];
           best=1;                                       //(34)
           k=0;
           for(i=m;i >= n;i--)                           //(35)
            {
             for(k_i = 1+k; k_i <= k+b[i]; k_i++)
              d[k_i]=i;
             k+=b[i];
            }
           k=0; //left sum
           for(_r=1; _r <= max-1; _r++)                  //(37) 
            {
             j=0; //right sum
             for(i=_r+1;i<=max;i++)
              j+=(MAX_VAL*_r < d[i])?MAX_VAL*_r:d[i];
             j+=MAX_VAL*_r*(_r-1)+(r_dim-max)*MAX_VAL*_r;
             k+=d[_r];
             if(k > j)
              {
               best=0;
               break;
              }
            } 
           if(best == 1)
            for(i=m;((i>=n)&&(i > MAX_VAL*(r_dim-1)));i--)
             if(b[i] > 0)
              {
               best=0; 
               break;
              } 
           if(best == 1)                                 //(42)
            {
             i=0;
             for(k=m;k >= n; k--)                        //(44)            
              {
               _r=r_+1;
               while((_r > 1)&&(_T[_r-1] >= k))
                _r--;
               for(j=_r;j <= r_;j++)
                for(o=1;o <= b_i_j[_T[j]][k];o++)
                  s[++i]=k;
              }                                         //(52)
             n=0; //left sum
             _r=0;//right sum
             for(k=1;k <= i;k++)                         //(53)
              {
               n+=s[k];
               _r=0;
               for(j=1;j<=l_dim;j++)
                _r+=(z[j] < MAX_VAL*k)?z[j]:MAX_VAL*k;
               if(n > _r)
                {
                 best=0;
                 break;
                }
              }                                          //(57)
             if((best == 1)&&(r_ind == 1))               //(58)
              {
               k=n=0;
               for(j=1;j<=l_dim;j++)
                k+=z[j];
               for(j=1;j<=r_dim;j++)
                n+=s[j];
               if(k != n)
                best=0; 
              } 
            }
           if(best == 0)                                 //(62)
            {
             while(PARTITION(_T[r_ind],0) == 0)
              {
               r_ind++;
               if(r_ind > r_)
                goto NEXT_C;
              }
            }                                            //(68)
           else                                          //(69)
            {
             if(r_ind > 1)                               //(70)
              {
               r_ind--;
               PARTITION(_T[r_ind],1);
              }                                          //(73)
             else                                        //(74)
              {
               j=0;
               for(k=1;k<=m;k++)
                j+=k*b[k]; 
               if(j % 2 == 0)
                {
                 if(CheckRestrictionsSplit() == 1)
                  { 
                  if(VERBOSE)
                    {
                     printf("%d: Aufspaltung gefunden:\n",TIEFE);
                     printf("b=\n");
                     b.PrintAb0(0); 
                     printf("c=\n");   
                     c.PrintAb0(0); 
                     printf("c_i_j=\n");
                     for(k=1;k<=_H.Used();k++)
                      {   
                       printf("%d : ",_H[k]);
                       c_i_j[_H[k]].PrintAb0(0);
                      }  
                     printf("b_i_j=\n");
                     for(k=1;k<=_T.Used();k++)
                      {
                       printf("%d : ",_T[k]);
                       b_i_j[_T[k]].PrintAb0(0);
                      }  
                    }
                   SPLITS_UNTIL_NOW++;
                   if(PRINT_SPLITS_UNTIL_NOW)
                    { 
                     printf("\n%d splits von %d",SPLITS_UNTIL_NOW,POSSIBLE_SPLITS); 
                     fflush(stdout);
                    } 
                   first_split = 0;
                   return(1);  
                  } 
                }
               NEXT_SPLIT:
               while(PARTITION(_T[r_ind],0) == 0)        //(78)
                {
                 r_ind++;
                 if(r_ind > r_)
                  goto NEXT_C;
                }
              } //End of (74)
            } //End of (69)
          } //End of (31)
        } //End of (27) 
       else goto NEXT_C; 
      } //End of (26)
    } //End of (21)
  } //End of (3)         

 return(0);                  
}



int GRADPART::CheckRestrictionsSplit()
{
 int i,j,ka,kn;

 if(ONLY_CRITICAL)
  {
   if(a[2])
    {
     //Knoten vom Grad 2 muessen mit Knoten max. Grades verbunden sein
     if(c_i_j[2][2] != a[2])
      return(0);
     if(b[CRITICAL_GRAD] < 2*a[2])
      return(0);
    }
   if(b_i_j[CRITICAL_GRAD][1] < 2*a[2])
    return(0);
   if(CRITICAL_GRAD > 3)
    {
     j = 0;
     for(i=1;i<=3;i++)
      j += c_i_j[3][i] * i;
     //es gehen j Kanten von Knoten vom Grad 3 zu Knoten
     //max. Grades
     int jo = 0;
     jo = b_i_j[CRITICAL_GRAD][1] - 2*a[2];
     jo += b_i_j[CRITICAL_GRAD][2] * 2;
     if(jo < j)
      return(0);
    }
   if(b_i_j[CRITICAL_GRAD][CRITICAL_GRAD])
    return(0);
   if(b_i_j[CRITICAL_GRAD][CRITICAL_GRAD-1])
    return(0);
 

   /*Es wird vermutet, dass es ein notwendiges und hinreichendes */
   /*Kriterium fuer die Existenz einer Inzidenzmatrix, die den sich aus */
   /*VAL ergebenden Nebenbedingungen genuegt, gibt. Dieses Kriterium */
   /*wird probehalber hier implementiert. */

   int i1,i2,i3,i4,i5,i6;
   max_bind.ReAlloc(CRITICAL_GRAD);
   max_bind.Clear();
   VEKTOR < short >  hilfvar;
   hilfvar.ReAlloc(CRITICAL_GRAD);
   for(i1=2;i1 < CRITICAL_GRAD;i1++)
    {
     //fuer Knoten vom Grad i1 kommen nur Knoten max. Grades
     //mit hoechstens i1-1 Nachbarn in H als Nachbarn in Frage
     //Fuege deshalb die Knoten max. Grades mit i1-1 Nachbarn
     //in H zu max_bind hinzu.
     max_bind[i1-1] += b_i_j[CRITICAL_GRAD][i1-1];

     for(i2=i1;i2 >= 1;i2--)
      {
       //versuche jetzt, die Knoten vom Grad i1 mit i2 Nachbarn in
       //T zuzuordnen.
       for(i3=1;i3<=c_i_j[i1][i2];i3++)
        {
         //zaehle jetzt die noch freien Bindungsmoeglichkeiten
         i5 = 0;
         for(i6=1;i6 < CRITICAL_GRAD;i6++)
          i5 += max_bind[i6];
         if(i5 < i2)
          return(0);
         //es ist also eine Zuordnung moeglich 
         hilfvar.Clear();
         i4 = i2;
         for(i5=CRITICAL_GRAD-2;i5>=1;i5--)
          {
           if(i4 <= max_bind[i5])
            {
             hilfvar[i5] = i4;
             break;
            }
           else
            {
             hilfvar[i5] = max_bind[i5];
             i4 -= max_bind[i5];
            }
          }
         //wir nehmen also hilfvar[i] Nachbarn, die noch i freie Bindungen
         //haben
         max_bind[1] -= hilfvar[1];
         for(i5=2;i5<=CRITICAL_GRAD-2;i5++)
          {
           max_bind[i5] -= hilfvar[i5];
           max_bind[i5-1] += hilfvar[i5];
          }
        }
      }
    }
  }


 if(GIRTH > 3)
  {
   b.Used() = b.Dim();
   while(b[b.Used()] == 0)
    b.Used()--;
   if(a_gir_test.IsPossiblePart(b,GIRTH)==0)
    {
     return(0);
    }
   c.Used() = c.Dim();
   while(c[c.Used()] == 0)
    c.Used()--;
   if(a_gir_test.IsPossiblePart(c,GIRTH)==0)
    {
     return(0);
    }
  }
   
 if(ONLY_CONN_GRAPHS)
  {
   if(a[0] > 0)
    return(0);
   if((_T[1] == 1)&&(b_i_j[1][0] > 0))       
    return(0);
   if(b_i_j[_T[1]][0] == r_dim)
    return(0);  
   CONN_AND_IMPL_Sp = 0;
   if((b_i_j[_T[1]][0] == 0)&&(_T[1] == 1))
    {
     //=> links nur zusammenhaengende Graphen
     CONN_AND_IMPL_Sp = 1;
     if((c[0] > 0)&&(l_dim > 1))
      return(0);
     i = 0;
     for(j=0;j<=c.Dim();j++)
      i+=j*c[j];
     if(i < 2*(l_dim-1))
      return(0);  
    } 
   return(1);
  }

 if(TREES_ONLY)
  {
   if(ONLY_CONN_GRAPHS)
    {
     if(b_i_j[1][1] != r_dim)
      return(0);
     if((c[0] > 0)&&(l_dim > 1))
      return(0);
     ka = kn = 0;
     for(i=1;i<=c.Dim();i++)
      {
       kn += c[i];
       ka += i*c[i];
      }
     ka /= 2;
     if(kn != ka+1)
      return(0); 
     return(1);
    }
   else
    { 
     ka = kn = 0;
     for(i=1;i<=c.Dim();i++)
      {
       kn += c[i];
       ka += i*c[i];
      }
     ka /= 2;
     if((kn <= ka)&&(kn > 0))
      return(0);
     return(1);  
    }
  }

 return(1);
}





int GRADPART::PARTITION(int ind,int f)
{
 PART.GetFirst()=f;
 if(_HT[ind+1] == 1)   
  PART.GetMax()=(ind < MAX_VAL*r_dim)?ind:MAX_VAL*r_dim;
 else
  PART.GetMax()=(ind < MAX_VAL*l_dim)?ind:MAX_VAL*l_dim;

 PART.GetSumme()=a[ind];
 PART.SetShift();
 if(_HT[ind+1] == 1) //compute c_i_j[ind]  
  return(PART.NextRep(c_i_j[ind]));
 else //compute b_i_j[ind]
  return(PART.NextRep(b_i_j[ind]));
}




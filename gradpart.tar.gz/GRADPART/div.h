#ifndef DIV_H

#include "vector.t"
#include "array.t"
#include "bitvec.h"
#include "langzahl.h"
#include "defs.h"


class GRAPH_PART
{
 protected:
  VEKTOR < short >      part;
  VEKTOR < short >      d;
  int              knoten;
  int              kanten; 
  int              c;
  //maximale Bindungsvielfachheit
 public:
                        GRAPH_PART() { return; }
                        GRAPH_PART(int n,int k,int _c);

  void                  Init(int n,int k,int _c);
  int              IsGraphic();
  short&                GetVertAnz(int grad);
};




class SCHLICHT_PART : public GRAPH_PART
{
 public:
                        SCHLICHT_PART() { return; }
                        SCHLICHT_PART(int n,int k,int _c);

  int              NextRep();
  void                  Init(int n,int k,int _c);

};



class DEPTH_FIRST_SCHLICHT
{
 private:
  char               degree_gr_0;
  VEKTOR < short >        part;
  VEKTOR < short >        d;
  int                knoten;
  int                kanten;
  int                c; 
  int                max_entry;
  
 public:
                     DEPTH_FIRST_SCHLICHT() 
                      { return; }
                     DEPTH_FIRST_SCHLICHT(int n,int k,int _c); 

  void               Init(int n,int k,int _c);
  void               Init(int n,int k,int _c,int _max_entry);
  int           NextRep();
  int           IsAnfStueck(int r); 
  short              GetVertAnz(int grad); 
  void               SetDeg_gr_0() { degree_gr_0=1; }
};     



//part[0],...,part[max] shall be filled with
//part[0]+...+part[max] == summe.
//part[i] >= 0
class ALL_PART
{
 private:
  VEKTOR < short >       part;
  VEKTOR < short >       nr; 
  VEKTOR < short >       hilf; 
  VEKTOR < short >       shift_v;
  int               summe;
  int               max;
  char                   first;                 

 public:

                         ALL_PART()
                         { 
                          part.SetAb0();
                          nr.SetAb0();
                          hilf.SetAb0();
                          shift_v.SetAb0();
                         }
                         ~ALL_PART();

  int               NextRep();
  int               NextRep(VEKTOR < short >& V);
  int               Klein_part(VEKTOR < short >& a,
                                    int i,int r,char is_erster);
   
  void                   SetShift();
  short                  GetPart(int i); 
  int&              GetSumme() { return(summe); }
  int&              GetMax() { return(max); } 
  char&                  GetFirst() { return(first); }
};



//Berechnet alle absteigenden Partitionen von summe
class DescPart
{
 private:
  int               summe;
  VEKTOR < short >       part;  

 public:
                         DescPart(){};
  void                   Init(int sum);
  int               NextRep(char first);
  int               NextRep(VEKTOR < short >& PA,char first);
  VEKTOR < short >&      Part() { return(part);}                       

};




class ALL_HYBRID
{
 private:
  long int                    dim;
  VEKTOR<short>                  grade;
  ARRAY < VEKTOR<short> >        parts;
  char                        first;
  VEKTOR<short>                  klassen;
  //innerhalb der gleichen Klassen muss parts
  //lex. absteigend sein, um doppelte Loesungen zu vermeiden

  DescPart                    a_desc;
 public:
  void                        Init(long int _dim,long int maxgrad);
  void                        SetGrad(long int idx,long int wert);
  long int                    NextRep(); 
  ARRAY < VEKTOR<short> >&       GetHybrid() { return(parts); }
  void                        SetKlasse(int idx,int wert)
                               { klassen[idx] = wert; }

  ARRAY < VEKTOR<short> >           hybridisierungen;
  VEKTOR<short>                     hybrid_min_anz;
  VEKTOR<short>                     hybrid_max_anz;
  VEKTOR<short>                     Hybr_H_anz;
  VEKTOR<short>                     hybrid_typnummern;
  VEKTOR<short>                     multi;
  VEKTOR<short>                     H_numbers;

  VEKTOR<short>                     mult1,mult2;
  VEKTOR<short>                     hybrid_anz;
  VEKTOR<short>                     hybrid_bed_in_row;
  int                               MAXVAL;

};




class VALID_HYBRID
{
 private:
  ARRAY < VEKTOR < short > >  parts;
  int                    dim;
  GRAPH_PART                  a_part;
  VEKTOR < short >            testpart;
  VEKTOR < short >            mult;

 public:
  void                        Init(int _dim);
  int                    IsValid();
  ARRAY < VEKTOR < short > >&  GetHybrid() { return(parts); }
};



class GALE
{
 private:
  int           m;
  //number of rows

  int           n;
  //number of columns

  int           c;
  //maximal entry

  VEKTOR < short >   s;
  //column-sums

  VEKTOR < short >   z;
  //row-sums

 public:

                     GALE() { return; }
                     ~GALE(){ return; }

  void               Init(int _m,int _n,int _c);                    
  int           Test();
  void               SetSp(int idx,int wert);
  void               SetZ(int idx,int wert);
};




class KILOMETER_ZAEHLER
{
 private:
  int             k;
  ARRAY < LANGZAHL >   Z;
  ARRAY < LANGZAHL >   nr_i;
  int             k_intern;
  ARRAY < LANGZAHL >   Z_intern;
  ARRAY < LANGZAHL >   nr_i_intern;
  LANGZAHL             nr; 
  
 public:

  void             Start(LANGZAHL& _nr);
  void             SetZ(int idx,LANGZAHL& wert);
  void             Setk(int _k); 
  LANGZAHL&        Getnr_i(int idx);
};



class UNRANK
{
 private:
  int            k;
  LANGZAHL            R;
  VEKTOR < short >    v;

 public:

  void                Setk(int _k);
  void                Start(LANGZAHL& _m);
  int            Getv(int idx);

};



class UNRANK_MULTI
{
 private:
  int              n;
  int              k;
  VEKTOR < short >      n_i;
  VEKTOR < short >      m_i;
  ARRAY < LANGZAHL >    nr_i;

  VEKTOR < short >      i_i;
  VEKTOR < short >      ind;

  KILOMETER_ZAEHLER     a_Z;
  UNRANK                a_UR;

 public:

  void                  Start(LANGZAHL& nr);
  VEKTOR < short >&     GetLoes();
  void                  Setn(int _n);
  void                  Setk(int _k);
  void                  Setn_i(int idx,int wert); 

};



class CONN_TEST
{
 private:
  int                    dim;
  ARRAY < VEKTOR < short > >  *NBList;  

 public:

  int    IsZshg(ARRAY < VEKTOR < short > >& P,int anz,int flag);

};



//A ist die Nachbarschaftsliste eines Graphen.
//A[i] enthaelt alle Nachbarn von i.
//Der Graph wird breadth-first durchsucht.
//Nach dem Aufruf von ComputeLevels enthaelt levels[1+k]
//alle Knoten des Graphen, die von a den Abstand k haben.

class BrFiSe
{
 private:
  int                    dim;
  BITVEK                      bits;
  ARRAY < VEKTOR < short > >  levels;
  ARRAY < VEKTOR < short > >  *NB;
  
 public:

  void           Init(ARRAY < VEKTOR < short > >& A, int dim);
  void           ComputeLevels(int a);              
  void           ComputeLevels(int a,int maxabst);              
  int       Abstand(int a,int b); 
  int       IsMinAbstand(int a,int b,int abst);

  VEKTOR<short>& Levels(int depth)
                  { return(levels[depth]); }
  BITVEK&        GetLevBits() { return(bits); }				  
};



class COLOR_EDGES
{
 private:
  short                         dim;
  short                         maxgrad;
  short                         kanten;
  VEKTOR<short>                 lauf;
  VEKTOR<short>                 kantenfarben;
  ARRAY < VEKTOR < short > >    knotenfarben;
  ARRAY < VEKTOR < short > >    kantenliste;
  ARRAY < VEKTOR < char > >     Mat;

  ARRAY < VEKTOR < short > >    NB;
  BITVEK                        bits;
  ARRAY < VEKTOR < short > >    levels;
  
 public:

  void                          FREE();
  int                           ChromaticIndex(ARRAY < VEKTOR < short > >& NBlist);

};



class CRITICAL_TEST
{
 private:
  short                       dim;
  short                       maxgrad;
  ARRAY < VEKTOR < short > >  testNB; 
  COLOR_EDGES                 a_col_edge;

 public:
  int                         IsCritical(ARRAY < VEKTOR < short > >& NB);

};



class SPLITINFO
{
 public:
                                SPLITINFO(int _dim);
                                SPLITINFO()
                                 { return; }
  void                          Init(int _dim);

  short                         x1,y1;
  //linke obere Ecke des Zeichenbereichs

  short                         x2,y2;
  //rechte untere Ecke des Zeichenbereichs

  int                      dim;
  //number of vertices

  int                      tiefe;

  VEKTOR < short >              global_nr;
  //global_nr[i] is the number of vertex i in the entire graph
  
  ARRAY < VEKTOR < short > >    NBlist;
  //neighbourhood-list
  
  ARRAY < VEKTOR < short > >    NBwert;
  
  VEKTOR < short >              split_left; 
  VEKTOR < short >              split_right; 
  //contain the degrees to split to the left and 
  //to the right 
  
  int                      first_col_nr;
  int                      l_dim;
  //used to identify the position in the whole matrix
  
  char                          is_split;
  //==1, if this graph was constructed by splitting
  
  char                          is_plaziert;
  VEKTOR < short >              x_coordinates;
  VEKTOR < short >              y_coordinates;
  //used if is_split==0. The coordinates have values
  //between 1 and 1000 and are related to the whole
  //drawing area.

  void                          FREE(); 
  void                          operator=(SPLITINFO& Q);
  int                      operator==(SPLITINFO& I); 
  int                      operator<(SPLITINFO& I); 
  int                      operator>(SPLITINFO& I);         

  void                          Print(FILE *fp);
  int                      Scan(FILE *fp);
};




#include "binbaum.t"


class TG_GRAPH
{
 private:
  ARRAY < VEKTOR < short > >    NBlist;
  //neighbourhood-list
  
  ARRAY < VEKTOR < short > >    NBwert;
  //connection-multiplicities
  
  int                           dim;
  //number of vertices
 
  short                         max_tiefe;  
    
  ARRAY < VEKTOR < short > >    split_tiefe;
  //split_tiefe[i][j] denotes the depth of the split-tree
  //in which the edge (i,j) has been inserted. 

  short                         line_anz; 
  VEKTOR < short >              x1;  
  VEKTOR < short >              y1;  
  VEKTOR < short >              x2;  
  VEKTOR < short >              y2;  
  VEKTOR < short >              line_tiefe;
  //Linie j geht von (x1[j],y1[j]) nach (x2[j],y2[j]).
  //Sie muss in Tiefe line_tiefe[j] hinzugefuegt werden. 
     
  int                           l_dim;
  //used to identify the position in the whole matrix
  
  char                          is_plaziert;
  VEKTOR < short >              x_coordinates;
  VEKTOR < short >              y_coordinates;

  char                          is_split;
  //==1, if this graph was constructed by splitting
  
  BINBAUM < SPLITINFO >         SplitTree;

 public:

  void                          Init(int _dim);
  void                          Plaziere(); 
  void                          Init(int _l_dim,int _is_spl);

  void                          Insert(SPLITINFO *I) 
                                 { SplitTree.Insert(I); }
                                                                   
  void                          ReadNBList(FILE *fp); 

  ARRAY < VEKTOR < short > >&   GetNBList()
                                 { return(NBlist); }    
  ARRAY < VEKTOR < short > >&   GetNBWert()
                                 { return(NBwert); }    
  BINBAUM < SPLITINFO >&        GetSplitTree()
                                 { return(SplitTree); }                                
  int&                          Dim() { return(dim); } 
  void                          PrintSplitTree(FILE *fp);
  void                          ScanSplitTree(FILE *fp);
  char&                         IsSplit() { return(is_split); }
  VEKTOR < short >&             XCoord() { return(x_coordinates); }
  VEKTOR < short >&             YCoord() { return(y_coordinates); }
  ARRAY < VEKTOR < short > >&   GetSplitTiefe() { return(split_tiefe); }                                 
  VEKTOR < short >&             SplLineX1() { return(x1); } 
  VEKTOR < short >&             SplLineX2() { return(x2); } 
  VEKTOR < short >&             SplLineY1() { return(y1); } 
  VEKTOR < short >&             SplLineY2() { return(y2); } 
  VEKTOR < short >&             LineTiefe() { return(line_tiefe); }
  short                         LineAnz() { return(line_anz); }   
  short                         MaxTiefe() { return(max_tiefe);}
};



void ReadParameters(char& go,char& S50,char& S_Mi,char& S_MA,char& PRE_C,char &REC);
int  f_0(int k,int t);

class GIRTH_TEST
{
 private:
  ARRAY < VEKTOR < short > >     schichten;
  VEKTOR < short >               vek;
  int                            GIRTH;
 public:

  int    IsPossiblePart(VEKTOR < short >& qvek, int g);          
};


#include "list.t"

class HDD_GIRTH
{
 private:
  LIST_BASE < int >         **HDDtafel;
  VEKTOR < short >               HDD_part;
  int                       HDD_girth;
  int                            K_nr;
  int                            Girth_nr;
  
 public:
        HDD_GIRTH();
	~HDD_GIRTH();
   
  void  InsertHDD(int idx,int wert,int dim); 
  void  Init(int K_N,int GI_N);     
  int   IsPossiblePartition(VEKTOR<short>& bvek);
  void  ReadHDDtafel();
  void  WriteHDDtafel();
  void  ReadHDD_part(FILE *fp,int startpos);

};


class HDD_GIRTH_DATABASE
{
 private:
  LIST_BASE < int >              **HDDtafel;
  VEKTOR < short >               HDD_part;
  int                            HDD_write_start,HDD_graph_anz; 
  VEKTOR<int>                    write_st_gi,graph_anz_gi;
  int                            max_kand_girth;
  int                            K_nr;
  int                            Girth_nr;

 public:
  HDD_GIRTH_DATABASE();
  ~HDD_GIRTH_DATABASE();

  void  InsertHDD(int idx,int wert,int dim); 
  void  Init(int K_N,int GI_N);     
  int   IsPossiblePartition(VEKTOR<short>& bvek);
  int   IsPossiblePartition(VEKTOR<short>& bvek,int GI);
  void  ReadHDDtafel();
  void  WriteHDDtafel();
  void  ReadHDD_part(FILE *fp,int startpos);
		
  int   GetHDD_write_start() { return(HDD_write_start); }
  int   GetHDD_graph_anz() { return(HDD_graph_anz); }       
  int   GetMAX_GIRTH() { return(max_kand_girth); }
  VEKTOR<int>& GetWriteSt() { return(write_st_gi); }
  VEKTOR<int>& GetGraph_Anz() { return(graph_anz_gi); }
  int   GetKNR() { return(K_nr); }
  int   GetGINR() { return(Girth_nr); }  
};


class GIRTH_DAT_READ
{
 private:
  int                            K_nr;
  int                            Girth_nr;
  int                            read_start;
  int                            read_anz;
  int                            read_until;
  int                            dim;
  int                            dim_gr_0;
  int                            kant_anz;
  FILE                           *in;
  VEKTOR < short >               NBListKompr;
  ARRAY < VEKTOR < short > >     NBList;
  VEKTOR < short >               ZSums;

  void                           ReadNB(FILE *f, VEKTOR<short>& N,
                                        int _dim,int& gi);
 public:
  
  void                           Init(int KNR,int GNR,int RST,
                                      int RA,int DIM,int DIMGR,int KA);
  int                            NextRep(int& gi);

  VEKTOR < short >&              GetZSums() { return(ZSums); }
  ARRAY < VEKTOR < short > >&    GetNBList() { return(NBList); }
};



class FIND_CIRCLES
{
 private:
  ARRAY < VEKTOR < short > >  nb;
  VEKTOR < short >            dpf,ind;
  BITVEK                      bits; 

 public:
  
  void   ComputeCircles(ARRAY < VEKTOR < short > >& NB,
                        ARRAY < VEKTOR < short > >& kreis_list,
                        int GIRTH); 

};

#define DIV_H
#endif


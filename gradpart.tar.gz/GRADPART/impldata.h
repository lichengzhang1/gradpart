#ifndef IMPL_DATA_H

#include <stdio.h>
#include "array.t"
#include "vector.t"
#include "langzahl.h"
#include "list.t"
#include "div.h"

class impl
{
 public:
                       impl() { return; }
                       impl(int dim) 
                        { return; }


  void operator=(impl& q);

  int                  first_col_nr;
  //== GRADPART.FIRST_COL_NR of the GRADPART,
  //   this struct belongs to

  int                  l_dim;
  //like first_col_nr. ( with these two variables
  //we can identify, to which GRADPART this struct belongs ) 

  int                  r_dim;

  int                  n;
  //number of rows or columns

  int                  k;
  //number of blocks
  
  VEKTOR < short >     n_i;
  //lengths of the blocks
  
  LANGZAHL             fak;
  //number of possibilities
  
  char                 change_rows;
  // == 1, if some rows can be changed
  // == 0, if some columns can be changed
  
  VEKTOR < short >     idx;
  //row- or columnnumbers according to the whole 
  //matrix
  
  VEKTOR < short >     constr_idx;
  //numbers during construction of a special
  //representative

  VEKTOR < short >     m_i;
  //idx[j] -> idx[m_i[j]]

  short                ab;

  LANGZAHL             nr;
  //this representative shall be constructed

};



class IMPL_DATA
{
 private:
  int                      dim;
  //dimension of mat
 
  ARRAY < VEKTOR < char > >     mat;
  //matrix that stores the found representative

  ARRAY < VEKTOR < char > >     hilf_mat;

  TG_GRAPH                         erg;
  //neighbourhood-list of erg 

  TG_GRAPH                         constr;
  //here the constructed representative is stored

  ARRAY < LIST_BASE < impl > >  imp_str;
 
  LANGZAHL                      PROD;
  //product of all imp_str.fak 

  LANGZAHL                      COMP;
  //this representative shall be computed

  short                         act_idx;
  //imp_str[act_idx] is going to be filled 

  char                          is_last;

  KILOMETER_ZAEHLER             a_counter;
  UNRANK_MULTI                  a_unrank_multi;

 public:
                                IMPL_DATA() { return; } 
                                IMPL_DATA(int _dim);
                                ~IMPL_DATA() { return; }
    
  void                          Init(int _dim); 
  void                          Init(int f_c_nr,int l_dim);
  //computes act_idx and eventually allocates some memory
  void                          Del(int f_c_nr,int l_dim);
  
  void                          Comp_Rep(LANGZAHL& L);

  void                          ConstrStart();
  int                      ConstructNextSolution(); 

  void                          ReadInput(FILE *fp);

  /*******************************************************/
  //die folgenden Funktionen sollten von Gradpart aus
  //in der Reihenfolge verwendet werden, wie hier
  //aufgefuehrt.
  void                          Set_n(int _n);
  void                          Set_k(int _k);
  void                          Set_n_i(int idx,int wert); 
  void                          Set_ch_rows(char w);
  void                          Set_ab(int _ab); 
  void                          Setr_dim(int _r_dim);
  void                          Set_idx(int nr,int wert);
  /*******************************************************/
 
  ARRAY < VEKTOR < short > >&   GetNBList();
  ARRAY < VEKTOR < short > >&   GetNBWert();
  ARRAY < VEKTOR < short > >&   GetNewNBList();
  ARRAY < VEKTOR < short > >&   GetNewNBWert();
  TG_GRAPH&                        GetGraph()
                                 { return(erg); } 
  TG_GRAPH&                        GetNewGraph()
                                 { return(constr); } 
  void                          ComputeFak();
  void                          ComputeNewFak(int a,int b);
  LANGZAHL&                     GetFak();
  void                          Print(FILE *fp);
  void                          Print(FILE *fp,int i);
  void                          PrintUsed(FILE *fp,int i);
};


#define IMPL_DATA_H
#endif


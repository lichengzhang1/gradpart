
#ifndef BITVEK_H

#include "defs.h"
#include <stdio.h>
#include <stdlib.h>
#include "mess.h"


class BITVEK
{
 private:
  long int*        vec;
  short		   anz;
  short		   bits;
  int              INT_SIZE;

 public:
		   BITVEK(){ anz=0; bits=0;
                             vec=NULL; INT_SIZE = 8 * sizeof(long int); }
		   BITVEK(short dim);
		   ~BITVEK();


  int              GetVec()
                    {
                     return(vec[0]);
                    }
  void		   Init(int i);
  void             FREE();
  void		   ReAlloc(int i);
  int	           operator [] (short idx)
                    {
                     #ifdef DEBUG_TG
                      if((idx < 1)||(idx > bits))
                       {
                        FatalMess("Falscher Index bei BITVEK::operator[]\n");
                        EXIT();
                       }
                      #endif

                     idx--;
                     return vec[idx/INT_SIZE] & (1L << idx%INT_SIZE)?1:0;
                    }
  void		   Set(short idx)
                    {
                      #ifdef DEBUG_TG
                       if((idx < 1L)||(idx > bits))
                        {
                         FatalMess("Falscher Index bei BITVEK::Set\n");
                         EXIT();
                        }
                      #endif

                      idx--;
                      vec[idx/INT_SIZE] |= (1L << idx%INT_SIZE);
                    }
  void		   Reset(short idx)
                    {
                     #ifdef DEBUG_TG
                      if((idx < 1L)||(idx > bits))
                       {
                        FatalMess("Falscher Index bei BITVEK::Reset\n");
                        EXIT();
                        }
                     #endif

                     idx--;
                     vec[idx/INT_SIZE] &= ~(1L << idx%INT_SIZE);
                    }

  void		   operator ~ ()
                    {
                     for(int i=0;i<anz;i++)
                      vec[i]=~vec[i];
                    }
  void		   operator &= (BITVEK& v)
                    {
                     for(int i=0;i<anz;i++)
                      vec[i]=vec[i] & v.Vektor()[i];
                    }
  void		   operator |= (BITVEK& v)
                    {
                     for(int i=0;i<anz;i++)
                      vec[i]=vec[i] | v.Vektor()[i];
                    }
  void		   operator = (BITVEK& v)
                    {
                     for(int i=0;i<anz;i++)
                      vec[i]=v.Vektor()[i];
                    }
  void		   Print(int einrueck);
  void		   Print(FILE *fp,int einrueck);
  void		   PrintUsed(FILE *fp,int einrueck);
  void		   Scan();
  void             Clear();
  int              IsEmpty();
  int		   Dim() { return(bits); }
  long int*        Vektor() { return(vec); }

  //Phantomfunktionen
  void Add(int i,int j){ return;}
  void REALLOC(int i,int j){ return;}
};



#define BITVEK_H
#endif





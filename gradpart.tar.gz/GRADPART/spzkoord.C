#include "spzkoord.h"
#include "defs.h"



//Sp,Zei,G,sp_soll and z_soll must already be initialized
void ORD_SP_Z_KOORD::Init()
{
 int i;

 ORD_KOORD::Init();
 z_sums.ReAlloc(Zei);
 sp_sums.ReAlloc(Sp);
 z_sums.Clear();
 sp_sums.Clear();

 next_s_u.ReAlloc(Sp);
 next_s_o.ReAlloc(Sp);
 next_z_u.ReAlloc(Zei);
 next_z_o.ReAlloc(Zei);

 //all other data-structures are allocated dynamically
}



ORD_SP_Z_KOORD::~ORD_SP_Z_KOORD()
{
 if(ords != NULL)
  { 
   for(int i=1;i<=ords_anz;i++)
    delete ((ORDTREU_SP_Z_SUMS*)ords[i]);
   free(ords);
   ords = NULL;
  } 
}


ORD_SP_Z_KOORD::ORD_SP_Z_KOORD():ORD_KOORD()
{
 COLUMN_WISE_NUMBERING=0;
}


void ORD_SP_Z_KOORD::FREE()
{
 z_soll.FREE();
 sp_soll.FREE();
 z_sums.FREE();
 sp_sums.FREE();
 next_s_u.FREE();
 next_s_o.FREE();
 next_z_u.FREE();
 next_z_o.FREE();

 z_orbits.FREE();
 sp_orbits.FREE();
 ZeilenZerlegung.FREE();
 SpaltenZerlegung.FREE();
 reihenf_zeile.FREE();
 reihenf_spalte.FREE();

 G.FREE();
 is_first.FREE(); 
 for(int i=1;i<=ords_anz;i++)
  delete ((ORDTREU_SP_Z_SUMS*)ords[i]);
 free(ords);
 ords=NULL;
 ords_anz=0;
}





int ORD_SP_Z_KOORD::BerechneEingabeData(int idx)
{
 int i,j,_z,_s,m,n,l;


 if(is_first[idx] == 1)
  {
   //evtl. realloc ords and initialize ords[idx]->z_p,
   //ords[idx]->s_p,ords[idx]->G,ords[idx]->AUT

   if(idx > ords_anz)
    {
     if(ords_anz == 0)
      {
       ords=(ORDTREU**)malloc(2*sizeof(ORDTREU*));
       #ifdef DEBUG_TG
        if(ords == NULL)
         {
          FatalMess("no memory in ORD_SP_Z_SUMS::BerechneEingabeData\n");
          exit(0);   
         }
       #endif
       ords[1]=NULL;
       ords_anz=1;
      }
     else
      {
       ords=(ORDTREU**)realloc(ords,
             (ords_anz+2)*sizeof(ORDTREU*));
       #ifdef DEBUG_TG
        if(ords == NULL)
         {
          FatalMess("no memory in ORD_SP_Z_SUMS::BerechneEingabeData\n");
          exit(0);   
         }
       #endif
       ords_anz++;
       ords[ords_anz]=NULL;
      }
    } 

   if(ords[idx] == NULL)
    {
     ords[idx]=new ORDTREU_SP_Z_SUMS;
     #ifdef DEBUG_TG
      if(ords[idx] == NULL)
       {
        FatalMess("no memory in ORD_SP_Z_SUMS::BerechneEingabeData\n");
        exit(0);   
       }
     #endif
    }    

   _s=SpaltenZerlegung[reihenf_spalte[idx]].Used();   
   _z=ZeilenZerlegung[reihenf_zeile[idx]].Used();   

   ords[idx]->GetMAX_VAL() = MAX_VAL;
   ords[idx]->Spalten()=_s;   
   ords[idx]->Zeilen()=_z;   
   ords[idx]->Anz()=1; //pro forma

   ords[idx]->GetGROUP_IS_ID()=1;
   if(COLUMN_WISE_NUMBERING==0)
    ((ORDTREU_SP_Z_SUMS*)ords[idx])->SetROWWISE_NUMBERING();
   else 	
    ((ORDTREU_SP_Z_SUMS*)ords[idx])->SetCOLUMN_NUMBERING(spaltenorder);
   ((ORDTREU_SP_Z_SUMS*)ords[idx])->Init(this);
   //at this position Init() is called only for allocating
   //ords[idx]->Zei_NR(),...

   ords[idx]->GetENABLE_AUT()=1;
   ords[idx]->GetPRINT_SOLUTIONS()=0;
   ords[idx]->GetPRINT_ANZ_CANDIDATES()=0;
   ords[idx]->GetPRINT_CANDIDATES()=0;

   for(i=1;i<=_z;i++)
     ords[idx]->Zei_Nr()[i]=ZeilenZerlegung[reihenf_zeile[idx]][i];
   for(i=1;i<=_s;i++)
     ords[idx]->Sp_Nr()[i]=SpaltenZerlegung[reihenf_spalte[idx]][i]+Zei;

   ords[idx]->Inv_sz().ReAlloc(Zei+Sp);
   for(i=1;i<=_z;i++)
     ords[idx]->Inv_sz()[ords[idx]->Zei_Nr()[i]]=i;                         
   for(i=1;i<=_s;i++)
     ords[idx]->Inv_sz()[ords[idx]->Sp_Nr()[i]]=i;  
  }


 //now compute upper and lower bounds for the next step.
 //Initialize also ords[idx]->Anz() and ords[idx]->Gruppe().
 //Note: ords[idx]->Init() has to be called.


 _s=SpaltenZerlegung[reihenf_spalte[idx]].Used();   
 _z=ZeilenZerlegung[reihenf_zeile[idx]].Used();   

 if(idx == 1)
  {
   if(GROUP_IS_ID == 1)
    ords[idx]->GetGROUP_IS_ID()=1;
   else
    {
     if(is_first[idx] == 1)
      {
       i=0;
       for(j=1;j<=G.Dim();j++)
        {
         if(G.HV(j) != j)
          {
           for(m=1;m<=_z;m++)
            {
             l=ords[idx]->Zei_Nr()[m];
             if(G.KM(G.pi(j))[l] != l)
              i=1;
            }
           for(m=1;m<=_s;m++)
            {
             l=ords[idx]->Sp_Nr()[m];
             if(G.KM(G.pi(j))[l] != l)
              i=1;
            }
          } 
        }   
       ords[idx]->GetGROUP_IS_ID()=0;
       if(i == 0)
        {
         ords[idx]->GetIND_GROUP_IS_ID()=1;
         ords[idx]->SetOP_G(&G);
        }
       else
        {
         ords[idx]->GetIND_GROUP_IS_ID()=0;
         ords[idx]->Gruppe().Init(G.Dim());   
         ords[idx]->AutGruppe().Init(G.Dim());   
         ords[idx]->Gruppe()=G;
        }
      }       
    }
  }
 else
  {
   if(ords[idx-1]->GetAUT_IS_ID() == 1)
     ords[idx]->GetGROUP_IS_ID()=1;
   else
    {
     i=0;
     for(j=1;j<=ords[idx-1]->AutGruppe().Dim();j++)
      {
       if(ords[idx-1]->AutGruppe().HV(j) != j)
        {
         for(m=1;m<=_z;m++)
          {
           l=ords[idx]->Zei_Nr()[m];
           if(ords[idx-1]->AutGruppe().KM(ords[idx-1]->AutGruppe().pi(j))[l] != l)
            i=1;
          }
         for(m=1;m<=_s;m++)
          {
           l=ords[idx]->Sp_Nr()[m];
           if(ords[idx-1]->AutGruppe().KM(ords[idx-1]->AutGruppe().pi(j))[l] != l)
            i=1;
          }
        } 
      }   
     ords[idx]->GetGROUP_IS_ID()=0;
     if(i == 0)
      {
       ords[idx]->GetIND_GROUP_IS_ID()=1;
       ords[idx]->SetOP_G(&ords[idx-1]->AutGruppe());
      }
     else
      {
       ords[idx]->GetIND_GROUP_IS_ID()=0;
       ords[idx]->Gruppe().Init(G.Dim());   
       ords[idx]->AutGruppe().Init(G.Dim());   
       ords[idx]->Gruppe()=ords[idx-1]->AutGruppe();
      }
    }
  }


 is_first.Reset(idx);
 //ords[idx]->Gruppe() is initialized.

 _s=SpaltenZerlegung[reihenf_spalte[idx]].Used();   
 _z=ZeilenZerlegung[reihenf_zeile[idx]].Used();   
 

 //compute now z_sums and sp_sums
 z_sums.Clear();
 sp_sums.Clear();

 for(i=1;i<idx;i++)
  {
   for(j=1;j<=ords[i]->Zeilen();j++)
     z_sums[ords[i]->Zei_Nr()[j]]+=ords[i]->ZeiSumme()[j];
   for(j=1;j<=ords[i]->Spalten();j++)
     sp_sums[ords[i]->Sp_Nr()[j]-Zei]+=ords[i]->SpSumme()[j];
  }

 int uebrig;
 uebrig=Zei-_z;
 for(i=1;i<idx;i++)
  {
   if(reihenf_spalte[i] == reihenf_spalte[idx])
     uebrig-=ZeilenZerlegung[reihenf_zeile[i]].Used(); 
  } 

 //after filling ords[idx] there remain 'uebrig' places to fill
 //in each column belonging to ords[idx].

 //now fill next_s_u and next_s_o 
 VEKTOR < short >& vec=SpaltenZerlegung[reihenf_spalte[idx]];
 for(i=1;i<=_s;i++)
  {
   next_s_u[i]=0;
   int noch=sp_soll[vec[i]]-sp_sums[vec[i]];
   if(noch > MAX_VAL*uebrig)
    next_s_u[i]=noch-MAX_VAL*uebrig;

   next_s_o[i]=MAX_VAL*_z;
   if(noch < next_s_o[i])
    next_s_o[i]=noch;
  }

 uebrig=Sp-_s;
 for(i=1;i<idx;i++)
  {
   if(reihenf_zeile[i] == reihenf_zeile[idx])
     uebrig-=SpaltenZerlegung[reihenf_spalte[i]].Used(); 
  } 

 //after filling ords[idx] there remain 'uebrig' places to fill
 //for each row belonging to ords[idx].

 //now fill next_z_u and next_z_o 
 VEKTOR < short >& vec2=ZeilenZerlegung[reihenf_zeile[idx]];
 for(i=1;i<=_z;i++)
  {
   next_z_u[i]=0;
   int noch=z_soll[vec2[i]]-z_sums[vec2[i]];
   if(noch > MAX_VAL*uebrig)
    next_z_u[i]=noch-MAX_VAL*uebrig;

   next_z_o[i]=MAX_VAL*_s;
   if(noch < next_z_o[i])
    next_z_o[i]=noch;
  }

if(0)
 {
  printf("next_s_u=\n");
  for(i=1;i<=_s;i++)
   printf("%d ",next_s_u[i]);
  printf("\n");
  printf("next_s_o=\n");
   for(i=1;i<=_s;i++)
   printf("%d ",next_s_o[i]);
  printf("\n");
  printf("next_z_u=\n");
  for(i=1;i<=_z;i++)
   printf("%d ",next_z_u[i]);
  printf("\n");
  printf("next_z_o=\n");
  for(i=1;i<=_z;i++)
   printf("%d ",next_z_o[i]);
  printf("\n");
  fflush(stdout);
 }

 ords[idx]->GetIS_NULL_REP()=1; 
 m=0;
 for(i=1;i<=_s;i++)
  m+=next_s_u[i];
 if(m > 0)
  ords[idx]->GetIS_NULL_REP()=0; 
 n=0;
 for(i=1;i<=_z;i++)
  n+=next_z_o[i];
 if(m > n)
   return(0);

 m=0;
 for(i=1;i<=_s;i++)
  m+=next_s_o[i];
 n=0;
 for(i=1;i<=_z;i++)
  n+=next_z_u[i];
 if(n > 0)
  ords[idx]->GetIS_NULL_REP()=0; 
 if(m < n)
   return(0);

 if(Sp*Zei > GALE_LIMIT)
  {
   if((idx > 1)&&
      (reihenf_spalte[idx-1] == SpaltenZerlegung.Used()))
    {  
     gale_vek.ReAlloc(ZeilenZerlegung.Used());
     gale_vek.Clear();
     for(i=1;i < idx;i++)
      gale_vek.Set(reihenf_zeile[i]);
     m=Zei;
     for(i=1;i<=ZeilenZerlegung.Used();i++)
      if(gale_vek[i] == 1)
       m-=ZeilenZerlegung[i].Used(); 
     a_gale.Init(m,Sp,MAX_VAL);
     l=0;
     for(i=1;i<=ZeilenZerlegung.Used();i++)
      {
       if(gale_vek[i] == 0)
        {
         for(j=1;j<=ZeilenZerlegung[i].Used();j++)
           a_gale.SetZ(++l,z_soll[ZeilenZerlegung[i][j]]);
        }
      }
     for(i=1;i<=Sp;i++)
      a_gale.SetSp(i,sp_soll[i]-sp_sums[i]);

     if(! a_gale.Test()) 
       return(0);
    }
  }


 //now next_s_u,next_s_o,... are computed
 int _anz=0;
 for(i=1;i<=_s;i++)
  _anz+=next_s_o[i];
 j=0;
 for(i=1;i<=_z;i++)
  j+=next_z_o[i];
 if(j > _anz)_anz=j;
 
 ords[idx]->GetMAX_VAL() = MAX_VAL;
 ords[idx]->Anz()=_anz;

 for(i=1;i<=_s;i++)
  {
   ((ORDTREU_SP_Z_SUMS*)ords[idx])->Sp_U_Gr()[i]=next_s_u[i];
   ((ORDTREU_SP_Z_SUMS*)ords[idx])->Sp_O_Gr()[i]=next_s_o[i];
  }
 for(i=1;i<=_z;i++)
  {
   ((ORDTREU_SP_Z_SUMS*)ords[idx])->Zei_U_Gr()[i]=next_z_u[i];
   ((ORDTREU_SP_Z_SUMS*)ords[idx])->Zei_O_Gr()[i]=next_z_o[i];
  }

 if(COLUMN_WISE_NUMBERING==0)
  ((ORDTREU_SP_Z_SUMS*)ords[idx])->SetROWWISE_NUMBERING();
 else 	
  ((ORDTREU_SP_Z_SUMS*)ords[idx])->SetCOLUMN_NUMBERING(spaltenorder);
 ((ORDTREU_SP_Z_SUMS*)ords[idx])->Init(this);

 return(1);
}




#include "koorbase.h"



int KOORD_BASE::NextRep()
{
 int idx,ret;

 if(is_first[1] == 1)
  idx=1;
 else
  {
   idx=schritte;
   goto NEXT;
  }
 while(1)
  {
   if(BerechneEingabeData(idx) == 0)
    {
     if(idx == 1)
      return(0);
     else
      idx--; 
    }
   NEXT:
   ret=ords[idx]->NextRep();
   if(ret==0)
    {
     if(idx==1)
      return(0);
     else
      {
       idx--; 
       goto NEXT;
      }
    }
   else
    {
     NotiereTeilLoesung(idx);
     if(idx==schritte)
      {
       NotiereLoesung();
       if(PRINT_SOLUTIONS)
         PrintLoesung();
       return(1);
      }
     else
      idx++;
    } 
  }
}




void KOORD_BASE::FREE()
{
 G.FREE();
 is_first.FREE(); 
 for(int i=1;i<=ords_anz;i++)
  delete ords[i];
 free(ords);
 ords=NULL;
 ords_anz=0;
}






#ifndef MESS_H


#ifdef NO_STDERR

  static void FatalMess(char *nachricht)
  {
   FILE *fp;

   fp=fopen("error.out","w");
   fprintf(fp,"%s",nachricht);
   fclose(fp);
  }

#else

  static void FatalMess(char *nachricht)
  {
   fprintf(stderr,"%s",nachricht);
  }

#endif


#define MESS_H
#endif

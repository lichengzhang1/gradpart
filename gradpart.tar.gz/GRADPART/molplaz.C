#include "defs.h"
#include "molplaz.h"

#include <math.h>
#include <iostream.h>


//berechnet Zusammenhangskomponenten von NB,
//plaziert diese mit dem MOLGEN-Plazierer, und verteilt die 
//verschiedenen Komponenten auf der Zeichenflaeche.
//Die Koordinaten haben Werte zwischen 1 und 1000
//und werden in x_coord bzw. y_coord gespeichert.




void CompZshg_and_Plaz(int dim,ARRAY < VEKTOR < short > >& NB,
                       VEKTOR < short >& x_coord,
                       VEKTOR < short >& y_coord)
{
 int i,j,k,l;

 ARRAY < VEKTOR < short > >  komponenten;
 komponenten.REALLOC(dim,dim);
 BITVEK bits;
 bits.ReAlloc(dim);
 bits.Clear();

 komponenten.Used()=0;
 while(1)
  {
   i=1;
   while((i <= dim)&&(bits[i]==1))  
    i++;
   if(i == dim+1)
    break;
   komponenten.Used()++;
   j=komponenten.Used();
   komponenten[j].Used()=1;
   komponenten[j][1]=i;
   bits.Set(i);
   k=1;
   while(k <= komponenten[j].Used())
    {
     for(l=1;l<=NB[komponenten[j][k]].Used();l++)
      {
       if(bits[NB[komponenten[j][k]][l]]==0)
        {
         bits.Set(NB[komponenten[j][k]][l]);
         komponenten[j][++komponenten[j].Used()]=
          NB[komponenten[j][k]][l];
        }  
      }
     k++; 
    } 
  }
 
 ARRAY < VEKTOR < short > >  temp_x; 
 ARRAY < VEKTOR < short > >  temp_y; 
 temp_x.REALLOC(komponenten.Used(),dim);
 temp_y.REALLOC(komponenten.Used(),dim);


 ARRAY < VEKTOR < short > >   NBklein;
 NBklein.REALLOC(dim,dim);
 
 //durchlaufe jetzt die Komponenten, erstelle die 
 //Nachbarschaftsliste und fuelle eine Molekuelstruktur
 //damit.
 VEKTOR < short > grade;
 for(i=1;i<=komponenten.Used();i++)
  {
   for(j=1;j<=komponenten[i].Used();j++)
    NBklein[j].Used()=0;
   for(j=1;j<=komponenten[i].Used();j++)
    {  
     for(k=1;k<=NB[komponenten[i][j]].Used();k++)
      {
       for(l=j+1;l<=komponenten[i].Used();l++)
        { 
         if(NB[komponenten[i][j]][k] == komponenten[i][l])
          {
           NBklein[j][++NBklein[j].Used()]=l;
           NBklein[l][++NBklein[l].Used()]=j;
          } 
        }
      }
    }

   if(komponenten[i].Used()==1)
    {
     temp_x[i][1]=500;
     temp_y[i][1]=500;
    }
   else
    {
   #ifdef USE_MOLGEN_PLAZIERER     
     mol=new Molecule;
     if(mol==NULL)
      {
       FatalMess("memory exceeded in CompZshg_and_Plaz\n");
       exit(0);
      }  
     grade.ReAlloc(komponenten[i].Used());
     grade.Used()=0;
     for(j=1;j<=komponenten[i].Used();j++)
      {
       l=0;
       for(k=1;k<=grade.Used();k++)
        if(grade[k]==NBklein[j].Used())
         l=1;
       if(l==0)
        grade[++grade.Used()]=NBklein[j].Used();
      }  
     if(! mol->allocate(grade.Used(),komponenten[i].Used(),0)) 
      {
       FatalMess("memory exceeded in mol->allocate\n");
       exit(0);
      }
     mol->setTypeC(grade.Used());
     mol->setAtomC(komponenten[i].Used());
     mol->setHC(0);
     mol->setFVC(0);
     mol->setEnergy(-1.0);
     mol->setMolName("");
     for(j=1;j<=grade.Used();j++)
      {
       l=0;
       for(k=1;k<=komponenten[i].Used();k++)
        if(grade[j]==NBklein[k].Used())
         l++;
       mol->atomType(j-1).set("Q",grade[j],0,l);
      }

     for(j=1;j<=komponenten[i].Used();j++)
      {
       mol->atom(j-1).hydrogen_c=0;
       mol->atom(j-1).free_val=0;
       for(k=1;k<=grade.Used();k++)
        {
         if(grade[k]==NBklein[j].Used())
          {
           l=k;
           break;
          }
        }
       mol->atom(j-1).typenum=l-1;
      }
     for(j=1;j<=komponenten[i].Used();j++)
       for(k=1;k<=NBklein[j].Used();k++)
         mol->Ctab(j-1,NBklein[j][k]-1).symbol=1;

     display_mbf_2d(*mol); 

     //fuelle jetzt temp_x[i] und temp_y[i]

     for(j=0;j<komponenten[i].Used();j++)
      {
       temp_x[i][j+1]=mol->atom2D(j).x;
       temp_x[i][j+1]*=0.8;
       temp_x[i][j+1]+=5000;
       temp_x[i][j+1]/=10;
       temp_y[i][j+1]=mol->atom2D(j).y;
       temp_y[i][j+1]*=0.8;
       temp_y[i][j+1]-=5000;
       temp_y[i][j+1]/=10;
       temp_y[i][j+1]*=-1;
      }
     delete mol;
   #else
     //Ordne die Knoten einfach auf einem Kreis an
     for(j=1;j<=komponenten[i].Used();j++)
      {  
       double d1;
       d1 = 6.28/komponenten[i].Used();
       d1 *= (j-1);
       temp_x[i][j] = (short)(400*cos(d1)); 
       temp_x[i][j]+=500;
       temp_y[i][j] = (short)(400*sin(d1)); 
       temp_y[i][j]+=500;
     }
   #endif
    }
  }

 short a_x[] = {1,2,2,2,3,3,3,3,3,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,6,6,6}; 
 short a_y[] = {1,1,2,2,2,2,3,3,3,3,3,3,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6};
 //fuer die Aufteilung der Zeichenflaeche

 short x_l = 1000/a_x[komponenten.Used()-1];
 short y_l = 1000/a_y[komponenten.Used()-1];
 short x_nr,y_nr;
 for(i=1;i<=komponenten.Used();i++)
  {
   x_nr = ((i-1) % a_x[komponenten.Used()-1])+1;
   y_nr = ((i-1) / a_x[komponenten.Used()-1])+1;
   for(j=1;j<=komponenten[i].Used();j++)
    {
     x_coord[komponenten[i][j]] =  temp_x[i][j];
     x_coord[komponenten[i][j]] /= a_x[komponenten.Used()-1];
     x_coord[komponenten[i][j]] += (x_nr-1) * x_l;
     y_coord[komponenten[i][j]] =  temp_y[i][j];
     y_coord[komponenten[i][j]] /= a_y[komponenten.Used()-1];
     y_coord[komponenten[i][j]] += (y_nr-1) * y_l;
    }
  }

 x_coord.Used()=dim;
 y_coord.Used()=dim;
 
}



#ifndef GRADPART_H

#include "ordgraph.h"
#include "dnkkoord.h"
#include "spzkoord.h"
#include "can_num.h"


class GRADPART
{  
 protected:

  VEKTOR < short >               a,b,c;
  //degree partitions as in 'DIPLOMARBEIT'
  int                       MAX_VAL;
  //maximal connection-multiplicity
  char                           ONLY_CONN_GRAPHS;
  //==1, if only connected graphs are computed
  char                           TREES_ONLY;
  char                           GIRTH;
  GIRTH_TEST                     a_gir_test;
  char                           GIRTH_AND_IMPL;
  //==1, falls im Falle von H_Verteilung implizit
  //     berechnet werden darf
  
  char                           ONLY_CRITICAL;
  //==1, if only candidates for critical graphs shall be constructed
  char                           CRITICAL_GRAD;


  VEKTOR < short >               max_bind;
  //max_bind[i] ist die Anzahl der knoten max. Grades, die
  //momentan noch i Bindungen nach links frei haben
  char                           LeftRepCRITICAL_flag;
  BrFiSe                         a_search;
  char                           GO_IMPL;
  //==1, if we store solutions implicitly
  //==0, otherwise
  char                           CONN_AND_IMPL_Sp;
  char                           CONN_AND_IMPL;
  //wird waehrend der Berechnung gesetzt
  char                           IMP_IF_CONN;
  //==1, if we are allowed to construct implicitly,
  //     only if the constructed graphs at this step
  //     are all connected. 
  //nur relevant fuer ONLY_CONN_GRAPHS == 0
  char                           H_Verteil_Flag;
  int                       m;
  //maximal degree
  VEKTOR < short >               _H,_T;
  BITVEK                         _HT;
  //these vectors encode, how to split a.
  ARRAY < VEKTOR < short > >     c_i_j,b_i_j; 
  // 'partition-table'
  int                       dim; 
  //number of vertices of G
  int                       l_dim;
  //number of vertices of H 
  int                       r_dim;
  //number of vertices of T 
  MULTGRAPH                      L_MULT,R_MULT;
  //L_MULT for H, R_MULT for T
  GRADPART                       *L_GRAD,*R_GRAD;
  //L_GRAD for H, R_GRAD for T
  int                       POSSIBLE_SPLITS;
  //number of possible splits
  int                       SPLITS_UNTIL_NOW;
  //number of splits until now
  char                           PRINT_SPLITS_UNTIL_NOW;
  char                           AUT_IS_ID;
  DNK_KOORD                      DNK;
  //used to compute the double-cosets
  char                           first_DNK_rep;
  ORD_SP_Z_KOORD                 KOORD; 
  //used to fill I
  ALL_PART                       PART;
  //computes the rows of the partition-table
  VEKTOR < short >               z_sums;
  //row-sums of the adjacency matrix belonging
  //to the current representative with degree partition a.
  ARRAY < VEKTOR < short > >     I_Sum;
  //contains the row - and columnsums belonging
  //to DNK.p_i_j()
  char                           SPLIT_MAX;
  char                           SPLIT_MIDDLE;
  char                           SPLIT_50_50;
  //these flags determine, how to split a 
  char                           first,first_split;
  char                           go_L_MULT;
  char                           go_R_MULT;
  LANGZAHL                       LOESUNG_ANZ;
  ARRAY < VEKTOR < short > >     NBdummy;
  ARRAY < VEKTOR < short > >     NBlist;  
  ARRAY < VEKTOR < short > >     NBrestr;  
  ARRAY < VEKTOR < short > >     NBwert;  
  ARRAY < VEKTOR < short > >     I_ConnList;  
  LABRA_TG                       H_VER_LAB;
  //wird nur im Falle von H-Verteilung gebraucht
  short                          TIEFE;
  int                       l_,r_,l_ind,r_ind;
  char                           d[500],z[500],s[500];
  short                          FIRST_COL_NR;
  //number of the first column according to the whole
  //matrix.    


  /****************************************************/
  /*  structures used in the case GO_IMPL == 1        */
  /****************************************************/

  BITVEK                         l_impli;
  BITVEK                         r_impli;
  //l_impli[x] == 1  <=> row x is stabilized by LeftAUT
  //r_impli[x] == 1  <=> column x is stabilized by RightAUT


  /****************************************************/
  /*  Internal functions                              */
  /****************************************************/

  int                       ImplDurchlauf();
  //==1, if implicit construction is allowed at this stage.
  void                           ComputeCONN_AND_IMPL();
  int                       CheckRestrictions();
  //checks, if a found representative contradicts to 
  //a restriction 
  int                       CheckRestrictionsSplit();
  //checks, if a found split contradicts to a restriction. 
  int                       Is_H_Verteilung();
  int                       NextKoordRep();
  void                           InitNBRestr(); 
  int                       NextSplit(); 
  //computes the next valid partition-table
  virtual void                   InitLeftData();
  //computes input data for and initializes L_MULT or L_GRAD 
  virtual void                   InitRightData();
  //as InitLeftData
  virtual int               LeftNextRep();
  virtual int               RightNextRep();
  void                           Init_DNK_Data();
  //computes input data for and initializes DNK
  void                           Init_KOORD_Data();
  //computes input data for and initializes KOORD
  void                           NotiereImplData();
  //notes the information needed to store implicit solutions  
  void                           DeleteImplData();
  int                       NextDnkRep();
  void                           Compute_H_T();
  //computes _H and _T according to the 'split-flags'.
  virtual char                   LeftAUT_IS_ID();  
  virtual char                   RightAUT_IS_ID();  
  virtual LABRA_TG&              LeftAUT();
  virtual LABRA_TG&              RightAUT();
  virtual ARRAY < VEKTOR < short > >&    RightNBList();
  virtual ARRAY < VEKTOR < short > >&    LeftNBList();
  ARRAY < VEKTOR < short > >&    ConnList();
  virtual ARRAY < VEKTOR < short > >&    RightNBWert();
  virtual ARRAY < VEKTOR < short > >&    LeftNBWert();
  virtual int               Left_Z_SUM(int i);  
  virtual int               Right_Z_SUM(int i);  
  void                           NotiereErg();
  int                       PARTITION(int ind,int f);
  //computes row ind of the partition-table.
  //If f==0, the first partition of a[ind] is inserted.
  int                            IsValidDNK();
  /****************************************************/

 public:
                                 GRADPART(); 
                                 ~GRADPART(); 

  virtual void                   Init();
  //initializes b,c,m,_H,_T,c_i_j,b_i_j,dim,l_dim,r_dim,z_sums
  //a has to be allocated and initialized from the outside.
  void                           FREE();
  //frees all dynamically allocated memory
  int                       NextRep();
  //computes the next representative
  void                           ComputePossibleSplits();
  void                           SaveSplitTree();
  int                       GirthSet(int z,int sp,int wert);
  void                           GirthDel(int z,int sp);
  int                       CriticalSet(int z,int sp,int wert);

  ARRAY < VEKTOR < short > >&    GetNBList() { return(NBlist); }
  ARRAY < VEKTOR < short > >&    GetNBWert() { return(NBwert); }
  LABRA_TG&                      GetAUT();
  int                       GetDim() { return(dim); }
  int&                      GetMAXVAL() { return(MAX_VAL); }
  char&                          GetCONN() { return(ONLY_CONN_GRAPHS); }
  char&                          GetGIRTH() { return(GIRTH); }
  char&                          GetTREES_ONLY() { return(TREES_ONLY); }
  char&                          GetGIRTH_AND_IMPL() { return(GIRTH_AND_IMPL); }
  char&                          GetIMP_IF_CONN() { return(IMP_IF_CONN); }
  int                       Getl_dim() { return(l_dim); }
  VEKTOR < short >&              GetPart() { return(a); }
  char                           GetAUT_IS_ID() { return(AUT_IS_ID); } 
  void                           EnableSPLIT_MAX();
  void                           EnableSPLIT_MIDDLE();
  void                           EnableSPLIT_50_50(); 
  int                       GetZ_SP_SUM(int i);
  void                           SetCRITICAL(int CR_GR);
  short&                         GetTIEFE() { return(TIEFE); } 
  char&                          GetGO_IMPL() { return(GO_IMPL); }
  short&                         GetFIRST_COL_NR() 
                                  { return(FIRST_COL_NR); } 
  LANGZAHL&                      GetLOES() { return(LOESUNG_ANZ); }
                          
  int                       GetSplitsUntilNow()
                                  { return(SPLITS_UNTIL_NOW); }
  int                       GetPossSplits()
                                  { return(POSSIBLE_SPLITS); }
  void                           SetPRINT_SPLITS() { PRINT_SPLITS_UNTIL_NOW=1; }

  int&                      GetKrL();
};



#define GRADPART_H
#endif


#ifndef ORDTREU_H

#include "ordhash.h"
#include "labra.h"

typedef void (*R_D)(int z,int sp);
typedef int  (*R_S)(int z,int sp,int wert);

class KOORD_BASE;

class ORDTREU
{
 protected:

  /*******************************************************/
  /* structures accesible from outside                   */
  /*******************************************************/

  short             s,z;
  // s= #columns, z= #rows

  short            anz;
  //maximal number of 1's. 
  //( must be initialized from outside  )

  VEKTOR<short>    z_p,s_p;
  //row- and columnnumbers relative to the entire matrix 

  LABRA_TG            G,AUT;
  //Must be allocated from outside
  
  
  /*******************************************************/
  /* structures not accesible from outside               */
  /*******************************************************/

  char                                    StandAlone;

  R_D                                     R_D_f;
  R_S                                     R_S_f;

  ORDHASH                                 a_HASH;  

  KOORD_BASE                               *VATER;
  //in a non-standalone version this is a pointer 
  //to the base class that provides the functions
  //Set and Del. 

  char                                    GROUP_IS_ID;
  //==1, if the operating group is the idendity;
  //in this case most of the data-structures need not
  //be allocated.

  char                                    AUT_IS_ID;
  //==1, if the automorphism group of the current
  //representative is the idendity.

  char                                    INDUCED_GROUP_IS_ID;
  //==1, if the induced group is id => no fusels etc. are needed

  LABRA_TG                                *OP_G;
  //pointer to the operating group, if INDUCED_GROUP_IS_ID==1,
  //but GROUP_IS_ID == 0 

 /******************************************************/  
 /* BE CAREFUL: DON'T TOUCH G OR AUT, IF THE TWO UPPER */
 /*             FLAGS ARE EQUAL TO 1 !!!!!!!           */ 
 /******************************************************/  

  char                                    IS_NULL_REP;
  //==1, if the empty matrix is a solution too.
  char                                    IS_FIRST;
  //==1, if we are in NextRep for the first time after
  //calling Init().
  int                                LOESUNG_ANZ;         
  //number of solutions
  short                                   last_max_ind;
  //number of 1's of the last candidate corresponding
  //to the new candidate
  VEKTOR<short>                           stabindex;        
  //Is used by WechsleBasis
  VEKTOR<short>                           merke;
  //is used by UpdateNullbahn and UpdateEinsbahn
  char                                    ENABLE_HASH;
  //Hashing is used in MinTest, if this variable is 
  //equal to 1
  char                                    ENABLE_AUT;
  //AutErzInd and AutTransInd are filled, if this variable
  //is equal to 1 

  char                                    ENABLE_ROWWISE_NUMBERING;
  char                                    ENABLE_PERMUT_NUMBERING;
  PERMUT<short>                           permut_v;
  char                                    ENABLE_GEO_NUMBERING;
  PERMUT<short>                           spaltenorder;
  PERMUT<short>                           spaltenorder_inv;
  char                                    ENABLE_COLUMN_NUMBERING;

  char                                    USED_BY_DNK;
  ARRAY < VEKTOR < short > >              DNK_FUS;
  ARRAY < VEKTOR < short > >              ZeilenBahnen; 
		
  short                                   STUFE;
  //Needed in MinTest for correct use of AutErzInd
  short                                   ZURUECK;
  //denotes the number of possible steps backwards, after
  //a candidate has been rejected by MinTest
  char                                    PRINT_SOLUTIONS;
  //==1 , if the solutions shall be printed as a matrix
  char                                    PRINT_ANZ_CANDIDATES;
  //==1, if the number of representatives and the number of candidates 
  //     shall be printed to stdout.
  char                                    BESTANDEN;
  //this variable is equal to 1, if the candidate has not been rejected
  char                                    PERMFLAG;
  //equal to 1, if in the actual subtree of MinTest
  //further automorphisms have to be searched
  char                                    PRINT_CANDIDATES;
  //if this variable is == 1, then the candidates of MinTest
  //are printed to stdout
  int                                ANZ_CANDIDATES;
  //number of candidates until now
  int                                MAXREK;
  //number of vertices of the backtrack-tree of the last candidate  
  VEKTOR<short>                           inv_sz_p; 
  //Must be allocated from outside. This is the inverse
  //of s_p and z_p. 
  short                                   minrek_tiefe;
  //denotes the number of stabilized 1's in MinTest
  short                                   eins_anz;
  //denotes the number of 1's in the actual candidate
  char                                    MAX_VAL;
  //maximal entry in the matrix 
  char                                    LOW_MEM;
  //==1, if we have to save memory
  VEKTOR<short>                           MinTestInd;
  //variables used for navigating through the backtrack-tree
  //in MinTest. Because of this variables no recursion is needed.
  VEKTOR<int>                        InvHit;
  //the inverse of einsindex[1] 
  BITVEK                                  IsHit;
  //IsHit[i]==1, if einsindex[1][i] has been reached in
  //MinTest
  int                                min_gr_pos;
  ARRAY < BITVEK >                        nullbahn,einsbahn;
  ARRAY < PERMUT < short > >              fus_els;
  //array of permutations that is used to store the 
  //fusing elements in MinTest.
  ARRAY < PERMUT < short > >              Lern_fusels;
  //needed to compute the so-called LERNEFFEKT 
  BITVEK                                  LERNVEK;
  ARRAY < VEKTOR < short > >              fus_el_tab;
  //fus_el_tab[i][j] is the number of the permutation
  //in fus_els that transports place j onto the i-th 1.
  VEKTOR<short>                           Lern_fus_tab;
  short                                   fus_el_anz;
  PERMUT<short>                           transperm;
  //is used in MinTest to store the fusing element 
  VEKTOR < short >                        AutTransInd;
  //AutTransInd[i] denotes the number of 1's, which are
  //fixed by the i-th automorphism.
  ARRAY < ARRAY < VEKTOR < short > > >    AutErzInd;
  //(AutErzInd[i][1][1],AutErzInd[i][1][2]), 
  //(AutErzInd[i][2][1],AutErzInd[i][2][2]), 
  //(AutErzInd[i][3][1],AutErzInd[i][3][2]), 
  //  usw.
  //are the indices of the fusel's that have to be
  //multiplied to get the i-th automorphism.
  int                                AutErzAnz;
  //number of stored automorphisms
  VEKTOR < char >                         sp_summe,z_summe;
  //actual row- and columnsums
  ARRAY < VEKTOR < char > >               K;
  //matrix that contains the candidate
  BITVEK                                  dummy;
  ARRAY < VEKTOR < short > >              einsindex;
  //numbers of the places that contain a entry > 0.
  //Used in MinTest to avoid running through the 
  //whole matrix K.
  ARRAY < VEKTOR < short > >              eins_werte;
  //the entries of einsindex
  VEKTOR<short>                           eins_plaetze;
  //numbers of the places of the candidate that contain a  
  //a value > 0
  VEKTOR<short>                           platz_wert;
  //platz_wert[i] is the entry at position eins_plaetze[i] 
  ARRAY < VEKTOR < short > >              z_sp_to_nr;
  //z_sp_to_nr[i][j] denotes the number of the place (i,j)
  //according to the rowwise numbering of the matrix.
  //This is used in order to avoid unnecessary multiplications.
  VEKTOR<short>                           nr_to_z;
  //nr_to_z[ind] denotes the row of the place with number ind.
  VEKTOR<short>                           nr_to_sp;   
  //nr_to_sp[ind] denotes the column of the place with number ind.

  /*******************************************************/
  /*  intern functions                                   */
  /*******************************************************/

  void             Berechne_Platzumrechnung();
  //Here the numbering of the matrix is computed.
  //Mostly we will use a rowwise numbering of the places,
  //but all other alternatives are possible.

  void             PrintLoesung();
  //prints a found representative to stdout.

  void             NotiereLoesung();
  //fills K with the found representative using eins_plaetze.

  int         ComputeTransperm_1(int u);
  void             ComputeTransperm_2();
  //in MinTest these functions compute the permutation that 
  //transports the candidate onto the matrix that represents
  //the stage of the recursion tree where we currently are.

  void             ComputeZURUECK_1(int i,int u);
  void             ComputeZURUECK_2(int min_diff);
  //in MinTest these functions compute, how far we can go back
  //in the generation

  void             NotiereAutomorphismus();
  //used to store found automorphisms in MinTest

  PERMUT<short>&   fus_el(int i,int j);
  PERMUT<short>&   fus_el_alt(int i,int j);
  //this function returns a fusing element;

  PERMUT<short>&   Lern_fus(int i);

  virtual int      IsErlaubt(int platz,int wert) = 0;
  //this function returns
  //  - 1, if it is allowed to set the entry 'wert' at the place 
  //       with number platz
  //  - 2, if it is allowed to set the entry 'wert' at the place 
  //       with number platz and the candidate fulfills
  //       all the constraints
  //  - 0, otherwise

  
  virtual void     DelFunc(int _zei,int _sp) { return; }

  void             Update_Nullbahn(int eins_nr);
  //computes the characteristic function of the places 
  //(eins_zeile[eins_nr-1],eins_spalte[eins_nr-1]+1),...,
  //(eins_zeile[eins_nr],eins_spalte[eins_nr]-1) under
  //the operation of the stabilizer of the first
  //eins_nr-1 1's.

  void             Update_Einsbahn(int eins_nr);
  //computes the characteristic function of  
  //(eins_zeile[eins_nr],eins_spalte[eins_nr]) under
  //the operation of the stabilizer of the first
  //eins_nr-1 1's.

  void             WechsleBasis();
  //Changes the basis of G so that the 1's of the candidate
  //are stabilized one after the other.

  void             InitMinTestData();
  //This function is called before a MinTest is performed.
  //It initializes some needed data structures.

  virtual int      MinTest();
  //transperms are not used any more.
  //If the automorphism group is needed, only AutErzInd
  //is filled in MinTest. Only when the candidate is not 
  //rejected by MinTest the automorphisms are computed by
  //multiplying the corresponding fusel's.

  void             ComputeNext_einsindex();
  //is used in MinTest to compute the matrix that is obtained
  //in the next step of the recursion in MinTest. 
  //Notice: not the whole matrix is computed, but only the
  //        numbers of the places of the 1's which have other 
  //        positions than the 1's in the step before.

  int         CompareNext_einsindex();
  //here the new computed matrix is compared with the candidate.
  //If this matrix is lexicographically smaller than the candidate
  //the the candidate is rejected.


  virtual void     BerechneAut();
  //computes the automorphism group of a representative

  int         Anwende(PERMUT<short>& pi,int nr);
  //describes the operation of G: the return value is the number 
  //of the place,  which is obtained when you apply pi to the 
  //point nr.

 public:
                   ORDTREU();
                   virtual ~ORDTREU() { }

 void              Init(int alone);  
 //Initialize and eventually realloc the data-structures.
 //The input - data has to be set from the outside using
 //the functions below.

 void              Init(KOORD_BASE* _VATER);
 //Same function as above, but is used in non-standalone versions 

 void              FREE(); 

 int          NextRepID();
 //to have a better survey this function is used instead 
 //of NextRep() if GROUP_IS_ID == 1

 int          NextRep();
 //returns 1, if a representative has been found. The representative
 //and his stabilizer then can be reached from the outside.
 //All the data - structures remain so that with a new call
 //to this function the next representative is computed.


 short&            Spalten()   { return(s);   } 
 short&            Zeilen()    { return(z);   } 
 VEKTOR<short>&    Zei_Nr()    { return(z_p); }
 VEKTOR<short>&    Sp_Nr()     { return(s_p); }
 VEKTOR<short>&    Inv_sz()    { return(inv_sz_p); }
 VEKTOR<char>&     SpSumme()   { return(sp_summe); }
 VEKTOR<char>&     ZeiSumme()  { return(z_summe); }
 short&            Anz()       { return(anz); }
 LABRA_TG&         Gruppe()    { return(G);   }
 LABRA_TG&         AutGruppe() 
                    { 
                     if(INDUCED_GROUP_IS_ID == 0)
                      return(AUT); 
                     else
                      return(*OP_G);
                    }
 char              Erg(int i,int j)    { return(K[i][j]); } 

 void              SetGEO_NUMBERING()
                    { 
                      ENABLE_GEO_NUMBERING = 1;
                      ENABLE_COLUMN_NUMBERING = 0;
                      ENABLE_ROWWISE_NUMBERING = 0;
                      ENABLE_PERMUT_NUMBERING = 0;
                    }

 void              SetROWWISE_NUMBERING()
                    { 
                      ENABLE_GEO_NUMBERING = 0;
                      ENABLE_COLUMN_NUMBERING = 0;
                      ENABLE_ROWWISE_NUMBERING = 1;
                      ENABLE_PERMUT_NUMBERING = 0;
                    }

 void              SetPERMUT_NUMBERING(PERMUT<short>& per)
                    {
                      ENABLE_GEO_NUMBERING = 0;
                      ENABLE_COLUMN_NUMBERING = 0;
                      ENABLE_ROWWISE_NUMBERING = 0;
                      ENABLE_PERMUT_NUMBERING = 1;
                      permut_v = per;
                    }
 void              SetCOLUMN_NUMBERING(PERMUT<short>& per)
                    { 
                      ENABLE_GEO_NUMBERING = 0;
                      ENABLE_COLUMN_NUMBERING = 1;
                      ENABLE_ROWWISE_NUMBERING = 0;
                      ENABLE_PERMUT_NUMBERING = 0;
                      spaltenorder = per;
                      spaltenorder_inv = per;
                      spaltenorder_inv.Inv();
                    }
 void             SetLocalRestr(R_S _a,R_D _b) 
                    { R_S_f = _a; R_D_f = _b; }
 void             SetDNK_USE() { USED_BY_DNK = 1; }
                     
 void              SetOP_G(LABRA_TG *point)
                    { OP_G=point; }
 char&             GetMAX_VAL() { return(MAX_VAL); }
 char&             GetENABLE_AUT() { return(ENABLE_AUT); }   
 char&             GetPRINT_SOLUTIONS() { return(PRINT_SOLUTIONS); }   
 char&             GetPRINT_ANZ_CANDIDATES() { return(PRINT_ANZ_CANDIDATES); }   
 char&             GetPRINT_CANDIDATES() { return(PRINT_CANDIDATES); }   
 char&             GetGROUP_IS_ID() { return(GROUP_IS_ID); }
 char&             GetIND_GROUP_IS_ID() { return(INDUCED_GROUP_IS_ID); }
 char&             GetAUT_IS_ID() { return(AUT_IS_ID); }
 char&             GetIS_NULL_REP() { return(IS_NULL_REP); }
 void              SetLOW_MEM() { LOW_MEM=1; }
};




inline int ORDTREU::Anwende(PERMUT<short>& pi,int nr)
 {
  #ifdef DEBUG_TG
    if((nr < 1)||(nr > s*z))
     {
      FatalMess("Falscher Index bei ORDTREU::Anwende\n");
      EXIT();
     }
  #endif

  return(z_sp_to_nr[inv_sz_p[pi[z_p[nr_to_z[nr]]]]][inv_sz_p[pi[s_p[nr_to_sp[nr]]]]]);
 }




#define ORDTREU_H
#endif



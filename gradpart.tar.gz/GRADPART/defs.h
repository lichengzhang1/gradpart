#ifndef DEFS_H
#include <assert.h>
#include <string.h>
#include <time.h>

extern int DEBUG_LINE;
extern char DEBUG_FILE[];


#define DEBUG_LINE_FILE \
DEBUG_LINE = __LINE__; strcpy(DEBUG_FILE,__FILE__);


/*
#define DEBUG_LINE_FILE DEBUG_LINE = __LINE__; 

#define DEBUG_LINE_FILE  {}
*/

#define EXIT() \
 printf("ZEILE = %d\n",DEBUG_LINE); \
 printf("FILE = %s\n",DEBUG_FILE); \
 fflush(stdout); \
 exit(0);



extern clock_t time1;
extern int VERBOSE; 
extern int HASH_LENGTH;
extern int GALE_LIMIT;
extern int SPLIT_KLEIN;
extern int SPLIT_MIN;
extern int SHIFT_PARTITIONS;
extern int STEPS_TO_SAVE;
extern int STEPS_SAVED;

#define DEFS_H
#endif


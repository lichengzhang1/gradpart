#ifndef DNK_KOORD_H

#include "orddnk.h"
#include "koorbase.h"


//This is a class to compute double cosets of the form
//(+)(+)S(p_i_j) \ (+)S(p_i) / G.
// -  (+)S(p_i) is a direct product of symmetric groups
//    of order p_i
// -  (+)S(p_i_j) is a subgroup of S(p_i) with 
//    p_i_1 + p_i_2 + ... == p_i
//The computation is done through a series of homomorphism
//steps. In each step ORDDNK can be used to solve the problem. 

#define MAX_RESTR_FUNC 10

typedef void (*RD)(int z,int sp);
typedef int  (*RS)(int z,int sp,int wert);

class DNK_KOORD : public KOORD_BASE
{
 protected:

  short                         SUCHGROESSE;
  ARRAY < VEKTOR < short > >    LOES;
  //LOES[k][1],...,LOES[k][p_i[k]] encodes the computed 
  //representative of (+)S(p_i_j[k]) \ S(p_i[k]) / G'.
  ARRAY < VEKTOR < short > >    aufteilung;
  int                      elem_schritte; 
  //number of p_i-parts
  VEKTOR < short >              s_von;
  VEKTOR < short >              s_bis;
  //in row r a 1 may only be set in columns i
  //with s_von[r] <= i <= s_bis[r].

/***************************************************/
/*                 INPUT-DATA                      */
/***************************************************/
  VEKTOR < short >              p_i;
  ARRAY < VEKTOR < short > >    p_i_j;
  ARRAY < VEKTOR < short > >    p_i_idx;
  //p_i_idx[j] contains the row-numbers that belong
  //to p_i[j].

/***************************************************/

 void                          NotiereTeilLoesung(int ind)
                                { return; }

 int                           restr_func_anz;

	RD                            RestrDel[MAX_RESTR_FUNC];
 RS                            RestrSet[MAX_RESTR_FUNC];

 public:

                                DNK_KOORD() : KOORD_BASE()
                                 { return; }

                                ~DNK_KOORD();
 
  void                          FREE();
 
  int                           NextRep();
  void                          Del(int z,int sp);
  int                           Set(int z,int sp,int wert);
  void                          Init();
  int                           BerechneEingabeData(int i);
  void                          BerechneAufteilung();
  void                          NotiereLoesung();   
  void                          PrintLoesung(); 
  void                          SetRestr(RS set,RD del);
  VEKTOR < short >&             Getp_i() { return(p_i); }
  ARRAY < VEKTOR < short > >&   Getp_i_j() { return(p_i_j); }
  ARRAY < VEKTOR < short > >&   Getp_i_idx() { return(p_i_idx); }
  char                          GetErg(int i,int j);
  LABRA_TG&                     GetAut(); 
};


#define DNK_KOORD_H
#endif






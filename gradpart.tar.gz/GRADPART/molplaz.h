#ifndef MOLPLAZ_H

#include "vector.t"
#include "array.t"
#include "bitvec.h"

//#define USE_MOLGEN_PLAZIERER

void CompZshg_and_Plaz(int dim,ARRAY < VEKTOR < short > >& NB,
                       VEKTOR < short >& x_coord,
                       VEKTOR < short >& y_coord);  



#define MOLPLAZ_H
#endif


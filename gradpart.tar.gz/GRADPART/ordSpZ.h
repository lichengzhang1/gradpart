#ifndef ORDTREU_SP_Z_SUMS_h

#include "ordtreu.h"



class ORDTREU_SP_Z_SUMS : public ORDTREU
{
 protected:

  VEKTOR<char>      s_u,s_o,z_u,z_o;
  //lower and upper bounds for row- and columnsums

  int IsErlaubt(int platz, int wert)
   {
    int i,j,von;

    if(ENABLE_COLUMN_NUMBERING)
     {
      //wird nur von Girthpart aus verwendet
      j = spaltenorder_inv[nr_to_sp[platz]];
      if((j > 1)&&(sp_summe[spaltenorder[j-1]] < s_u[spaltenorder[j-1]]))
       return(-1);
     }
 
    if((z_summe[nr_to_z[platz]]+wert > z_o[nr_to_z[platz]])||
       (sp_summe[nr_to_sp[platz]]+wert > s_o[nr_to_sp[platz]]))
      return(0); 

    if(ENABLE_ROWWISE_NUMBERING || ENABLE_GEO_NUMBERING)
     {
      if((z_u[nr_to_z[platz]]-z_summe[nr_to_z[platz]]) >
         ((s-nr_to_sp[platz]+1) * MAX_VAL))
       return(0);

      if((s_u[nr_to_sp[platz]]-sp_summe[nr_to_sp[platz]]) >
         ((z-nr_to_z[platz]+1) * MAX_VAL))
       return(0); 
     }

    if(ENABLE_ROWWISE_NUMBERING)
     {
      if(eins_anz == 0)
       von=1;
      else
       von=nr_to_z[eins_plaetze[eins_anz]];
      for(i=von;i < nr_to_z[platz];i++)
       {
        if(z_summe[i] < z_u[i])
         return(-1);
       }
     }
 
    if(ENABLE_GEO_NUMBERING)
     {
      if(eins_anz == 0)
       von=1;
      else
       {
        von=nr_to_z[eins_plaetze[eins_anz]];
        if(nr_to_sp[eins_plaetze[eins_anz]] < von)
         von=nr_to_sp[eins_plaetze[eins_anz]];
       }     
      int bis;

      bis=nr_to_z[platz];
      if(nr_to_sp[platz] < bis)
       bis=nr_to_sp[platz];

      for(i=von;i < bis;i++)
       {
        if(z_summe[i] < z_u[i])
         return(-1);
        if(sp_summe[i] < s_u[i])
         return(-1);
       }
     }

    if((s_u[nr_to_sp[platz]] <= sp_summe[nr_to_sp[platz]]+wert) &&
       (s_o[nr_to_sp[platz]] >= sp_summe[nr_to_sp[platz]]+wert) &&
       (z_u[nr_to_z[platz]] <= z_summe[nr_to_z[platz]]+wert) &&
       (z_o[nr_to_z[platz]] >= z_summe[nr_to_z[platz]]+wert))
     {
      for(i=1;i<=z;i++)
       if((i != nr_to_z[platz])&&(z_u[i] > z_summe[i]))
         return(1);
      for(i=1;i<=s;i++)
       if((i != nr_to_sp[platz])&&(s_u[i] > sp_summe[i]))
         return(1);
      return(2);
     }

   return(1);
  }


 public:
                    ORDTREU_SP_Z_SUMS();
                    ~ORDTREU_SP_Z_SUMS();
 
  VEKTOR<char>&     Sp_U_Gr();
  VEKTOR<char>&     Sp_O_Gr();
  VEKTOR<char>&     Zei_U_Gr();
  VEKTOR<char>&     Zei_O_Gr();
  void              Init(int alone);                    
  void              Init(KOORD_BASE *_VATER); 

};




#define ORDTREU_SP_Z_SUMS_h
#endif



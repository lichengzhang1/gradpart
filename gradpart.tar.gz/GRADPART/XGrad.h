/* gp.h */

#include "div.h"


#ifdef DEC_ALPHA
  #include <poll.h>
#endif




#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <Xm/MessageB.h>
#include <Xm/DialogS.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/LabelG.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <Xm/MainW.h>

#include <StringDefs.h>
#include <Intrinsic.h>
#include <Protocols.h>
#include <Shell.h>
#include <Xutil.h>
#include <cursorfont.h>
#include <Xlib.h>
#include <Xatom.h>
#include <Xm.h>
#include <BulletinB.h>
#include <CascadeB.h>
#include <DrawingA.h>
#include <Label.h>
#include <FileSB.h>
#include <PushB.h>
#include <PushBG.h>
#include <RowColumn.h>
#include <SelectioB.h>
#include <Separator.h>
#include <ScrolledW.h>
#include <ScrollBar.h>
#include <Text.h>


typedef struct gp_dial GP_DIAL;



struct gp_dial 
{

  Widget all_form;
     Widget param_form;
        Widget param_frame;
           Widget param_frame_form;
              Widget dp_form;
                 Widget dp_label;
                 Widget dp_text;
                 Widget dp_file;
              Widget mode_form;
                 Widget dp_vert_frame;
                    Widget dp_vert_form;
                       Widget dp_vert_label;
                       Widget dp_vert_radiobox;
                          Widget degree_toggle;
                          Widget vertex_toggle;
                 Widget vert_edge_frame;
                    Widget vert_edge_form;
                       Widget vert_edge_label;
                       Widget vert_edge_up_form;
                          Widget vert_edge_up_label;
                          Widget vert_edge_up_text;
                       Widget vert_edge_down_form;
                          Widget vert_edge_down_label;
                          Widget vert_edge_down_text;
                 Widget flags_frame;
                    Widget flags_form;
                       Widget flags_form_label;
                       Widget flags_form_opt_button;
                       Widget flags_form_split_button;
                       Widget flags_form_constr_button;
              Widget step_form;
                 Widget step_label;
                 Widget step_text;
                 Widget time_label;
     Widget button_form;
        Widget quit_button;
        Widget start_button;
        Widget stop_button;
        Widget draw_button;
        Widget restr_button;
     Widget scrolled_text;

  Widget file_sel_shell;
     Widget file_sel_box;

  Widget options_form_dialog;
     Widget opt_up_form;
      Widget opt_form_ok;
     Widget opt_down_form;
        Widget opt_frame;
           Widget opt_frame_form;
              Widget opt_prompt_label;
              Widget opt_prompt_split_toggle;
              Widget opt_prompt_verbose_toggle;
              Widget opt_prompt_goimpl_toggle;
              Widget opt_prompt_reconstr_toggle;

  Widget split_form_dialog;
     Widget split_up_form;
        Widget split_form_ok;
     Widget split_down_form;
        Widget split_down_frame;
           Widget split_down_frame_form;
              Widget spl_d_fr_f_label;
              Widget spl_d_fr_f_radiobox;
                 Widget spl_d_fr_f_split_middle;
                 Widget spl_d_fr_f_split_max;
                 Widget spl_d_fr_f_split_50_50;
              Widget spl_d_fr_f_min_form;
                 Widget spl_d_fr_f_min_label;
                 Widget spl_d_fr_f_min_text;

  Widget constr_form_dialog;
     Widget constr_up_form;
        Widget constr_form_ok;
     Widget constr_down_form;
        Widget constr_down_frame;
           Widget constr_down_frame_form;
              Widget con_d_f_label;
              Widget con_d_fr_f_fr1;
                 Widget con_d_fr_f_radiobox1;
                    Widget con_d_fr_f_smblfi;
                    Widget con_d_fr_f_lablfi;
              Widget con_d_fr_f_fr2;
		 Widget con_d_fr_f_radiobox2;
		    Widget con_d_fr_f_maincfi;
		    Widget con_d_fr_f_feincfi;
		    Widget con_d_fr_f_avincfi;

  Widget restr_form_dialog;
     Widget restr_up_form;
        Widget restr_form_ok;
     Widget restr_down_form;
        Widget restr_down_frame;
           Widget restr_down_frame_form;   
              Widget restr_conn_toggle;
              Widget restr_tree_toggle;
              Widget restr_girth_form;
                 Widget restr_girth_label;
                 Widget restr_girth_text;
              Widget restr_bond_form;
                 Widget restr_bond_label;
                 Widget restr_bond_text;


  Widget error_dialog_shell;
     Widget error_dialog;

};


GRAPH_PART a_part;


char OP_ACTIVE,SPLIT_ACTIVE,CONSTR_ACTIVE,RESTR_ACTIVE;

int main(int argc, char **argv);

Widget wnd_toplevel;
GP_DIAL *gl_gp_dial;

XFontStruct *gp_fnt;
XmFontList gp_font1, gp_curfont;

XtAppContext gl_app;
XtIntervalId PipeId;
XtIntervalId TimeId;

int seconds,minutes,hours,days,seconds_10;
int delay;

int help_pid;
FILE *erg_pipe;
char sig_line[1000];
void handler(int a);

char is_in_pipe;
char is_running;

char* err_string[] = 
 {"couldn't read 'split_min' !!",
  "wrong degree-partition format !!",
  "degree sum is not divisible by 2 !!",
  "no graphical partition !!",
  "degree can't be greater than (number of vertices-1)*MAXBOND !!",
  "couldn't read steps to store !!",
  "stop old computation first !!",
  "there is no computation running !!",
  "couldn't read number of vertices !!",
  "couldn't read number of edges !!",
  "Internal error!!",
  "couldn't open file !!",
  "wrong file format !!",
  "no file selected !!",
  "couldn't read girth !!",
  "couldn't read MAXBOND !!",
  "if TREES_ONLY==1, then MAXBOND must be equal to 1 !!" };


XColor Appcolor,Framecolor,Buttoncolor,Selectcolor,
       ErrorColor,exact;
char AppCol[] = "wheat1";
char FrameCol[] = "RoyalBlue4";
char ButtonCol[] = "wheat2";
char SelectCol[] = "red"; 
char ErrCol[] = "LightSkyBlue";

char _PRECOMPUTE_SPLITS_,_VERBOSE_,_GO_IMPL_,_RECONSTRUCT_ALL_;
short _SPLIT_MIN_;
char SPLIT_STRATEGY;
//middle=1, max=2, 50_50=3
char _SPLIT_KLEIN_;
char _SHIFT_PARTITIONS_;
//0=many incidences, 1=average, 2=few
char GIRTH,MAXBOND,CONN_GRAPHS,TREES_ONLY;


void CreateButtons();
int i_var();
int i_gp_dlg(void);
void GetColors();
void InitFlags();
void ErrorMessage(int i);


void flags_form_opt_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void flags_form_split_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void flags_form_constr_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void quit_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void start_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void stop_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void draw_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void restr_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void dp_file_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void file_sel_cancel(Widget w,XtPointer client_data,
                               XtPointer call_data);
void file_sel_ok(Widget w,XtPointer client_data,
                               XtPointer call_data);
void opt_form_ok_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void split_form_ok_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void constr_form_ok_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void restr_form_ok_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void error_dialog_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);









#include "ordConj.h"



void ORDTREU_CONJ_CLASSES::Init(int alone)
{
 int i;

 ORDTREU::Init(alone);

 if(ENABLE_PERMUT_NUMBERING)
  {
   permut_v_inv = permut_v;
   permut_v_inv.Inv();
   NextPosition.REALLOC(s,z);
   InvPos.REALLOC(s,s);
   NextPosition[permut_v[1]].Clear();
   if(s > 1)
    for(i=1;i<=Kette[1].Used();i++)
     {
      NextPosition[permut_v[1]].Set(Kette[1][i][permut_v[1]]);
      InvPos[permut_v[1]][Kette[1][i][permut_v[1]]]=i;
     }
   else
    NextPosition[permut_v[1]].Set(1);
  }
 else
  { 
   NextPosition.REALLOC(s,z);
   InvPos.REALLOC(s,s);
   NextPosition[1].Clear();
   if(s > 1)
    for(i=1;i<=Kette[1].Used();i++)
     {
      NextPosition[1].Set(Kette[1][i][1]);
      InvPos[1][Kette[1][i][1]]=i;
     }
   else
    NextPosition[1].Set(1);
  }    
}


void ORDTREU_CONJ_CLASSES::FREE()
{
 Kette.FREE();
 NextPosition.FREE();
 InvPos.FREE();

 ORDTREU::FREE();
}


SIMS& ORDTREU_CONJ_CLASSES::GetKette()
{ return(Kette); } 

ORDTREU_CONJ_CLASSES::ORDTREU_CONJ_CLASSES():ORDTREU()
{ }

ORDTREU_CONJ_CLASSES::~ORDTREU_CONJ_CLASSES()
{ }


inline int ORDTREU_CONJ_CLASSES::IsErlaubt(int platz,int wert)
{
 int i,j,k,l,_k;

 if(ENABLE_PERMUT_NUMBERING)
  {
   if(NextPosition[nr_to_z[platz]][nr_to_sp[platz]] == 0)
    return(0);
   for(i=1;i < permut_v_inv[nr_to_z[platz]];i++)
    if(z_summe[permut_v[i]] == 0)
     return(-1); 
   if(z_summe[nr_to_z[platz]] == 1)
     return(0);
   if(permut_v_inv[nr_to_z[platz]] < z-1)
    {
     //Compute possible positions for the next 1
     l = permut_v_inv[nr_to_z[platz]] + 1 ;
     _k = permut_v[l];
     NextPosition[_k].Clear();
     for(i=1;i<=Kette[l].Used();i++)
      {
       k = _k;
       k = Kette[l][i][k];
       k = Kette[l-1][InvPos[nr_to_z[platz]][nr_to_sp[platz]]][k];
       //platz ist bei eins_plaetze noch nicht dabei
       for(j=l-2;j > 0;j--)
         k = Kette[j][InvPos[permut_v[j]][nr_to_sp[eins_plaetze[j]]]][k];
     
       NextPosition[_k].Set(k);
       InvPos[_k][k] = i;
      }
     return(1);
    } 
 
   if(permut_v_inv[nr_to_z[platz]] == z-1)
    {
     NextPosition[permut_v[z]].Clear();
     for(i=1;i<=eins_anz;i++)
      NextPosition[permut_v[z]].Set(nr_to_sp[eins_plaetze[i]]);
     NextPosition[permut_v[z]].Set(nr_to_sp[platz]);
     ~NextPosition[permut_v[z]];
     return(1);
    }
   return(2);
  }
 else 
  {
   if(NextPosition[nr_to_z[platz]][nr_to_sp[platz]] == 0)
    return(0);
   for(i=1;i<nr_to_z[platz];i++)
    if(z_summe[i] == 0)
     return(-1); 
   if(z_summe[nr_to_z[platz]] == 1)
     return(0);
   if(nr_to_z[platz] < z-1)
    {
     //Compute possible positions for the next 1
     NextPosition[nr_to_z[platz]+1].Clear();
     for(i=1;i<=Kette[nr_to_z[platz]+1].Used();i++)
      {
       k=nr_to_z[platz]+1;
       k=Kette[nr_to_z[platz]+1][i][k];
       k=Kette[nr_to_z[platz]][InvPos[nr_to_z[platz]][nr_to_sp[platz]]][k];
       //platz ist bei eins_plaetze noch nicht dabei
       for(j=nr_to_z[platz]-1;j > 0;j--)
         k=Kette[j][InvPos[j][nr_to_sp[eins_plaetze[j]]]][k];
     
       NextPosition[nr_to_z[platz]+1].Set(k);
       InvPos[nr_to_z[platz]+1][k]=i;
      }
     return(1);
    } 
 
   if(nr_to_z[platz] == z-1)
    {
     NextPosition[z].Clear();
     for(i=1;i<=eins_anz;i++)
      NextPosition[z].Set(nr_to_sp[eins_plaetze[i]]);
     NextPosition[z].Set(nr_to_sp[platz]);
     ~NextPosition[z];
     return(1);
    }
   return(2);
  } 
}






#include "dnkkoord.h"
#include "defs.h"
#include <time.h>

int DNK_KOORD::NextRep()
{
 int idx,ret;


 if(is_first[1] == 1)
  idx=1;
 else
  {
   idx=schritte;
   goto NEXT;
  }
 while(1)
  {
   BerechneEingabeData(idx);
   NEXT:
   ret=((ORDDNK*)ords[idx])->NextRep();
   if(ret==0)
    {
     if(idx==1)
       return(0);
     else
      {
       idx--; 
       goto NEXT;
      }
    }
   else
    {
     if(idx==schritte)
      {
       NotiereLoesung();
       if(PRINT_SOLUTIONS)
         PrintLoesung();
       return(1);
      }
     else
      idx++;
    } 
  }
}



void DNK_KOORD::FREE()
{
 LOES.FREE();
 aufteilung.FREE();
 s_von.FREE();
 s_bis.FREE();
 p_i.FREE();
 p_i_j.FREE();
 p_i_idx.FREE();

 G.FREE();
 is_first.FREE(); 
 if(ords != NULL)
  {
   for(int i=1;i<=ords_anz;i++)
    delete ((ORDDNK*)ords[i]);
   free(ords);
   ords=NULL;
   ords_anz=0;
  } 
}



DNK_KOORD::~DNK_KOORD()
{
if(ords != NULL)
 {
  for(int i=1;i<=ords_anz;i++)
   delete ((ORDDNK*)ords[i]);
  free(ords);
  ords = NULL;
 } 
}





void DNK_KOORD::SetRestr(RS set,RD del)
{
 if(restr_func_anz == MAX_RESTR_FUNC)
  {
   printf("Can't set another restriction !\n");
   exit(0);
  }
 RestrSet[restr_func_anz] = set;
 RestrDel[restr_func_anz] = del;
 restr_func_anz++;
}


//all the input-data-structures have to be allocated
//before from the outside.

void DNK_KOORD::Init()
{
 int i,j;

 if(VERBOSE)
  {
   printf("Hier DNK_KOORD::Init\n");
   printf("Zei=%d\n",Zei);
   printf("GROUP_IS_ID=%d\n",GROUP_IS_ID);
   printf("p_i=\n");
   p_i.PrintUsed(0);
   printf("p_i_j=\n");
   for(i=1;i<=p_i.Used();i++)
    {
     printf("ARRAY-Nr.%d\n",i);
     p_i_j[i].PrintUsed(3);
    }
   printf("\n");
   printf("p_i_idx=\n");
   for(i=1;i<=p_i.Used();i++)
    {
     printf("ARRAY-Nr.%d\n",i);
     p_i_idx[i].PrintUsed(3);
    }
   printf("\n");
   fflush(stdout);
  }

 elem_schritte=p_i.Used();
// SUCHGROESSE=80;
 SUCHGROESSE=5;

 LOES.ReAlloc(elem_schritte);
 for(i=1;i<=elem_schritte;i++)
  {
   if(! LOES.IsAlloc(i))
    LOES.Add(i,p_i[i]);
   LOES[i].ReAlloc(p_i[i]);
  }

 s_von.ReAlloc(Zei);
 s_bis.ReAlloc(Zei);

 aufteilung.REALLOC(elem_schritte,elem_schritte);
 is_first.ReAlloc(elem_schritte);
 is_first.Clear();
 ~is_first;
 restr_func_anz=0;
}




void DNK_KOORD::BerechneAufteilung()
{
 int i,j,k,l,m,n;
 BITVEK d(elem_schritte);

 d.Clear();
 schritte=0;
 i=0;
 while(i < elem_schritte)
  {
   i++;
   if(d[i] == 0)
    {
     j=p_i[i];
     schritte++;
     aufteilung[schritte].Used()=1;
     aufteilung[schritte][1]=i;
     d.Set(i);
     k=i;
     while(j < SUCHGROESSE)
      {
       k++;
       if(k > elem_schritte)
        break;
       if((d[k]==0)&&(j+p_i[k] <= SUCHGROESSE))
        {
         d.Set(k);
         aufteilung[schritte][++aufteilung[schritte].Used()]=k;
         j+=p_i[k];
        }  
      }
    }
  }

 for(k=1;k<=schritte;k++)
  { 
   l=1;
   for(i=1;i<=aufteilung[k].Used();i++)
    {
     m=p_i_j[aufteilung[k][i]].Used();
     for(j=1;j<=p_i[aufteilung[k][i]];j++)
      {
       s_von[p_i_idx[aufteilung[k][i]][j]]=l;  
       s_bis[p_i_idx[aufteilung[k][i]][j]]=l+m-1;  
      }
     l+=m;
    }
  }

if(VERBOSE)
 {
  printf("Nach BerechneAufteilung\n");
  printf("schritte=%d\n",schritte);
  printf("Aufteilung=\n");
  for(i=1;i<=schritte;i++)
   {
    aufteilung[i].PrintUsed(0);
    printf("\n");
   }
  printf("von-bis:\n");
  for(i=1;i<=Zei;i++)
    printf("%d : von %d bis %d\n",i,s_von[i],s_bis[i]);
  printf("\n");
 }

}






LABRA_TG& DNK_KOORD::GetAut()
{
 #ifdef DEBUG_TG
  if(ords[schritte]==NULL)
   {
    FatalMess("error in ORD_KOORD::GetAut\n");
    exit(0);
   } 
 #endif

 return(((ORDDNK*)ords[schritte])->GetOP_AUT());
}





char DNK_KOORD::GetErg(int i,int j)
{
 #ifdef DEBUG_TG
  if((i < 1)||(i > elem_schritte))
   {
    FatalMess("error 1 at DNK_KOORD::GetErg\n");
    exit(0);
   }

  if((j < 1)||(j > p_i[i]))
   {
    FatalMess("error 2 at DNK_KOORD::GetErg\n");
    exit(0);
   }
 #endif

 return(LOES[i][j]);
}





int DNK_KOORD::BerechneEingabeData(int idx)
{
 int i,j,k,_z,_s,m,n,l;

if(VERBOSE)
 {
  printf("DNK_KOORD::BerechneEingabe mit idx=%d ords_anz=%d\n",
        idx,ords_anz);
  fflush(stdout);
 }

 if(is_first[idx] == 1)
  {
   //evtl. realloc ords and initialize ords[idx]->z_p,
   //ords[idx]->s_p,ords[idx]->G,ords[idx]->AUT

   if(idx > ords_anz)
    {
     if(ords_anz == 0)
      {
       ords=(ORDTREU**)malloc(2*sizeof(ORDTREU*));
       #ifdef DEBUG_TG
        if(ords == NULL)
         {
          FatalMess("no memory in DNK_KOORD::BerechneEingabeDatA\n");
          exit(0);   
         }
       #endif
       ords[1]=NULL;
       ords_anz=1;
      }
     else
      {
       ords=(ORDTREU**)realloc(ords,
             (ords_anz+2)*sizeof(ORDTREU*));
       #ifdef DEBUG_TG
        if(ords == NULL)
         {
          FatalMess("no memory in DNK_KOORD::BerechneEingabeData\n");
          exit(0);   
         }
       #endif
       ords_anz++;
       ords[ords_anz]=NULL;
      }
    } 

   if(ords[idx] == NULL)
    {
     ords[idx]=new ORDDNK;
     #ifdef DEBUG_TG
      if(ords[idx] == NULL)
       {
        FatalMess("no memory in DNK_KOORD::BerechneEingabeData\n");
        exit(0);   
       }
     #endif
    }    

   ((ORDDNK*)ords[idx])->Zeilen()=0;
   for(i=1;i<=aufteilung[idx].Used();i++)
     ((ORDDNK*)ords[idx])->Zeilen()+=p_i[aufteilung[idx][i]];

   k=0;
   ((ORDDNK*)ords[idx])->Zei_Nr().ReAlloc(ords[idx]->Zeilen());
   for(i=1;i<=aufteilung[idx].Used();i++)
    {
     for(j=1;j<=p_i[aufteilung[idx][i]];j++)
      ((ORDDNK*)ords[idx])->Zei_Nr()[++k]=p_i_idx[aufteilung[idx][i]][j];  
    }

   k=0;
   for(i=1;i<=aufteilung[idx].Used();i++)
     k+=p_i_j[aufteilung[idx][i]].Used();
   ((ORDDNK*)ords[idx])->GetYoungPart().ReAlloc(k);
   ((ORDDNK*)ords[idx])->GetYoungPart().Used()=k;
   k=0;
   for(i=1;i<=aufteilung[idx].Used();i++)
    {
     for(j=1;j<=p_i_j[aufteilung[idx][i]].Used();j++)
      ((ORDDNK*)ords[idx])->GetYoungPart()[++k] =
                  p_i_j[aufteilung[idx][i]][j];
    }

   ords[idx]->GetIS_NULL_REP()=0;
   ((ORDDNK*)ords[idx])->GetOP_G_DIM()=Zei;
   ords[idx]->GetENABLE_AUT()=1;
   ords[idx]->GetPRINT_SOLUTIONS()=0;
   ords[idx]->GetPRINT_ANZ_CANDIDATES()=0;
   ords[idx]->GetPRINT_CANDIDATES()=0;
   ords[idx]->GetMAX_VAL()=1;
  }

 //now compute upper and lower bounds for the next step.
 //Initialize also ords[idx]->Anz() and ords[idx]->Gruppe().
 //Note: ords[idx]->Init() has to be called.


 if(idx == 1)
  {
   if(GROUP_IS_ID == 1)
    ords[idx]->GetGROUP_IS_ID()=1;
   else
    {
     if(is_first[idx] == 1)
      {
       ((ORDDNK*)ords[idx])->GetGROUP_IS_ID()=0;
       ((ORDDNK*)ords[idx])->GetIND_GROUP_IS_ID()=0;
       ((ORDDNK*)ords[idx])->GetOP_G().Init(G.Dim());
       ((ORDDNK*)ords[idx])->GetOP_G()=G;
      }       
    }
  }
 else
  {
   if(ords[idx-1]->GetAUT_IS_ID() == 1)
     ords[idx]->GetGROUP_IS_ID()=1;
   else
    {
     ((ORDDNK*)ords[idx])->GetGROUP_IS_ID()=0;
     ((ORDDNK*)ords[idx])->GetIND_GROUP_IS_ID()=0;
     ((ORDDNK*)ords[idx])->GetOP_G().Init(G.Dim());
     ((ORDDNK*)ords[idx])->GetOP_G() =
         ((ORDDNK*)ords[idx-1])->GetOP_AUT();
    }
  }


 is_first.Reset(idx);
 //ords[idx]->Gruppe() is initialized.

 ((ORDDNK*)ords[idx])->GetOP_G_DIM()=Zei;
 ((ORDDNK*)ords[idx])->Init(this);

 return(1);
}





void DNK_KOORD::Del(int _z,int _sp)
{ 
 for(int i=0;i<restr_func_anz;i++)
  (*RestrDel)(_z,_sp);
}



int DNK_KOORD::Set(int _z,int _sp,int wert)
{
 _sp-=Zei;

 if(!((s_von[_z] <= _sp)&&(_sp <= s_bis[_z])))
	 return(0);
		
 for(int i=0;i<restr_func_anz;i++)
  if( (*RestrSet)(_z,_sp,wert) == 0)
   return(0);

 return(1);
}



void DNK_KOORD::NotiereLoesung()
{
 int i,j,k,l,m;

 for(i=1;i<=schritte;i++)
  {
   m=k=0;
   for(j=1;j<=aufteilung[i].Used();j++)
    {
     for(l=1;l<=p_i[aufteilung[i][j]];l++)
       LOES[aufteilung[i][j]][l]=((ORDDNK*)ords[i])->GetErg(k+l)-m;    
     m+=p_i_j[aufteilung[i][j]].Used();
     k+=p_i[aufteilung[i][j]];
    }
  }

 AUT_IS_ID=((ORDDNK*)ords[schritte])->GetAUT_IS_ID();
}




void DNK_KOORD::PrintLoesung()
{
 int i,j;

 for(i=1;i<=elem_schritte;i++)
  {
   for(j=1;j<=p_i[i];j++)
    printf("%d ",LOES[i][j]);
   printf("\n");
  }
 printf("\n");
 fflush(stdout);

}





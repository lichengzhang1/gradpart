#include <string.h>
#include "ordtreu.h"
#include "koorbase.h"
#include <time.h>



ORDTREU::ORDTREU()
{
 MAX_VAL = 1;
 LOW_MEM = 0;
 R_D_f = NULL;
 R_S_f = NULL;
}


void ORDTREU::Init(int alone)
{
 int i,j,io,permdim;
 VEKTOR<short>  dims(s*z); 


 StandAlone = alone;
 IS_FIRST=1;
 if(anz==0)
   anz++;

 ANZ_CANDIDATES=0;
 last_max_ind=0;

 if( (GROUP_IS_ID==0)&&(INDUCED_GROUP_IS_ID==0)&&
    (ENABLE_ROWWISE_NUMBERING || ENABLE_PERMUT_NUMBERING || ENABLE_COLUMN_NUMBERING))
  {
   stabindex.ReAlloc(s*z+1);
   stabindex[1]=0;
   IsHit.ReAlloc(s*z);
   InvHit.ReAlloc(s*z);
   merke.ReAlloc(s*z);
   permdim=G.Dim();
   MinTestInd.ReAlloc(anz+1);
   nullbahn.REALLOC(anz,s*z);
   einsbahn.REALLOC(anz,s*z);
   dummy.ReAlloc(s*z);
   i=anz*(anz-1)/2;
   if(i==0)i=1;
   dims.ReAlloc(i);

   if(! LOW_MEM)
    {
     fus_el_tab.REALLOC(anz,s*z);
     for(j=1;j<=anz;j++)
      fus_el_tab[j].Clear();
    } 
   else
    {
     fus_el_tab.REALLOC(anz,6);
     for(j=1;j<=anz;j++)
      fus_el_tab[j].Used() = 0;
    }
    
   LERNVEK.ReAlloc(s*z);
   if(! LOW_MEM)
    {
     if(Lern_fusels.Dim()==0)
      Lern_fusels.REALLOC(s*z,permdim);
     else
      {
       if(permdim != Lern_fusels[1].Dim())
         Lern_fusels.FREE();
       Lern_fusels.REALLOC(s*z,permdim);
      }
    }
   else
    {
     Lern_fusels.REALLOC(5,permdim); 
     Lern_fusels.Used() = 0;
     Lern_fus_tab.ReAlloc(s*z);
     Lern_fus_tab.Clear();
    }         
   if(fus_els.Dim()==0)
    fus_els.REALLOC(1,permdim);
   else
    {
     if(permdim != fus_els[1].Dim())
      {
       fus_els.FREE();
       fus_els.REALLOC(1,permdim);
      }
    }
   fus_el_anz=0;
   if((transperm.Dim() > 0)&&(transperm.Dim() != permdim))
    transperm.FREE();
   transperm.ReAlloc(permdim);
   AutTransInd.ReAlloc(i);
   for(j=1;j<=i;j++)
    dims[j]=anz;

   einsindex.REALLOC(anz+2,anz);
   eins_werte.REALLOC(anz+2,anz);
  }

 z_p.ReAlloc(z);
 s_p.ReAlloc(s);
 K.REALLOC(z,s);
 for(i=1;i<=z;i++)
  K[i].Clear();
 eins_plaetze.ReAlloc(anz+1);
 platz_wert.ReAlloc(anz+1);
 sp_summe.ReAlloc(s);
 z_summe.ReAlloc(z);
 z_sp_to_nr.REALLOC(z,s);
 nr_to_z.ReAlloc(s*z);
 nr_to_sp.ReAlloc(s*z);

 LOESUNG_ANZ=0;
 eins_anz=0;
 for(j=1;j<=s;j++)
  sp_summe[j]=0;
 for(j=1;j<=z;j++)
  z_summe[j]=0;
 
 Berechne_Platzumrechnung();
 VATER=NULL;
	USED_BY_DNK = 0;
}



inline PERMUT<short>& ORDTREU::Lern_fus(int i)
{
 if(! LOW_MEM)
   return(Lern_fusels[i]);
 else 
  {
   if(Lern_fus_tab[i]==0)
    {
     Lern_fusels.REALLOC(Lern_fusels.Used()+1,s+z);
     Lern_fusels.Used()++;
     Lern_fus_tab[i] = Lern_fusels.Used();
    }
   return(Lern_fusels[Lern_fus_tab[i]]); 
  }
}



void ORDTREU::Init(KOORD_BASE* _VATER)
{
 Init(0);
 VATER=_VATER;
}



void ORDTREU::FREE()
{
 int io;

 stabindex.FREE();
 merke.FREE();
 inv_sz_p.FREE();
 MinTestInd.FREE();
 InvHit.FREE();
 IsHit.FREE();
 nullbahn.FREE();
 einsbahn.FREE();
 fus_els.FREE();
 Lern_fusels.FREE();
 LERNVEK.FREE();
 fus_el_tab.FREE();
 transperm.FREE();
 AutTransInd.FREE();
 AutErzInd.FREE();
 sp_summe.FREE();
 z_summe.FREE();
 K.FREE();
 dummy.FREE();
 einsindex.FREE();
 eins_werte.FREE();
 eins_plaetze.FREE();
 platz_wert.FREE();
 z_sp_to_nr.FREE();
 nr_to_z.FREE();
 nr_to_sp.FREE();
}




void ORDTREU::Berechne_Platzumrechnung()
{
 int i,j,k,l,m;

 if(ENABLE_ROWWISE_NUMBERING)
  {
   for(i=1;i<=z;i++)
    { 
     for(j=1;j<=s;j++)
       z_sp_to_nr[i][j]=(i-1)*s+j;
    }
   for(i=1;i<=z;i++)
    {
     for(j=1;j<=s;j++)
      nr_to_z[(i-1)*s+j]=i;
    }
   for(i=1;i<=s;i++)
    {
     for(j=1;j<=z;j++)
      nr_to_sp[(j-1)*s+i]=i;
    }
  }

 if(ENABLE_PERMUT_NUMBERING)
  {
   for(i=1;i<=z;i++)
    { 
     for(j=1;j<=s;j++)
      {
       z_sp_to_nr[permut_v[i]][j]=(i-1)*s+j;
       nr_to_z[(i-1)*s+j] = permut_v[i];
       nr_to_sp[(i-1)*s+j] = j;
      } 
    }
  }

 if(ENABLE_COLUMN_NUMBERING)
  {
   for(i=1;i<=s;i++)
    {
     for(j=1;j<=z;j++)
   	  {
       z_sp_to_nr[j][spaltenorder[i]] = (i-1)*z+j;
       nr_to_z[(i-1)*z+j] = j;
       nr_to_sp[(i-1)*z+j] = spaltenorder[i];
      }
   	}
  }

 if(ENABLE_GEO_NUMBERING)
  {
   int min=(z<s)?z:s;
   k=0;
   for(i=1;i<=min;i++)
    {
     for(j=i;j<=s;j++)
      {
       z_sp_to_nr[i][j]=++k;
       nr_to_z[k]=i;
       nr_to_sp[k]=j;
      }
     for(j=i+1;j<=z;j++)
      {
       z_sp_to_nr[j][i]=++k;
       nr_to_z[k]=j;
       nr_to_sp[k]=i;
      }
    }
  }
}


void ORDTREU::WechsleBasis()
{
 int i,j,k,l;

 for(i=last_max_ind+1;i<=eins_anz;i++)
  {
   k=z_p[nr_to_z[eins_plaetze[i]]];
   l=0;
   if(i > 1)
    {
     for(j=1;j<=stabindex[i-1];j++)
      if(G.pi(j) == k)
       l=1;
    }
    
   if(l == 0)
    {
     if(i > 1)
      stabindex[i]=stabindex[i-1]+1;
     else
      stabindex[i]=1;
     if(G.pi(stabindex[i]) != k)
      G.Cycle(stabindex[i],G.pi_i(k));
    }
   else
    stabindex[i]=stabindex[i-1];

   k=s_p[nr_to_sp[eins_plaetze[i]]];
   l=0;
   if(i > 1)
    {
     for(j=1;j<=stabindex[i];j++)
      if(G.pi(j) == k)
       l=1;
    }
    
   if(l == 0)
    {
     stabindex[i]++;
     if(G.pi(stabindex[i]) != k)
       G.Cycle(stabindex[i],G.pi_i(k));
    }
  }
}




void ORDTREU::Update_Nullbahn(int nr)
{
 int i,von,delta,anf,end,x;

 if(nr == 1)x=0;
 else x=stabindex[nr-1];

 nullbahn[nr].Clear();
 if(nr == 1)von=1;
 else von=eins_plaetze[nr-1]+1;
 for(i=von;i < eins_plaetze[nr];i++)
  {
   if(nullbahn[nr][i] == 0)
    {
     dummy.Clear();
     dummy.Set(i);
     merke[1]=i;
     anf=1;end=1;
     while(anf <= end)
      {
       G.StabErz_start(x);
       while(! G.IsLastStabErz())
        { 
         PERMUT<short>& perm=G.StabErz(x);
         delta=Anwende(perm,merke[anf]);
         if(dummy[delta] == 0)
          {
           dummy.Set(delta);
           merke[++end]=delta;
          }
        }
       anf++;
      }
     nullbahn[nr] |= dummy;
    }
  }
}


inline PERMUT < short >& ORDTREU::fus_el(int i,int j)
{
 if(USED_BY_DNK==0)
	 return(fus_el_alt(i,j));

	if(IS_FIRST)
	 return(fus_el_alt(i,j));

	return(fus_el_alt(i,DNK_FUS[i][nr_to_z[j]]));	
}



PERMUT < short >& ORDTREU::fus_el_alt(int i,int j)
{
 char fl = 1;

 if((! LOW_MEM)&&(fus_el_tab[i][j] != 0))  
  fl = 0;
 if(LOW_MEM)
  {
   int k = 1;
   while((k <= fus_el_tab[i].Used())&&(fus_el_tab[i][k] != j))  
    k += 2;
   if(k <= fus_el_tab[i].Used())
    fl = 0; 
  }  

 if(fl)
  {
   fus_el_anz++;
   if(fus_el_anz == fus_els.Dim())
    fus_els.REALLOC(fus_els.Dim()+10,G.Dim());
   fus_els[fus_el_anz].Id();
 
   if(! LOW_MEM)  
    fus_el_tab[i][j]=fus_el_anz;
   else
    {
     fus_el_tab[i].ReAlloc(fus_el_tab[i].Used()+2);  
     fus_el_tab[i][++fus_el_tab[i].Used()] = j;
     fus_el_tab[i][++fus_el_tab[i].Used()] = fus_el_anz;
    }  
  }


 if(! LOW_MEM)
  return(fus_els[fus_el_tab[i][j]]);
 else
  {
   int k = 1;
   while((k <= fus_el_tab[i].Used())&&(fus_el_tab[i][k] != j))  
    k += 2;

   return(fus_els[fus_el_tab[i][k+1]]);
  }   
}



void ORDTREU::Update_Einsbahn(int nr)
{
 int x,anf,end,delta;

 if(nr == 1)x=0;
 else x=stabindex[nr-1];
 DNK_FUS.REALLOC(z,z);   

 einsbahn[nr].Clear();
 einsbahn[nr].Set(eins_plaetze[nr]);
 merke[1]=eins_plaetze[nr];
 fus_el(nr,merke[1]).Id();
	if(USED_BY_DNK)
	 DNK_FUS[nr][nr_to_z[merke[1]]] = merke[1];
 anf=end=1;
 while(anf <= end)
  {
   G.StabErz_start(x);
   while(! G.IsLastStabErz())
    { 
     PERMUT<short>& perm=G.StabErz(x);
     delta=Anwende(perm,merke[anf]);
     if(einsbahn[nr][delta] == 0)
      {
       einsbahn[nr].Set(delta); 
       merke[++end]=delta;
       fus_el(nr,delta)=perm;
       fus_el(nr,delta).Inv();
       fus_el(nr,delta)*=fus_el(nr,merke[anf]); 
	      if(USED_BY_DNK)
	       DNK_FUS[nr][nr_to_z[delta]] = delta;
      }
    }  
   anf++;
  }
}



//Multiplies the appropriate fusels to get transperm
int ORDTREU::ComputeTransperm_1(int u)
{
 int i;

 if(minrek_tiefe == 1)
   transperm=fus_el(1,einsindex[1][MinTestInd[1]]);
 else
  { 
   transperm=fus_el(1,einsindex[1][MinTestInd[1]-1]);
   for(i=2;i<minrek_tiefe;i++)
    transperm*=fus_el(i,einsindex[i][MinTestInd[i]-1]);
  }

 if(minrek_tiefe == 1)
  {
   if(u < einsindex[1][1])
    return(u);
  }
 else
  {
   if((u < einsindex[1][minrek_tiefe])&&
      (u > einsindex[1][minrek_tiefe-1]))
    return(u);
  }

 int x,anf,end,delta;

 if(minrek_tiefe == 1)x=0;
 else x=stabindex[minrek_tiefe-1];

 LERNVEK.Clear();
 LERNVEK.Set(u);
 merke[1]=u;
 Lern_fus(u).Id();
 anf=end=1;
 while(anf <= end)
  {
   G.StabErz_start(x);
   while(! G.IsLastStabErz())
    {
     PERMUT<short>& perm=G.StabErz(x);
     delta=Anwende(perm,merke[anf]);
     if(LERNVEK[delta] == 0)
      {
       LERNVEK.Set(delta);
       merke[++end]=delta;
       Lern_fus(delta)=Lern_fus(merke[anf]);
       Lern_fus(delta)*=perm;
       if(minrek_tiefe == 1)
        {
         if(delta < einsindex[1][1])
          {
           transperm*=Lern_fus(delta);
           return(delta);
          }
        }
       else
        {
         if((delta < einsindex[1][minrek_tiefe])&&
            (delta > einsindex[1][minrek_tiefe-1]))
          {
           transperm*=Lern_fus(delta);
           return(delta);
          }
        }      
      }
    }
   anf++;
  }  
}



//Multiplies the appropriate fusels to get transperm
void ORDTREU::ComputeTransperm_2()
{
 int i;

 if(minrek_tiefe == 1)
  {
   transperm=fus_el(1,einsindex[1][MinTestInd[1]]);
   return;
  }
 transperm=fus_el(1,einsindex[1][MinTestInd[1]-1]);
 for(i=2;i<minrek_tiefe;i++)
  transperm*=fus_el(i,einsindex[i][MinTestInd[i]-1]);
 transperm*=fus_el(minrek_tiefe,einsindex[minrek_tiefe][MinTestInd[minrek_tiefe]]);
}


void ORDTREU::ComputeZURUECK_1(int i,int u)
{
 int k,l,delt;

 delt=ComputeTransperm_1(u);
 transperm.Inv();

 ZURUECK=0;
 for(l=1;l<=minrek_tiefe-1;l++)
  if((k=Anwende(transperm,einsindex[1][l])) > ZURUECK)
    ZURUECK=k;
 if((k=Anwende(transperm,delt)) > ZURUECK) 
   ZURUECK=k;
 if(einsindex[1][minrek_tiefe] > ZURUECK)
  ZURUECK=einsindex[1][minrek_tiefe];

 //the first ZURUECK places of the candidate cause the 
 //rejection of the candidate
}



void ORDTREU::ComputeZURUECK_2(int min_diff)
{
 int i,j,k;

 ComputeTransperm_2();
 transperm.Inv();
 i=1;
 ZURUECK=0;
 while((i <= eins_anz)&&(einsindex[1][i] < min_diff))
  {
   if((k=Anwende(transperm,einsindex[1][i])) > ZURUECK)
    ZURUECK=k;
   i++;
  }
 if((k=Anwende(transperm,min_diff)) > ZURUECK)
  ZURUECK=k;
 if(min_diff > ZURUECK)
  ZURUECK=min_diff;

 //the first ZURUECK places of the candidate cause the 
 //rejection of the candidate
}





void ORDTREU::InitMinTestData()
{
 int i,j,k;

 if(PRINT_ANZ_CANDIDATES)
  {
   char nachr[1000];
   sprintf(nachr,"\rRepAnz=%d CandAnz=%d",LOESUNG_ANZ,ANZ_CANDIDATES);
   FatalMess(nachr);
  }
 if(USED_BY_DNK==0)
	 {
   WechsleBasis();
   for(i=last_max_ind+1;i<=eins_anz;i++)
    Update_Nullbahn(i);
   for(i=last_max_ind+1;i<=eins_anz;i++)
    Update_Einsbahn(i);
  }
	else
	 {
   if(IS_FIRST)
			 {
     WechsleBasis();
     for(i=1;i<=eins_anz;i++)
      Update_Nullbahn(i);
     for(i=1;i<=eins_anz;i++)
      Update_Einsbahn(i);
     ZeilenBahnen.REALLOC(z,z);
					for(i=1;i<=z;i++)
					 ZeilenBahnen[i].Used()=0;
					for(i=1;i<=z;i++)
					 {
       for(j=1;j<=s*z;j++)
							 {
								 if(einsbahn[i][j])
									 ZeilenBahnen[i][++ZeilenBahnen[i].Used()]=nr_to_z[j];
						  }
						}
					if(0)
					 {
       printf("InitMintestData mit IS_FIRST==1\n");
							printf("einsbahnen =\n");
							for(i=1;i<=eins_anz;i++)
        {
								 printf("%d: ",i);
									einsbahn[i].Print(0);
									for(j=1;j<=s*z;j++)
									 if(einsbahn[i][j]==1)
										 {
            printf("fusel(%d,%d) = ",i,j);
            fus_el(i,j).Print(0); 
											}
        }
							printf("nullbahnen =\n");
							for(i=1;i<=eins_anz;i++)
        {
								 printf("%d: ",i);
									nullbahn[i].Print(0);
        }
       printf("ZeilenBahnen = \n");
							for(i=1;i<=z;i++)
							 {
         printf("%d: ",i);
									ZeilenBahnen[i].PrintUsed(0);
        }
						}
				}
			else
			 {
				 int i1,i2,i3;
     for(i=last_max_ind+1;i<=eins_anz;i++)
      {
       einsbahn[i].Clear();
       einsbahn[i].Set(eins_plaetze[i]);
							i1 = nr_to_sp[eins_plaetze[i]];
       for(j=2;j<=ZeilenBahnen[i].Used();j++)
							 {
					    i2 = z_sp_to_nr[ZeilenBahnen[i][j]][i1];
									einsbahn[i].Set(i2);
        }
						}
					int von;	
     for(i=last_max_ind+1;i<=eins_anz;i++)
      {
						 nullbahn[i].Clear();
       if(i == 1)von=1;
       else von=eins_plaetze[i-1]+1;
       for(j=von;j < eins_plaetze[i];j++)
        {  
							  if(nullbahn[i][j]==0)
									 {
										 nullbahn[i].Set(j);
           i1 = nr_to_sp[j];
											i3 = nr_to_z[j];
											if(i3 != i-1)
											 {
						  				 for(k=2;k<=ZeilenBahnen[i3].Used();k++)
								  			 {
               i2 = z_sp_to_nr[ZeilenBahnen[i3][k]][i1];
												   nullbahn[i].Set(i2);
														}	
										  }
							   }
        }
      }

					if(0)
					 {
							int j1,j2;
       printf("InitMintestData mit IS_FIRST==0, last_max_ind=%d\n",last_max_ind);
							printf("einsbahnen =\n");
							for(i=1;i<=eins_anz;i++)
        {
								 printf("%d:\n",i);
									for(j1=1;j1<=z;j1++)
									 {
										 for(j2=1;j2<=s;j2++)
											 {
             if(einsbahn[i][(j1-1)*s+j2]==1)
													 printf("1 ");
													else
													 printf("0 ");
												}
											printf("\n");	
										}		
									printf("\n");	
									//einsbahn[i].Print(0);
									for(j=1;j<=s*z;j++)
									 if(einsbahn[i][j]==1)
										 {
            printf("fusel(%d,%d) = ",i,j);
            fus_el(i,j).Print(0); 
											}
        }
							printf("nullbahnen =\n");
							for(i=1;i<=eins_anz;i++)
        {
								 printf("%d:\n",i);
									for(j1=1;j1<=z;j1++)
									 {
										 for(j2=1;j2<=s;j2++)
											 {
             if(nullbahn[i][(j1-1)*s+j2]==1)
													 printf("1 ");
													else
													 printf("0 ");
												}
											printf("\n");	
										}		
									printf("\n");	
									//nullbahn[i].Print(0);
        }
      }
    }
		}
 NotiereLoesung();
 for(i=1;i<=eins_anz;i++)
  {
   einsindex[1][i] = eins_plaetze[i];
   eins_werte[1][i] = platz_wert[i];
  }
 minrek_tiefe=1;
 //there are (minrek_tiefe-1) 1's stabilized.

 MinTestInd[1]=1;

 for(i=1;i<=eins_anz;i++)
  InvHit[einsindex[1][i]]=i;

 PERMFLAG=0;
 if(ENABLE_AUT)
  {
   STUFE=s*z+1;
   AutErzAnz=0;
  }
}





void ORDTREU::ComputeNext_einsindex()
{
 int i,j,k;
 min_gr_pos = 1000000;
 VEKTOR < short >& E1 = einsindex[minrek_tiefe];
 VEKTOR < short >& E2 = einsindex[minrek_tiefe + 1];
 VEKTOR < short >& W1 = eins_werte[minrek_tiefe];
 VEKTOR < short >& W2 = eins_werte[minrek_tiefe + 1];

 IsHit.Clear();
 j=minrek_tiefe;
 for(i=minrek_tiefe;i<=eins_anz;i++)
 {
  if( i != MinTestInd[minrek_tiefe] )
   {
    j++;
    E2[j] =
     Anwende(fus_el(minrek_tiefe,E1[MinTestInd[minrek_tiefe]]),E1[i]);
    W2[j] = W1[i];

    k = K[nr_to_z[E2[j]]][nr_to_sp[E2[j]]];
    if( k == W2[j] )
      IsHit.Set(InvHit[E2[j]]);
    else
     {
      if(( k < W2[j] )&&( E2[j] < min_gr_pos))
       min_gr_pos = E2[j]; 
     }        
   } 
 }
}


//return value =
// - 0, if the candidate can be rejected
// - 1, if an automorphism is found
// - 2, otherwise
inline int ORDTREU::CompareNext_einsindex()
{
 int i,j,k;

 for(i=minrek_tiefe+1;(i<=eins_anz)&&(einsindex[1][i] < min_gr_pos);i++)
  {
   if(IsHit[i] == 0)
    return(2);
  }
 if(min_gr_pos < 1000000)
  {
   last_max_ind = eins_anz;
   ComputeZURUECK_2(min_gr_pos);
   return(0);
  }
 return(1);
}


int ORDTREU::MinTest()
{
 int i,j,ret,is_linker_ast=1;
 int ZURUECK_MIN=1000000,RET=1;


 if(PRINT_CANDIDATES == 1)
  {
   printf("Next Candidate:\n");
   PrintLoesung();
   printf("GRUPPE=\n");
   G.Print();
  }
		
 InitMinTestData();
	
 MAXREK=0;
 while(minrek_tiefe > 0)
  {
   UP:
   MAXREK++;
   for(i=minrek_tiefe;i<=eins_anz;i++)
    {
     if(nullbahn[minrek_tiefe][einsindex[minrek_tiefe][i]] == 1)
      {
       last_max_ind=eins_anz;
       ComputeZURUECK_1(i,einsindex[minrek_tiefe][i]);
       return(0);
      }
    }
   while(MinTestInd[minrek_tiefe] <= eins_anz)
    {
     if((einsbahn[minrek_tiefe]
                [einsindex[minrek_tiefe][MinTestInd[minrek_tiefe]]] == 1)&&
        (eins_werte[1][minrek_tiefe] <= eins_werte[minrek_tiefe]
                                                  [MinTestInd[minrek_tiefe]]))        
      {
       if(ENABLE_AUT == 1)
        {
         //einsindex[minrek_tiefe][MinTestInd[minrek_tiefe]] kann nach
         //einsindex[1][minrek_tiefe] gebracht werden.
         if(eins_werte[1][minrek_tiefe] < 
              eins_werte[minrek_tiefe][MinTestInd[minrek_tiefe]])       
          {         
           last_max_ind = eins_anz;
           ComputeZURUECK_2(einsindex[1][minrek_tiefe]);
           return(0);
          }

         if(einsindex[minrek_tiefe][MinTestInd[minrek_tiefe]] !=
            einsindex[1][minrek_tiefe])
          {
           if(minrek_tiefe <= STUFE)
            {
             STUFE=minrek_tiefe;
             PERMFLAG=1;
            }
          } 
        }
       ComputeNext_einsindex();
       ret=CompareNext_einsindex();
       if(ret == 0)
	{
         return(0);
	}	
       if(ret == 1)
        {
         if(ENABLE_AUT && PERMFLAG)
          {
           PERMFLAG=0; 
           NotiereAutomorphismus();
          } 
         //an automorphism is found
         if(is_linker_ast == 0)   //identischer Teilbaum gefunden
          {
           MinTestInd[minrek_tiefe]++;
           goto UP;
          }
        }
       MinTestInd[minrek_tiefe]++;
       minrek_tiefe++;
       MinTestInd[minrek_tiefe]=minrek_tiefe;
       goto UP;
      }
     else
      MinTestInd[minrek_tiefe]++;
    } //Ende von while
   minrek_tiefe--;
   is_linker_ast=0;
  }
 last_max_ind=eins_anz;
 return(1);
}



void ORDTREU::NotiereAutomorphismus()
{
 int i;

 AutErzAnz++;

 AutErzInd.ReAlloc(AutErzAnz);
 if(! AutErzInd.IsAlloc(AutErzAnz))
  AutErzInd.Add(AutErzAnz,0);
 AutErzInd[AutErzAnz].REALLOC(minrek_tiefe,2);

 if(minrek_tiefe == 1)
  {
   AutErzInd[AutErzAnz].Used()=1;
   AutErzInd[AutErzAnz][1][1]=1; 
   AutErzInd[AutErzAnz][1][2]=einsindex[1][MinTestInd[1]]; 
   AutTransInd[AutErzAnz]=STUFE;
   return;
  }

 AutTransInd[AutErzAnz]=STUFE;
 AutErzInd[AutErzAnz].Used()=1;
 AutErzInd[AutErzAnz][1][1]=1; 
 AutErzInd[AutErzAnz][1][2]=einsindex[1][MinTestInd[1]-1]; 
 
 for(i=2;i<minrek_tiefe;i++)
  {
   AutErzInd[AutErzAnz].Used()++;
   AutErzInd[AutErzAnz][AutErzInd[AutErzAnz].Used()][1]=i; 
   AutErzInd[AutErzAnz][AutErzInd[AutErzAnz].Used()][2]=
    einsindex[i][MinTestInd[i]-1];
  }

 AutErzInd[AutErzAnz].Used()++;
 AutErzInd[AutErzAnz][AutErzInd[AutErzAnz].Used()][1]=minrek_tiefe; 
 AutErzInd[AutErzAnz][AutErzInd[AutErzAnz].Used()][2]=
  einsindex[minrek_tiefe][MinTestInd[minrek_tiefe]];
}



void ORDTREU::NotiereLoesung()
{
 int i,j;

 for(i=1;i<=z;i++)
  K[i].Clear();
 for(i=1;i<=eins_anz;i++)
   K[nr_to_z[eins_plaetze[i]]][nr_to_sp[eins_plaetze[i]]] =
    platz_wert[i];
}


void ORDTREU::PrintLoesung()
{
 int i,j;

 NotiereLoesung();

 for(i=1;i<=z;i++)
  {
   for(j=1;j<=s;j++)
    printf("%d ",K[i][j]);
   printf("\n");
  }
 printf("\n");
 fflush(stdout);
}




void ORDTREU::BerechneAut()
{
 int i,j,k,l,m,n;

	i = stabindex[eins_anz];
 AUT.CopyStab(G,i);
 i=1;
 while(i <= AutErzAnz)
  {   
   k=z_p[nr_to_z[eins_plaetze[AutTransInd[i]]]];
   m=s_p[nr_to_sp[eins_plaetze[AutTransInd[i]]]];
   j=i;
   while((j <= AutErzAnz)&&(AutTransInd[j] == AutTransInd[i]))
    {
     transperm=fus_el(AutErzInd[j][1][1],AutErzInd[j][1][2]);
     for(l=2;l<=AutErzInd[j].Used();l++)
      transperm*=fus_el(AutErzInd[j][l][1],AutErzInd[j][l][2]);
     transperm.Inv();
     n=AUT.pi_i(transperm[m]);
     if((k == transperm[k])&&(AUT.HV(n) == n ))   
      {
       AUT.HV(n)=AUT.pi_i(m);
       AUT.KM(transperm[m])=transperm;  
      }
     j++;
    }
   j=i;

   while((j <= AutErzAnz)&&(AutTransInd[j] == AutTransInd[i]))
    {
     transperm=fus_el(AutErzInd[j][1][1],AutErzInd[j][1][2]);
     
     for(l=2;l<=AutErzInd[j].Used();l++)
      transperm*=fus_el(AutErzInd[j][l][1],AutErzInd[j][l][2]);

     transperm.Inv();
     n=AUT.pi_i(transperm[k]);  
     if((k != transperm[k])&&(AUT.HV(n) == n ))   
      {
       AUT.HV(n)=AUT.pi_i(k);
       AUT.KM(transperm[k])=transperm;  
      }
     j++;
    }
   while((i < AutErzAnz) && (AutTransInd[i+1] == AutTransInd[i]))
    i++;
   i++;
  }
 AUT.update_eckenmarken();
 AUT_IS_ID=1;
 for(i=1;i<=G.Dim();i++)
  if(AUT.HV(i) != i)
   AUT_IS_ID=0;
}




int ORDTREU::NextRepID()
{
 int ret,i,j,k,l,bis=s*z;

 if(GROUP_IS_ID == 0)
  AUT_IS_ID=0;
 else
  AUT_IS_ID=1;

 if(IS_FIRST && IS_NULL_REP)
  {
   NotiereLoesung();
   IS_FIRST=0;
   return(1);
  }
 do
  {
   VOR_ID:
   //Durchlaufe die moeglichen Plaetze fuer die naechste 1
   l=eins_anz+1;
   if(eins_anz == 0)
    eins_plaetze[l]=0;
   else
    eins_plaetze[l]=eins_plaetze[eins_anz];

   while(eins_plaetze[l] < bis)
    {
     eins_plaetze[l]++;
     platz_wert[l] = MAX_VAL + 1;
     NEXT_ID:
     l=eins_anz+1;
     while(platz_wert[l] > 1)
      { 
       platz_wert[l]--;

       ret=IsErlaubt(eins_plaetze[l],platz_wert[l]);
       if(ret == -1)
        goto AFTER_WHILE_ID;
       if(ret != 0)
        {
         if((VATER != NULL)&&
            (! VATER->Set(z_p[nr_to_z[eins_plaetze[l]]],
                        s_p[nr_to_sp[eins_plaetze[l]]],
                        platz_wert[l])))
           ret=0;
         if((R_S_f != NULL)&&
            (! (*R_S_f)(z_p[nr_to_z[eins_plaetze[l]]],
                        s_p[nr_to_sp[eins_plaetze[l]]],
                        platz_wert[l])))
           ret = 0;
	      	 if(ret==0)  
          DelFunc(nr_to_z[eins_plaetze[l]],
	              nr_to_sp[eins_plaetze[l]]);  
        }

       if(ret != 0)
        {
         //naechste Moeglichkeit gefunden
         sp_summe[nr_to_sp[eins_plaetze[l]]] +=platz_wert[l] ;
         z_summe[nr_to_z[eins_plaetze[l]]] +=platz_wert[l];
         eins_anz++;
         if(ret == 2)
          {
           LOESUNG_ANZ++;
           NotiereLoesung();         
           if(PRINT_SOLUTIONS)
            {
             printf("Solution Nr.%d\n",LOESUNG_ANZ);
             PrintLoesung(); 
            } 
           IS_FIRST=0; 
           return(1);
          }
         goto VOR_ID;
        }
      }
    } 
  AFTER_WHILE_ID:
   if(eins_anz ==  0)
     return(0);
   sp_summe[nr_to_sp[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
   z_summe[nr_to_z[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
   DelFunc(nr_to_z[eins_plaetze[eins_anz]],
           nr_to_sp[eins_plaetze[eins_anz]]);  
   if(VATER != NULL)
    VATER->Del(z_p[nr_to_z[eins_plaetze[eins_anz]]],
               s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
   if(R_D_f != NULL)
    (*R_D_f)(z_p[nr_to_z[eins_plaetze[eins_anz]]],
             s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
   eins_anz--;
   if(last_max_ind > 0)
    last_max_ind--;
   goto NEXT_ID;
  }
 while(1);
}




int ORDTREU::NextRep()
{
 int ret,i,j,k,l,bis=s*z;


 if((GROUP_IS_ID == 1)||(INDUCED_GROUP_IS_ID == 1))
  return(NextRepID());

 if(IS_FIRST && IS_NULL_REP)
  {
   NotiereLoesung();
   AUT=G;
   AUT_IS_ID=0;
   IS_FIRST=0;
   return(1);
  }

 do
  {
   VOR:
   //Durchlaufe die moeglichen Plaetze fuer die naechste 1
   l=eins_anz+1;
   if(eins_anz == 0)
    eins_plaetze[l]=0;
   else
    eins_plaetze[l]=eins_plaetze[eins_anz];
   while(eins_plaetze[l] < bis)
    {
     eins_plaetze[l]++;
     platz_wert[l] = MAX_VAL + 1;
     NEXT:
     l=eins_anz+1;
     while(platz_wert[l] > 1)
      { 
       platz_wert[l]--;

       ret=IsErlaubt(eins_plaetze[l],platz_wert[l]);
       if(ret == -1)
        goto AFTER_WHILE;
       if(ret != 0)
        {
         if((VATER != NULL)&&
            (! VATER->Set(z_p[nr_to_z[eins_plaetze[l]]],
                        s_p[nr_to_sp[eins_plaetze[l]]],
                        platz_wert[l])))
           ret=0;
         if((R_S_f != NULL)&&
            (! (*R_S_f)(z_p[nr_to_z[eins_plaetze[l]]],
                        s_p[nr_to_sp[eins_plaetze[l]]],
                        platz_wert[l])))
           ret = 0;
         if(ret==0)  
          DelFunc(nr_to_z[eins_plaetze[l]],
	              nr_to_sp[eins_plaetze[l]]);  
        }

       if(ret != 0)
        {
         //naechste Moeglichkeit gefunden
         sp_summe[nr_to_sp[eins_plaetze[l]]] += platz_wert[l];
         z_summe[nr_to_z[eins_plaetze[l]]] += platz_wert[l];
         eins_anz++;
        }  
       if(ret==1)
        goto VOR;
       if(ret==2) 
        {
         ENABLE_AUT=1;
         ANZ_CANDIDATES++;
         if(MinTest())
          { 
           LOESUNG_ANZ++;
           BerechneAut(); 
           NotiereLoesung();         
           IS_FIRST=0; 
           return(1);
          }
         else  //nicht bestanden
          {
           if(eins_plaetze[eins_anz]  == ZURUECK)
            {
             sp_summe[nr_to_sp[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
             z_summe[nr_to_z[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
             DelFunc(nr_to_z[eins_plaetze[eins_anz]],
	                 nr_to_sp[eins_plaetze[eins_anz]]);  
             if(VATER != NULL)
               VATER->Del(z_p[nr_to_z[eins_plaetze[eins_anz]]],
	                      s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
             if(R_D_f != NULL)
               (*R_D_f)(z_p[nr_to_z[eins_plaetze[eins_anz]]],
                        s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
             eins_anz--;
             if(last_max_ind > 0)
               last_max_ind--;
            }
           else
            {
             //some steps back are possible
             while((eins_anz > 0)&&(eins_plaetze[eins_anz] >= ZURUECK))
              {
               sp_summe[nr_to_sp[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
               z_summe[nr_to_z[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
               DelFunc(nr_to_z[eins_plaetze[eins_anz]],
	                   nr_to_sp[eins_plaetze[eins_anz]]);  
               if(VATER != NULL)
                 VATER->Del(z_p[nr_to_z[eins_plaetze[eins_anz]]],
                            s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
               if(R_D_f != NULL)
                 (*R_D_f)(z_p[nr_to_z[eins_plaetze[eins_anz]]],
                          s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
               eins_anz--;
               if(last_max_ind > 0)
                 last_max_ind--;
              }
             goto NEXT;
            }
          }
        } //Ende von if(ret == 2)
      }
    } //Ende der while-Schleife
  AFTER_WHILE:
   if(eins_anz ==  0)return(0);
   sp_summe[nr_to_sp[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
   z_summe[nr_to_z[eins_plaetze[eins_anz]]] -= platz_wert[eins_anz]; 
   DelFunc(nr_to_z[eins_plaetze[eins_anz]],
           nr_to_sp[eins_plaetze[eins_anz]]);  
   if(VATER != NULL)
    VATER->Del(z_p[nr_to_z[eins_plaetze[eins_anz]]],
               s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
   if(R_D_f != NULL)
    (*R_D_f)(z_p[nr_to_z[eins_plaetze[eins_anz]]],
             s_p[nr_to_sp[eins_plaetze[eins_anz]]]);  
   eins_anz--;
   if(last_max_ind > 0)
    last_max_ind--;
   goto NEXT;
  }
 while(1);
}




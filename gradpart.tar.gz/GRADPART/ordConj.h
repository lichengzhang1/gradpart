
#ifndef ORDTREU_CONJ_CLASSES_H

#include "ordtreu.h"
#include "sims.h"


class ORDTREU_CONJ_CLASSES : public ORDTREU
{
 private:

  SIMS                         Kette;
  ARRAY<BITVEK>                NextPosition; 
  ARRAY < VEKTOR < short > >   InvPos; 
  int                     IsErlaubt(int platz,int wert);
  PERMUT<short>                permut_v_inv;

 public:
                    ORDTREU_CONJ_CLASSES();
                    ~ORDTREU_CONJ_CLASSES();

  void              FREE();
 
  void              Init(int alone);                    

  //Da Kette nicht identisch mit der operierenden Gruppe ist,
  //muss Kette von aussen initialisiert werden.

  SIMS&             GetKette(); 
};




#define ORDTREU_CONJ_CLASSES_H
#endif



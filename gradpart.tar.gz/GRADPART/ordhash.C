#include "ordhash.h"


//vecl has the same value as eins_anz in ordtreu
void ORDHASH::Init(int vecl,VEKTOR<short>& einsen)
{
 int i;

 inf_length=vecl;
 einsindex=einsen;
 inf_anz=0;
 inf_max=HASH_LENGTH / (inf_length+2);

 collision_table.ReAlloc(inf_max);
 v.ReAlloc((int)(HASH_LENGTH));

 for(i=1;i<=inf_max;i++)
  {
   IsUsed(i)=0;
   Next(i)=0;
  }
}




void ORDHASH::FuegeEin(int minrek_tiefe,VEKTOR<short>& Ind,
                   VEKTOR<short>& places,int i)
{ 
 int j;

 IsUsed(i)=1;
 HoleTiefe(i)=minrek_tiefe;
 for(j=1;j<=minrek_tiefe;j++)
  HoleMinInd(i,j)=Ind[j];
 for(j=minrek_tiefe+1;j<=inf_length;j++)
  HoleEinsInd(i,j)=places[j];

 inf_anz++;
}





int ORDHASH::IsGleich(int minrek_tiefe,VEKTOR<short>& Ind,
                   VEKTOR<short>& places,int i)
{
 int j,k;
 
 if(minrek_tiefe < HoleTiefe(i))
  return(0);

 for(j=HoleTiefe(i)+1;j<=minrek_tiefe;j++)
  if(HoleEinsInd(i,j) != einsindex[j])
   return(0);

 for(j=minrek_tiefe+1;j<=inf_length;j++)
  if(HoleEinsInd(i,j) != places[j])
   return(0);

 //now it is verified that the 1's are at the same positions

 k=0;
 for(j=1;j<=HoleTiefe(i);j++)
  {
   if(Ind[j] != HoleMinInd(i,j))
    {
     k=1;
     break;
    }
  }  

 if(k==0)
  return(0);
 else
  return(1);

}





int ORDHASH::Insert(int minrek_tiefe,VEKTOR<short>& Ind,
                   VEKTOR<short>& places)
{
 int i,j,last;

 i=0;
 for(j=1;j<=minrek_tiefe;j++)
  i+=j*einsindex[j];
 for(j=minrek_tiefe+1;j<=inf_length;j++)
  i+=j*places[j];
 if(i < 0)i=-i; 
 i=(i % inf_max);
 //0 <= i <= inf_max-1
 i-=(i % 5);
 if(i < 5) i=5;
 //i is in { 5,10,15,20,25,....}

 do
  {
   if(IsUsed(i) == 0)
    {
     FuegeEin(minrek_tiefe,Ind,places,i);
     return(0);
    }
   if(IsGleich(minrek_tiefe,Ind,places,i))
    return(1);
   last=i;
   i=Next(i);
  }
 while(i);


 if(inf_anz >= (0.8 * inf_max))
  return(0);

 if(last == inf_max)i=1;
 else i=last+1;
 while((IsUsed(i) == 1) || (i % 5 == 0))
  {
   if(i < inf_max) i++;
   else i=1;
  }

 FuegeEin(minrek_tiefe,Ind,places,i);
 Next(last)=i;
 return(0);

}









#ifndef ORDDNK_H

#include <stdio.h>
#include "ordSpZ.h"
#include "langzahl.h"
#include "koorbase.h"



//this is a class to compute the double-cosets
//Y \ S(z) / G' , where Y is a Young-subgroup of S(z)
//and G' is the induced group of G.
 
class ORDDNK : public ORDTREU_SP_Z_SUMS 
{
 protected:

  VEKTOR < short >         young_part;
  //has to be allocated from the outside and contains
  //the partition of Y

  LANGZAHL                 ZIEL,L1,L2;

  LABRA_TG                 OP_G;
  LABRA_TG                 OP_AUT;

  int                      OP_G_DIM;
  //needed, if OP_G == id

 public:
                           ORDDNK();
                           ~ORDDNK(); 

  void                     Init(int alone);
  void                     Init(KOORD_BASE *_VATER);
  int                      NextRep();
  void                     BerechneAut();

  VEKTOR < short >&        GetYoungPart()
                            { return(young_part); }
  short                    GetErg(int i);
  LABRA_TG&                GetOP_G() { return(OP_G); }
  int&                     GetOP_G_DIM() { return(OP_G_DIM); }
  LABRA_TG&                GetOP_AUT() { return(OP_AUT); }
};




#define ORDDNK_H
#endif




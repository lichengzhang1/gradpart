#include "langzahl.h"



//Initialisiere mit 0

LANGZAHL::LANGZAHL()
{
 koeff.Init(1);
 temp1.Init(1);
 koeff.SetAb0();
 temp1.SetAb0();
 koeff.Used()=-1;
 //d.h. (*this) == 0
}


LANGZAHL::LANGZAHL(int l)
{
 koeff.Init(1);
 temp1.Init(1);
 koeff.SetAb0();
 temp1.SetAb0();
 (*this)=l;
}



//Be careful with this function !!
//there is no check for int-overflow
int LANGZAHL::lang_to_int()
{
 int ret=0;
 int i,j;

 j=1;
 for(i=0;i<=koeff.Used();i++)
  {
   ret+=koeff[i]*j;
   j*=10;
  }
 return(ret);
}


void LANGZAHL::operator+=(LANGZAHL& l)
{
 int i,j;

 if(koeff.Dim() < l.Koeff().Used()+1)
  {
   koeff.ReAlloc(l.Koeff().Used()+1);
   temp1.ReAlloc(l.Koeff().Used()+1);
  }

 for(i=koeff.Used()+1;i<=koeff.Dim();i++)
  koeff[i]=0;
 for(i=l.Koeff().Used()+1;i<=l.Koeff().Dim();i++)
  l.Koeff()[i]=0;

 for(i=0;i<=l.Koeff().Used();i++)
  koeff[i]+=l.Koeff()[i];
 for(i=0;i < koeff.Dim();i++)
  {
   koeff[i+1]+=koeff[i]/10;
   koeff[i]=koeff[i]%10;
  }
 while(koeff[koeff.Dim()] > 9)
  {
   i=koeff.Dim()+1;
   koeff.ReAlloc(i);
   temp1.ReAlloc(i);
   koeff[koeff.Dim()]=koeff[koeff.Dim()-1]/10;
   koeff[koeff.Dim()-1]=koeff[koeff.Dim()-1] % 10;
  }
 koeff.Used()=koeff.Dim();
 while((koeff.Used() >= 0)&&(koeff[koeff.Used()] == 0))
  koeff.Used()--;
}


void LANGZAHL::operator-=(LANGZAHL& l)
{
 minus(l,0);
}



void LANGZAHL::operator*=(LANGZAHL& l)
{
 int i,j,max;

 if(koeff.Dim() < (i=koeff.Used()+l.Koeff().Used()))
  {
   koeff.ReAlloc(i);
   temp1.ReAlloc(i);
  }
 temp1.Clear();
 for(i=0;i<=koeff.Used();i++)
  for(j=0;j<=l.Koeff().Used();j++)
    temp1[i+j]+=koeff[i]*l.Koeff()[j];

 koeff.Swap(temp1);
 for(i=0;i < koeff.Dim();i++)
  {
   koeff[i+1]+=koeff[i]/10;
   koeff[i]=koeff[i]%10;
  }
 while(koeff[koeff.Dim()] > 9)
  {
   i=koeff.Dim()+1;
   koeff.ReAlloc(i);
   temp1.ReAlloc(i);
   koeff[koeff.Dim()]=koeff[koeff.Dim()-1]/10;
   koeff[koeff.Dim()-1]=koeff[koeff.Dim()-1] % 10;
  }

 koeff.Used()=koeff.Dim();
 while((koeff.Used() >= 0)&&(koeff[koeff.Used()] == 0))
  koeff.Used()--;
}



void LANGZAHL::operator/=(LANGZAHL& l)
{
 int i,j;

 if(l == 1)
  return;
 temp1.Clear();
 j=koeff.Used()-l.Koeff().Used();
 for(i=j;i>=0;i--)
   while(GrEq(l,i))
    {
     minus(l,i);
     temp1[i]++;
    } 

 #ifdef DEBUG_TG
  if(koeff.Used() != -1)
   {
    FatalMess("Division geht nicht auf bei LANGZAHL\n");
    exit(0);
   }
 #endif

 koeff.Swap(temp1);
 koeff.Used()=koeff.Dim();
 while((koeff.Used() >= 0)&&(koeff[koeff.Used()] == 0))
  koeff.Used()--;
}




void LANGZAHL::minus(int ziffer,int hoch_i)
{
 int i,j;

/*
 #ifdef DEBUG_TG
  if(koeff.Used() < hoch_i)
   {
    FatalMess("Fehler1 bei LANGZAHL::minus mit ziffer=%d hoch_i=%d\n",
        ziffer,hoch_i);
    exit(0);
   }
  if((koeff.Used() == hoch_i)&&(koeff[koeff.Used()] < ziffer))
   {
    FatalMess("Fehler2 bei LANGZAHL::minus mit ziffer=%d hoch_i=%d\n",
                    ziffer,hoch_i);
    exit(0);
   }
 #endif 
*/
 
 if(koeff[hoch_i] >= ziffer)
  {
   koeff[hoch_i]-=ziffer;
   while((koeff.Used() >= 0)&&(koeff[koeff.Used()] == 0))
    koeff.Used()--;
   return;
  }

 koeff[hoch_i]+=10;
 koeff[hoch_i]-=ziffer;
 koeff[hoch_i+1]-=1;
 i=hoch_i+1;
 while((i <= koeff.Used())&&(koeff[i] < 0))
  {
   koeff[i]+=10;
   koeff[i+1]--;
   i++;
  }

 koeff.Used()=koeff.Dim();
 while((koeff.Used() >= 0)&&(koeff[koeff.Used()] == 0))
  koeff.Used()--;
}



void LANGZAHL::minus(LANGZAHL& l,int hoch_i)
{
 for(int i=0;i<=l.Koeff().Used();i++)
  minus(l.Koeff()[i],i+hoch_i);
}



int LANGZAHL::GrEq(LANGZAHL& l,int hoch_i)
{
 int i,j;

 if(koeff.Used() > l.Koeff().Used()+hoch_i)
  return(1);
 if(koeff.Used() < l.Koeff().Used()+hoch_i)
  return(0);
 for(i=koeff.Used();i>=0;i--)
  {
   if(i >= hoch_i)
    { 
     if(koeff[i] > l.Koeff()[i-hoch_i])
      return(1); 
     if(koeff[i] < l.Koeff()[i-hoch_i])
      return(0); 
    }
  }
 return(1);
}



int LANGZAHL::operator==(LANGZAHL& l)
{
 if(koeff.Used() != l.Koeff().Used())
  return(0);
 for(int i=0;i<=koeff.Used();i++)
  if(koeff[i] != l.Koeff()[i])
    return(0);
 return(1);
}


 
int LANGZAHL::operator>(LANGZAHL& l)
{
 if(koeff.Used() > l.Koeff().Used())
  return(1);
 if(koeff.Used() < l.Koeff().Used())
  return(0);
 for(int i=koeff.Used();i>=0;i--)
  {
   if(koeff[i] < l.Koeff()[i])
    return(0);
   if(koeff[i] > l.Koeff()[i])
    return(1);
  }  
 return(0);
}



int LANGZAHL::operator>=(LANGZAHL& l)
{
 if(koeff.Used() > l.Koeff().Used())
  return(1);
 if(koeff.Used() < l.Koeff().Used())
  return(0);
 for(int i=koeff.Used();i>=0;i--)
  {
   if(koeff[i] < l.Koeff()[i])
    return(0);
   if(koeff[i] > l.Koeff()[i])
    return(1);
  }  
 return(1);
}


int LANGZAHL::operator<(LANGZAHL& l)
{
 if(koeff.Used() > l.Koeff().Used())
  return(0);
 if(koeff.Used() < l.Koeff().Used())
  return(1);
 for(int i=koeff.Used();i>=0;i--)
  {
   if(koeff[i] < l.Koeff()[i])
    return(1);
   if(koeff[i] > l.Koeff()[i])
    return(0);
  }  
 return(0);
}



int LANGZAHL::operator<=(LANGZAHL& l)
{
 if(koeff.Used() > l.Koeff().Used())
  return(0);
 if(koeff.Used() < l.Koeff().Used())
  return(1);
 for(int i=koeff.Used();i>=0;i--)
  {
   if(koeff[i] < l.Koeff()[i])
    return(1);
   if(koeff[i] > l.Koeff()[i])
    return(0);
  }  
 return(1);
}


void LANGZAHL::operator=(LANGZAHL& l)
{
 if(koeff.Dim() < l.Koeff().Used())
  {
   koeff.ReAlloc(l.Koeff().Used());
   temp1.ReAlloc(l.Koeff().Used());
  }

 koeff.Used()=l.Koeff().Used();
 for(int i=0;i<=koeff.Used();i++)
  koeff[i]=l.Koeff()[i]; 
}



int LANGZAHL::MaxExp(int l)
{
 int i=0;
 double k=1.0;

 while((k <= UINT_MAX) && (k <= l))
  {
   k*=10;
   i++;
  }
 return(i-1);
}



void LANGZAHL::operator=(int l)
{
 int i,j,k=1;

 if(l==0)
   koeff.Used()=-1;
 else
  { 
   j=MaxExp(l);
   koeff.Used()=j;
   if(j > koeff.Dim())
    {
     koeff.ReAlloc(j); 
     temp1.ReAlloc(j); 
    }
   for(i=1;i<=j;i++)
    k*=10;
   for(i=j;i>=0;i--)
    {
     koeff[i]=l / k;
     l-=koeff[i]*k;
     k/=10;
    }
  }  
}




int LANGZAHL::operator==(int l)
{
 int i,j,k=1;

 if(l==0)
  {
   if(koeff.Used()==-1)return(1);
   else return(0);
  }
 else
  { 
   j=MaxExp(l);
   if(j != koeff.Used())
    return(0);
   for(i=1;i<=j;i++)
    k*=10;
   for(i=j;i>=0;i--)
    {
     if(koeff[i] != (l / k))
      return(0);
     l-=koeff[i]*k;
     k/=10;
    }
   return(1);
  } 
}



int LANGZAHL::operator>(int l)
{
 int i,j,k=1;

 if(l==0)
  {
   if(koeff.Used()==-1)return(0);
   else return(1);
  }
 else
  { 
   j=MaxExp(l);
   if(j > koeff.Used())
    return(0);
   if(j < koeff.Used())
    return(1);
   for(i=1;i<=j;i++)
    k*=10;
   for(i=j;i>=0;i--)
    {
     if(koeff[i] < (l / k))
      return(0);
     if(koeff[i] > (l / k))
      return(1);
     l-=koeff[i]*k;
     k/=10;
    }
   return(0);
  } 
}


int LANGZAHL::operator>=(int l)
{
 int i,j,k=1;

 if(l==0)
   return(1);
 else
  { 
   j=MaxExp(l);
   if(j > koeff.Used())
    return(0);
   if(j < koeff.Used())
    return(1);
   for(i=1;i<=j;i++)
    k*=10;
   for(i=j;i>=0;i--)
    {
     if(koeff[i] < (l / k))
      return(0);
     if(koeff[i] > (l / k))
      return(1);
     l-=koeff[i]*k;
     k/=10;
    }
   return(1);
  }  
}


int LANGZAHL::operator<(int l)
{
 int i,j,k=1;

 if(l==0)
  return(0);
 else
  { 
   j=MaxExp(l);
   if(j > koeff.Used())
    return(1);
   if(j < koeff.Used())
    return(0);
   for(i=1;i<=j;i++)
    k*=10;
   for(i=j;i>=0;i--)
    {
     if(koeff[i] < (l / k))
      return(1);
     if(koeff[i] > (l / k))
      return(0);
     l-=koeff[i]*k;
     k/=10;
    }
   return(0);
  } 
}


int LANGZAHL::operator<=(int l)
{
 int i,j,k=1;

 if(l==0)
  {
   if(koeff.Used()==-1)
    return(1);
   else 
    return(0);
  }
 else
  { 
   j=MaxExp(l);
   if(j > koeff.Used())
    return(1);
   if(j < koeff.Used())
    return(0);
   for(i=1;i<=j;i++)
    k*=10;
   for(i=j;i>=0;i--)
    {
     if(koeff[i] < (l / k))
      return(1);
     if(koeff[i] > (l / k))
      return(0);
     l-=koeff[i]*k;
     k/=10;
    }
   return(1);
  } 
}


void LANGZAHL::operator+=(int l)
{
 LANGZAHL L(l);
 (*this)+=L;
}


void LANGZAHL::operator-=(int l)
{
 LANGZAHL L(l);
 (*this)-=L;
}


void LANGZAHL::operator*=(int l)
{
 LANGZAHL L(l);
 (*this)*=L;
}


void LANGZAHL::operator/=(int l)
{
 LANGZAHL L(l);
 (*this)/=L;
}



void LANGZAHL::Print(int einr)
{
 int i,j;

 for(i=1;i<=einr;i++)
  printf(" ");

 i=koeff.Used();
 if(i == -1)
  printf("0");
 while(i >= 0)
  {
   printf("%d",koeff[i]);
   i--;
  }
 printf("\n");
}



void LANGZAHL::Print(FILE* fp,int einr)
{
 int i,j;

 for(i=1;i<=einr;i++)
  fprintf(fp," ");

 i=koeff.Used();
 if(i == -1)
  fprintf(fp,"0");
 while(i >= 0)
  {
   fprintf(fp,"%d",koeff[i]);
   i--;
  }
}


//allocates and fills str 
char* LANGZAHL::StrPrint()
{
 int i,j;
 char help[10];
 char *str;

 i=koeff.Used();
 if(i == -1)
  str=new char[2];
 else
  str=new char[i+2];
 if(str==NULL)
  {
   FatalMess("memory exceeded in LANGZAHL::StrPrint\n");
   exit(0);
  }    

 if(i == -1)
  {
   str[0]='0';
   str[1]='\0';
  }
 else
  {
   j=i;
   while(i >= 0)
    {
     str[j-i]=koeff[i]+'0'; 
     i--;
    }
   str[j+1]='\0';
  }  

 return(str); 
}




void LANGZAHL::Scan(FILE *fp)
{
 char line[500];
 int i;

 if(fgets(line,100,fp)==NULL)
  {
   FatalMess("error in LANGZAHL::Scan\n");
   exit(0);
  }
 koeff.Used()=strlen(line)-2;
 i=(koeff.Used() > 0)?koeff.Used():1;

 koeff.ReAlloc(i);
 temp1.ReAlloc(i);
 koeff.Clear();
 for(i=0;i <= koeff.Used();i++)
  {
   koeff[i]=line[koeff.Used()-i] - '0';
   if((koeff[i] < 0)||(koeff[i] > 9))
    {
     FatalMess("error in LANGZAHL::Scan\n");
     exit(0);
    }
  }  
}



void LANGZAHL::StrScan(char *line)
{
 int i;

 koeff.Used()=strlen(line)-1;
 i=(koeff.Used() > 0)?koeff.Used():1;

 koeff.ReAlloc(i);
 temp1.ReAlloc(i);
 koeff.Clear();
 for(i=0;i <= koeff.Used();i++)
  {
   koeff[i]=line[koeff.Used()-i] - '0';
   if((koeff[i] < 0)||(koeff[i] > 9))
    {
     FatalMess("error in LANGZAHL::Scan\n");
     exit(0);
    }
  }  
}



void LANGZAHL::Bin(int k,int n)
{
 int i,j;

 if(k==n)
  {
   (*this)=1;
   return;
  }
 if(k > n)
  {
   (*this)=0;
   return;
  }  
 (*this)=n;
 for(i=n-1;i>=n-k+1;i--)
  (*this)*=i;
 for(i=2;i<=k;i++)
  (*this)/=i; 
}




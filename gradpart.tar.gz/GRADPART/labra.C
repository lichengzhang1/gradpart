#include "labra.h"
#include "sims.h"
#include "ordConj.h"


//Initialisiere alle Datenstrukturen und belege diese so,
//dass id <= S(n) repraesentiert wird.


void LABRA_BASE::FREE()
{
 basis.FREE();
 basis_inv.FREE();
 vater.FREE();
 kantenmarken.FREE();
 eckenmarken.FREE();
 Delta.FREE();
 IsInv.FREE();
 SiftEin.FREE();
 SN.FREE();
}



void LABRA_BASE::Init(int n)
{
 if(IS_INIT)
  {
   if(grad == n)
    {
     basis.Id();
     basis_inv.Id();
     for(int i=1;i<=grad;i++)
      HV(i)=i;
     return;
    }
   FREE();
  }

 int i;
 grad=n;

 basis.Init(grad);     
 basis_inv.Init(grad);
 vater.Init(grad);

 kantenmarken.Init(grad);
 eckenmarken.Init(grad);
 for(i=1;i<=grad;i++)
  {
   kantenmarken.Add(i,grad);
   eckenmarken.Add(i,grad);
  }

 Delta.Init(grad);
 IsInv.Init(grad);
 SiftEin.Init(grad);
 SN.Init(grad);

 IS_INIT=1;
}



LABRA_BASE::LABRA_BASE(int n)
{
 IS_INIT=0;
 Init(n);
}



LABRA_BASE::LABRA_BASE(SIMS& Kette)
{
 IS_INIT=0;
 Init(Kette.Dim());
 (*this)=Kette;
}


LABRA_BASE::LABRA_BASE(ARRAY < PERMUT < short > >& gens)
{
 IS_INIT=0;
 Init(gens[1].Dim());
 (*this)=gens;
}



//returns the root of vertice i
short LABRA_BASE::HR(int i)
{
 int j;

 j=pi_i(i);
 while(HV(j) != j)
  j=HV(j);

 return(pi(j));
}



int LABRA_BASE::PathExists(int i,int k)
{
 int j1,j2;

  if(i == k)
   return(1);
   
 j1=pi_i(i);
 j2=pi_i(k);
 
 while(HV(j2) != j2)
  {
   if(HV(j2)==j1)
    return(1);
   j2=HV(j2);   
  } 
 
 return(0);
}





void LABRA_BASE::operator=(LABRA_BASE& quelle)
{
 #ifdef DEBUG_TG
  if(grad != quelle.Dim())
   {
    FatalMess("LABRA_TG::operator= mit unterschiedlichem Grad\n");
    char na[1000];
    sprintf(na,"grad=%d\nquelle.Dim()=%d\n",grad,quelle.Dim());
    FatalMess(na);
    exit(0);
   } 
 #endif

 int i;

 for(i=1;i<=grad;i++)
  {
   KM(i)=quelle.KM(i);
   EM(i)=quelle.EM(i);
  }
 basis=quelle.basis;
 basis_inv=quelle.basis_inv;
 vater=quelle.vater;
}





void LABRA_BASE::operator=(ARRAY < PERMUT <short > >& gens)
{
 int i,j,k,l,m;

 _V=new VEKTOR<short>(grad);
 _G_i=new ARRAY < PERMUT < short > >;
 _G_i_min_1=new ARRAY < PERMUT < short > >;

 _G_i->Init(grad);
 for(i=1;i<=grad;i++)
   _G_i->Add(i,grad);

 _G_i_min_1->Init(grad);
 for(i=1;i<=grad;i++)
   _G_i_min_1->Add(i,grad);


 if(gens.Dim() > grad)
  {
   for(j=1;j<=grad;j++)
    V()[j]=j;
 
   for(j=1;j<=gens.Dim();j++)
    Sift(gens[j],1);
  
   G_i_min_1_anz=0;
   for(j=1;j<=grad;j++)
    {
     if(V()[j] != j)
       G_i_min_1()[++G_i_min_1_anz].Swap(G_i()[j]);
    }
  }
 else
  {
   G_i_min_1_anz=gens.Dim();

   for(i=1;i<=gens.Dim();i++)
     G_i_min_1()[i]=gens[i];
  }

 gens_to_labra();

 delete _V;
 delete _G_i;
 delete _G_i_min_1;
}




//gens ist ein ARRAY der richtigen Laenge.
//Es werden die Erzeuger der Gruppe hineingeschrieben.

void LABRA_BASE::GetGens(ARRAY < PERMUT < short > >& gens)
{
 int i,j=1;

 for(i=1;i<=grad;i++)
  {
   if(HV(i) != i)
    gens[j++]=KM(pi(i));
  }

}




//Wandelt eine Simskette in ein labeled branching um

void LABRA_BASE::operator=(SIMS& Kette)
{
 int i,j,k;

 for(i=1;i<=grad;i++)HV(i)=i;
 basis=Kette.Base();
 basis_inv=basis;
 basis_inv.Inv();

 for(i=grad-1;i >= 1;i--)
  {
   for(k=1;k<=Kette[i].Dim();k++)
    {
     if(pi(i) != Kette[i][k][pi(i)])
      {
       j=pi_i( Kette[i][k][pi(i)] );
       if(HV(j) == j)
        {
         HV(j)=i;
         KM(pi(j))=Kette[i][k];
        }   
      } 
    }  
  }


 //Eckenmarken anpassen:

 update_eckenmarken();

}



void LABRA_BASE::InitErz(int nb_gen, int *gen)

{
 int i,j,k;

 _V=new VEKTOR<short>(grad);
 _G_i=new ARRAY < PERMUT < short > >;
 _G_i_min_1=new ARRAY < PERMUT < short > >;

 _G_i->Init(grad);
 for(i=1;i<=grad;i++)
   _G_i->Add(i,grad);

 _G_i_min_1->Init(grad);
 for(i=1;i<=grad;i++)
   _G_i_min_1->Add(i,grad);

 for(j=1;j<=grad;j++)
  V()[j]=j;

 
 G_i_min_1_anz=nb_gen;
 for(i=1;i<=G_i_min_1_anz;i++)
  {
   for(j=1;j<=grad;j++)
     SiftEin[j] = gen[(i - 1) * grad + (j - 1)];
  
   Sift(SiftEin,1);
  }

 G_i_min_1_anz=0;
 for(j=1;j<=grad;j++)
  if(V()[j] != j)
   G_i_min_1()[++G_i_min_1_anz].Swap(G_i()[j]);

 gens_to_labra();

 delete _V;
 delete _G_i;
 delete _G_i_min_1;
}





void LABRA_BASE::ScanErz()
{
 int i,j,k;

 _V=new VEKTOR<short>(grad);
 _G_i=new ARRAY < PERMUT < short > >;
 _G_i_min_1=new ARRAY < PERMUT < short > >;

 _G_i->Init(grad);
 for(i=1;i<=grad;i++)
   _G_i->Add(i,grad);

 _G_i_min_1->Init(grad);
 for(i=1;i<=grad;i++)
   _G_i_min_1->Add(i,grad);

 for(j=1;j<=grad;j++)
  V()[j]=j;

 scanf("%d",&G_i_min_1_anz);
 for(i=1;i<=G_i_min_1_anz;i++)
  {
   SiftEin.Scan();
   Sift(SiftEin,1);
  }

 G_i_min_1_anz=0;
 for(j=1;j<=grad;j++)
  if(V()[j] != j)
   G_i_min_1()[++G_i_min_1_anz].Swap(G_i()[j]);
 
 gens_to_labra();

 delete _V;
 delete _G_i;
 delete _G_i_min_1;
}






//Es wird angenommen, dass in G_i_min_1 die Erzeuger 
//schon eingetragen wurden.
//Algorithmus: Mark Jerrum, Representation for Permutation Groups

void LABRA_BASE::gens_to_labra()
{
 int i;

 basis.Id();
 for(i=1;i<=grad;i++)
  HV(i)=i;
 
 //jetzt ist branching leer

 for(i=1;i<=grad;i++)
  {
   Augment_U_i(i);
   if(i < grad)
    Schreier_und_Sift(i);
  }

 update_eckenmarken();

}




void LABRA_BASE::Augment_U_i(int i)
{
 int j,k,l,m;

 Delta.Clear();
 Delta.Set(i);

 SN.Used()=1;
 SN[1]=i;

 while(SN.Used() > 0)
  {
   j=SN[SN.Used()--];
   for(l=1;l <= G_i_min_1_anz;l++)
    {
     k=G_i_min_1()[l][j];
     if(Delta[k] == 0)
      {
       Delta.Set(k);
       SN[++SN.Used()]=k;
       if(j != i)
        {
         for(m=1;m<=grad;m++)
          U_i()[k][m]=G_i_min_1()[l][U_i()[j][m]];
        }
       else
         U_i()[k]=G_i_min_1()[l];
        
       HV(k)=i;
      }
    }
  }
}





//Es werden die Schreier-Erzeuger von G_i gebildet 
//und nacheinander in ein leeres branching eingesiftet.
//Dazu werden die kantenmarken_neu verwendet, die auch zum
//Basiswechsel gebraucht werden. Einige Namensgebungen
//beziehen sich auf den Basiswechsel, wobei allerdings
//die gleichen Strukturen fuer den Sift-Alg. eingesetzt werden.
//Um die Leserbarkeit zu verbessern existieren deshalb
//verschiedene Makros zum Zugriff auf diese Strukturen.

void LABRA_BASE::Schreier_und_Sift(int i)
{
 int j,k,l,m;

 for(j=1;j<=grad;j++)
  V()[j]=j;
   
 IsInv.Clear();
 for(j=1;j<=grad;j++)
  {
   if(Delta[j] == 1)  //i kann nach j
    {
     for(m=1;m <= G_i_min_1_anz;m++)  //durchlaufe K mit pi
      {
       if(j != i)
        SiftEin=U_i()[j];
       else
        SiftEin.Id();
       SiftEin*=G_i_min_1()[m];
       k=G_i_min_1()[m][j];
       if(IsInv[k] == 0)
        {
         IsInv.Set(k);
         U_i_inv()[k]=U_i()[k];
         U_i_inv()[k].Inv();
        }        
       if(k != i)
        SiftEin*=U_i_inv()[k];

       Sift(SiftEin,i);
      }
    }
  }
 
 //Die Erzeuger von G_i sind jetzt berechnet
 //Die Erzeuger von G_(i-1) werden nicht mehr gebraucht

 G_i_min_1_anz=0;
 for(j=1;j<=grad;j++)
  {
   if(V()[j] != j)
     G_i_min_1()[++G_i_min_1_anz].Swap(G_i()[j]);
  }
}





void LABRA_BASE::Sift(PERMUT<short>& p,int i)
{
 int j,k,flag,l,m;
 PERMUT<short> d(grad);

 j=i;
 while((p[j] == j)&&(j < grad))j++;
 k=p[j];

 flag=0;
 l=k;
 while((m=V()[l]) != l)
  {
   if((m == j)&&(j < grad))
    {
     flag=1;
     break;
    }
   l=m;  
  }
 
 while(flag)  //Zeilen 3-6 bei Mark Jerrum
  {
   l=k;
   while((m=V()[l]) != l)
    {
     d=G_i()[l];
     d.Inv();
     p*=d;

     if((m == j)&&(j < grad))
       break;
      
     l=m;  
    }
   j=i;
   while((p[j] == j)&&(j < grad))j++;
   k=p[j];
 
   flag=0;
   l=k;
   while((m=V()[l]) != l)
    {
     if((m == j)&&(j < grad))
      {
       flag=1;
       break;
      }
     l=m;  
    }
  }

 if(j == grad)return;

 while((V()[k] != k)&&(V()[k] > j)) //Zeilen 8-10 bei Jerrum
  {
   d=G_i()[k];
   d.Inv();
   p*=d;
   k=V()[k];
  } 

 if(V()[k] == k) //Zeilen 11-13 bei Jerrum
  {
   V()[k]=j;
   G_i()[k]=p;
  }
 else             //Zeilen 14-18 bei Jerrum
  {
   d.Swap(G_i()[k]);
   G_i()[k].Swap(p);
   p.Swap(d);
   d=G_i()[k];
   d.Inv();
   p*=d;

   V()[k]=j;
   Sift(p,i);
  }
}







void LABRA_BASE::update_eckenmarken()
{
 int k,j;

 for(k=1;k<=grad;k++)
  {
   if((j=HV(k)) != k)
    {
     if(HV(j) != j)
      {
       EM(pi(k))=EM(pi(j));
       EM(pi(k))*=KM(pi(k));       
      }
     else 
      EM(pi(k))=KM(pi(k));
    }
   else
    EM(pi(k))=KM(pi(k));
  }
}




void LABRA_BASE::Print()
{
 int i;

 printf("Es wird eine Gruppe ausgegeben:\n");
 printf("(erst Kantenmarke, dann Eckenmarke)\n");
 printf("BASIS=\n");
 basis.Print(0);
 for(i=1;i<=grad;i++)
  {
   printf("Nr.%d Vater:%d\n",pi(i),pi(HV(i)));
   if(pi(i) != pi(HV(i)))
    {
     KM(pi(i)).Print(0);
     EM(pi(i)).Print(0);
    }
  }

 fflush(stdout);

}



//Zurueckgegeben werden die Nachfolger von pi(i)
void LABRA_BASE::Nachfolger_start(int i)
{
 #ifdef DEBUG_TG
  if((i<1) || (i > grad))
   { 
    FatalMess("LABRA_TG::Nachfolger_start mit falschem i\n");
    exit(0);
   }
 #endif

 nachfolger_nr=i;
 is_last_Nachfolger=0;

 while((nachfolger_nr <= grad)&&(! PathExists(pi(i),pi(nachfolger_nr))))
  nachfolger_nr++;

 if(nachfolger_nr > grad)
  is_last_Nachfolger=1;
}




int LABRA_BASE::Nachfolger(int i)
{
 #ifdef DEBUG_TG
  if((i<1) || (i > grad))
   { 
    FatalMess("LABRA_TG::Nachfolger mit falschem i\n");
    exit(0);
   }
 #endif

 int j=nachfolger_nr;

 nachfolger_nr++;
 while((nachfolger_nr <= grad)&&(! PathExists(pi(i),pi(nachfolger_nr))))
  nachfolger_nr++;

 if(nachfolger_nr > grad)
   is_last_Nachfolger=1;

 return(pi(j));
}






void LABRA_BASE::Sohn_start(int i)
{
 #ifdef DEBUG_TG
  if((i<1) || (i > grad))
   { 
    FatalMess("LABRA_TG::Sohn_start mit falschem i\n");
    exit(0);
   }
 #endif

 sohn_nr=i+1;
 is_last_sohn=0;

 while((sohn_nr <= grad)&&(HV(sohn_nr)!=i))
  sohn_nr++;

 if(sohn_nr > grad)
  is_last_sohn=1;
}







/****************************************************************/
//Es werden die Kantenmarken der Soehne von pi(i) zurueckgegeben
//=> erlaubt ist i=1,...,i=grad
//Aufruf:
//   Sohn_start(i);
//   while(! IsLastSohn())
//    {
//     PERMUT<short>& perm=Sohn(i);
//     "irgendetwas"
//    }
/****************************************************************/

PERMUT<short>& LABRA_BASE::Sohn(int i)
{
 #ifdef DEBUG_TG
  if((i<1) || (i > grad))
   { 
    FatalMess("LABRA_TG::Sohn mit falschem i\n");
    exit(0);
   }
 #endif

 int j=sohn_nr;

 sohn_nr++;
 while((sohn_nr <= grad)&&(HV(sohn_nr)!=i))
  sohn_nr++;

 if(sohn_nr > grad)
   is_last_sohn=1;

 return(KM(pi(j)));
}





void LABRA_BASE::StabErz_start(int i)
{
 #ifdef DEBUG_TG
  if((i<0) || (i > grad))
   { 
    FatalMess("LABRA_BASE::StabErz_start mit falschem i\n");
    exit(0);
   }
 #endif

 ret_stab_nr=i+1;
 is_last_st=0;

 while((ret_stab_nr <= grad)&&
       ((HV(ret_stab_nr)==ret_stab_nr) || 
        (HV(ret_stab_nr)<=i))) 
  ret_stab_nr++;

 if(ret_stab_nr > grad)
   is_last_st=1;

}





/****************************************************************/
//Es werden Erzeuger von Stab_G({pi(1),...,pi(i)}) zurueckgegeben
//=> erlaubt ist i=0,...,i=grad
//j=0 => beginne Durchlauf
//Aufruf:
//   StabErz_start(i);
//   while(! IsLastStabErz())
//    {
//     PERMUT<short>& perm=StabErz(i)
//     "irgendetwas"
//    }
/****************************************************************/

PERMUT<short>& LABRA_BASE::StabErz(int i,int& km_nr)
{
 #ifdef DEBUG_TG
  if((i<0) || (i > grad))
   { 
    FatalMess("LABRA_BASE::StabErz mit falschem i\n");
    exit(0);
   }
 #endif

 int j=ret_stab_nr;

 ret_stab_nr++;
 while((ret_stab_nr <= grad)&&
       ((HV(ret_stab_nr)==ret_stab_nr) || 
        (HV(ret_stab_nr)<=i))) 
    ret_stab_nr++;

 if(ret_stab_nr > grad)
   is_last_st=1;


 km_nr=pi(j);

 return(KM(pi(j)));
}





PERMUT<short>& LABRA_BASE::StabErz(int i)
{
 #ifdef DEBUG_TG
  if((i<0) || (i > grad))
   { 
    FatalMess("LABRA_TG::StabErz mit falschem i\n");
    exit(0);
   }
 #endif

 int j=ret_stab_nr;

 ret_stab_nr++;
 while((ret_stab_nr <= grad)&&
       ((HV(ret_stab_nr)==ret_stab_nr) || 
        (HV(ret_stab_nr)<=i))) 
    ret_stab_nr++;

 if(ret_stab_nr > grad)
   is_last_st=1;


 return(KM(pi(j)));
}


//checks if point x is stabilized by the group
int LABRA_BASE::Stabilizes(int x)
{
 int i;

 for(i=1;i<=grad;i++)
  {
   if((HV(i) != i)&&(KM(pi(i))[x] != x))
    return(0);
  }
 return(1); 
}



LANGZAHL& LABRA_BASE::Ordnung()
{
 order=1;
 
 int *Nr;
 Nr=new int[grad+1];
 if(Nr==NULL)
  {
   FatalMess("Kein Speicher in LABRA_TG::Ordnung\n");
   exit(0);
  }
 
 int i;

 for(i=1;i<=grad;i++)
   Nr[i]=1;

 for(i=grad;i>=1;i--)
  if(HV(i) != i)
   Nr[HV(i)]+=Nr[i];
 
 for(i=1;i<=grad;i++)
  order*=Nr[i];

 delete[] Nr;
 return(order);
}



LABRA_TG::LABRA_TG(int n)
{
 IS_INIT=0;
 Init(n);
}



LABRA_TG::LABRA_TG(SIMS& Kette)
{
 IS_INIT=0;
 Init(Kette.Dim());
 ((LABRA_BASE&)(*this))=Kette;
}



LABRA_TG::LABRA_TG(ARRAY < PERMUT < short > >& gens)
{
 IS_INIT=0;
 Init(gens[1].Dim());
 ((LABRA_BASE&)(*this))=gens;
}



void LABRA_TG::FREE()
{
 ConjRep.FREE();
 basis_neu.FREE();
 dummy.FREE();
 basis_neu_inv.FREE();
 vater_neu.FREE();
 kantenmarken_neu.FREE();
 eckenmarken_neu.FREE();
 root.FREE();
 coseflag.FREE();
 orbitlist.FREE();
 newpoints.FREE();
 pointlist.FREE();
 orbit.FREE();
 delta.FREE();
 bo_m.FREE();
 cosetrep.FREE();
 br_a_soehne.FREE();
}



void LABRA_TG::Init(int n)
{
 int i;

 if(IS_INIT)
  {
   if(grad == n)
    {
     basis.Id();
     basis_inv.Id();
     for(i=1;i<=grad;i++)
      HV(i)=i;
     return;
    }
   FREE();
  }

 LABRA_BASE::Init(n);

 ConjRep.Init(grad);
 ORD=NULL;

 basis_neu.Init(grad);
 dummy.Init(grad);
 basis_neu_inv.Init(grad);
 vater_neu.Init(grad);
 
 kantenmarken_neu.Init(grad);
 eckenmarken_neu.Init(grad);

 for(i=1;i<=grad;i++)
  {
   kantenmarken_neu.Add(i,grad);
   eckenmarken_neu.Add(i,grad);
  }

 root.Init(grad);
 coseflag.Init(grad);
 orbitlist.Init(grad);
 newpoints.Init(grad);
 pointlist.Init(grad);
 orbit.Init(grad);
 delta.Init(grad);

 bo_m.Init(grad);
 
 cosetrep.Init(grad);
 for(i=1;i<=grad;i++)
  cosetrep.Add(i,grad);

 br_a_soehne.REALLOC(grad,grad);

 IS_INIT=1;
}





void LABRA_TG::operator=(LABRA_TG& quelle)
{
 (*((LABRA_BASE*)this))=(LABRA_BASE&)quelle;
}





//L sollte Basis id haben. L hat den halben Grad von (*this).
//Die Pemutationen aus L werden so verlaengert, dass die entstehende 
//Gruppe simultan auf Zeilen und Spalten einer quadratischen Matrix
//operiert.
void LABRA_TG::VerdoppeleGruppe(LABRA_TG &L)
{
 #ifdef DEBUG_TG
  if(2*L.Dim() != Dim())
   {
    FatalMess("Dimensionsfehler bei LABRA_TG::VerdoppeleGruppe\n");
    exit(0);
   }
 #endif

 int i,j;

 basis.Id();
 for(i=1;i<=Dim();i++)
  vater[i]=i;
 for(i=1;i<=L.Dim();i++)
  HV(i)=L.HV(i);
 
 for(i=1;i<=L.Dim();i++)
  {
   for(j=1;j<=L.Dim();j++)
    {
     KM(i)[j]=L.KM(i)[j];
     KM(i)[j+L.Dim()]=KM(i)[j]+L.Dim();
     EM(i)[j]=L.EM(i)[j];
     EM(i)[j+L.Dim()]=EM(i)[j]+L.Dim();
    }
  }
}



void LABRA_TG::SetDn()
{
 ARRAY < PERMUT < short > > gens;
 int i,j,k;

 if(grad % 2 == 0)
  {
   gens.REALLOC(3,grad);
   for(i=1;i < grad;i++)
    gens[1][i] = i+1;
   gens[1][grad] = 1;
   
   gens[2][1] = 1;
   gens[2][grad/2 + 1] = grad/2 + 1;
   for(i=2;i<=grad/2;i++)
    {
     gens[2][i] = grad-(i-2);
     gens[2][grad-(i-2)] = i;
    }          

   gens[3][1] = 2;
   gens[3][2] = 1;
   for(i=3;i <= grad/2 + 1;i++)
    {
     gens[3][i] = grad-(i-3);
     gens[3][grad-(i-3)] = i;    
    }
  }
 else
  { 
   gens.REALLOC(2,grad);
   for(i=1;i < grad;i++)
    gens[1][i] = i+1;
   gens[1][grad] = 1;

   for(i=2;i <= grad/2+1;i++)
    {
     gens[2][i] = grad-(i-2);
     gens[2][grad-(i-2)] = i;
    }
  }
 (*((LABRA_BASE*)(this))) = gens;
}



//initialize this with the full symmetric group
void LABRA_TG::SetSym()
{
 int i,j;

 basis.Id();
 for(i=1;i<=grad;i++)
  HV(i)=i;

 for(i=2;i<=grad;i++)
  {
   HV(i)=i-1;
   KM(i).Id();
   KM(i)[i]=i-1;
   KM(i)[i-1]=i;
  }
 update_eckenmarken();
}





//dim_vektor contains the partition of the young-subgroup
void LABRA_TG::SetYoung(VEKTOR < short >& dim_vektor)
{
 int i,j,k;

 #ifdef DEBUG_TG
  i=0;
  for(j=1;j<=dim_vektor.Used();j++)
   i+=dim_vektor[j];
  if(i != grad)
   {
    FatalMess("Wrong parameters in LABRA_TG::SetYoung\n");
    exit(0);
   }
 #endif

 
 basis.Id();
 for(i=1;i<=grad;i++)
  HV(i)=i;

 k=0;
 for(i=1;i<=dim_vektor.Used();i++)
  {
   for(j=1;j<=dim_vektor[i];j++)
    {
     k++;
     if(j > 1)
      {
       HV(k)=k-1;
       KM(k).Id();
       KM(k)[k]=k-1;      
       KM(k)[k-1]=k;      
      }
    }
  }         
 update_eckenmarken();
}



//Bildet das direkte Produkt der Gruppen LeftGroup und RightGroup
//Die Dimensionen der Gruppen muessen stimmen.

void LABRA_TG::DirProd(LABRA_TG& LeftGroup,LABRA_TG& RightGroup)
{
 #ifdef DEBUG_TG
  if(Dim() != LeftGroup.Dim()+RightGroup.Dim())
   {
    FatalMess("Fehler bei LABRA_TG::DirProd\n");
    exit(0);
   }
 #endif

 int i,j;

 for(i=1;i<=LeftGroup.Dim();i++)
  {
   pi(i)=LeftGroup.pi(i);
   HV(i)=LeftGroup.HV(i);
  }
 for(i=LeftGroup.Dim()+1;i<=Dim();i++)
  {
   pi(i)=RightGroup.pi(i-LeftGroup.Dim())+LeftGroup.Dim();
   HV(i)=RightGroup.HV(i-LeftGroup.Dim())+LeftGroup.Dim();
  }
 basis_inv=basis;
 basis_inv.Inv();
 
 for(i=1;i<=LeftGroup.Dim();i++)
  {
   for(j=1;j<=LeftGroup.Dim();j++)
    {
     KM(pi(i))[j]=LeftGroup.KM(LeftGroup.pi(i))[j];
     EM(pi(i))[j]=LeftGroup.EM(LeftGroup.pi(i))[j];
    }
   for(j=LeftGroup.Dim()+1;j<=Dim();j++)
    {
     KM(pi(i))[j]=j;
     EM(pi(i))[j]=j;
    }
  }


 for(i=LeftGroup.Dim()+1;i<=Dim();i++)
  {
   for(j=1;j<=LeftGroup.Dim();j++)
    {
     KM(pi(i))[j]=j;
     EM(pi(i))[j]=j;
    }
   for(j=LeftGroup.Dim()+1;j<=Dim();j++)
    {
     KM(pi(i))[j]=RightGroup.KM(RightGroup.pi(i-LeftGroup.Dim()))
                              [j-LeftGroup.Dim()]+LeftGroup.Dim();;
     EM(pi(i))[j]=RightGroup.EM(RightGroup.pi(i-LeftGroup.Dim()))
                              [j-LeftGroup.Dim()]+LeftGroup.Dim();
    }
  }

}





//this = Stab_Q(Q.pi(1),...,Q.pi(i))
//Eckenmarken bleiben noch unbelegt
void LABRA_TG::CopyStab(LABRA_TG& Q,int i)
{
 int j,k,nr;

 for(j=1;j<=grad;j++)
  {
   basis[j]=Q.pi(j);
   HV(j)=j;
  }

 basis_inv=basis;
 basis_inv.Inv();


 nr=i+1;
 while((nr <= grad)&&
       ((Q.HV(nr)==nr) || 
        (Q.HV(nr)<=i))) 
  nr++;

 if(nr > grad)
  return;

 while(1)
  {
   KM(pi(nr))=Q.KM(pi(nr));
   HV(nr)=Q.HV(nr);
   nr++;
   while((nr <= grad)&&
       ((Q.HV(nr)==nr) || 
        (Q.HV(nr)<=i))) 
    nr++;
   if(nr > grad)
     return;
  }
}




void LABRA_TG::cycle_node_bottom()
{
 int i,j,m;

 root.Clear();
 ~root;
 for(i=1;i<=grad;i++)
   HV_N(i)=i;
 bo_m.Used()=0;
 //Zeile (1) in DA

 basis_neu=basis;
 pi_N(R)=pi(S);
 for(i=R+1;i<=S;i++)
  pi_N(i)=pi(i-1);
 basis_neu_inv=basis_neu;
 basis_neu_inv.Inv();
 //basis_neu ist belegt

 for(j=S+1;j<=grad;j++)
  {
   i=HV(j);
   if((S < i) && (i != j))
    {
     HV_N(j)=i;
     root.Reset(j);
     bo_m[++bo_m.Used()]=j;
    }
  }

}




void LABRA_TG::cycle_node_middle()
{
 int i,j,m,p,q;

 init_data();
 
 for(j=S;j >= R+1;j--)
  {
   delta=br_a_soehne[j-1];
   for(m=j-1;m<=grad;m++)
    {
     if(delta[m] == 1) //d.h. pi(m) ist in delta
      {
       p=pi(S);
       if(HV(m) != m)
        {
         i=1;
         while(EM(pi(m))[i] != p)i++;
         p=i;
        }
       if(HV(j-1) != j-1)
        p=EM(pi(j-1))[p];
       p=pi_i(p);
       if(orbit[p] == 1)
        {
         q=pi_i_N(pi(m));
         if((q != j) && (root[q] == 1))
          {
           root.Reset(q);
           HV_N(q)=j;
           KM_N(pi_N(q))=cosetrep[p];
           if(HV(j-1) != j-1)
            {
             dummy=EM(pi(j-1));
             dummy.Inv();
             KM_N(pi_N(q))*=dummy;
            }
           if(HV(m) != m)
            KM_N(pi_N(q))*=EM(pi(m));           
          } 
        }
      }
    }
   update_orbit(j);
  }

 delta=orbit;

 for(m=1;m<=grad;m++)
  {
   if(delta[m] == 1)
    {
     q=pi_i_N(pi(m));
     if((q != R)&&(root[q] == 1))
      {
       root.Reset(q);
       HV_N(q)=R;
       KM_N(pi_N(q)).Swap(cosetrep[m]);
      }
    }
  }

 for(j=1;j<=bo_m.Used();j++)
   KM_N(pi_N(bo_m[j])).Swap(KM(pi(bo_m[j]))); 

}





void LABRA_TG::cycle_node_top()
{
 int i,j,k,m;

 for(i=R;i<=grad;i++)
  {
   if(root[i] == 1)
    {
     m=pi_i(pi_N(i));
     j=m;
     while((HV(j) != j) && (j >= R))
      j=HV(j);
     if(j < R)
      {
       HV_N(i)=j;
       if(HV(m) != m)
        EM_N(pi_N(i)).Swap(EM(pi(m)));
       else
        EM_N(pi_N(i)).Id();
       if(HV(m) == j)
        { 
         if(HV(m) != m)
          KM_N(pi_N(i)).Swap(KM(pi(m)));
         else
          KM_N(pi_N(i)).Id();  
        }
       else
        {
         if(HV(j) != j)
          {
           KM_N(pi_N(i))=EM(pi(j));
           KM_N(pi_N(i)).Inv();
          }
         else
          KM_N(pi_N(i)).Id(); 
         if(HV_N(i) != i) 
          KM_N(pi_N(i))*=EM_N(pi_N(i));
        }  
      }
    }
   else
    {
     if(HV_N(HV_N(i)) != HV_N(i))
      EM_N(pi_N(i))=EM_N(pi_N(HV_N(i)));
     else
      EM_N(pi_N(i)).Id();
     if(HV_N(i) != i) 
      EM_N(pi_N(i))*=KM_N(pi_N(i));
    }
  }

 for(i=1;i<=R-1;i++)
  {
   HV_N(i)=HV(i);
   EM_N(pi_N(i)).Swap(EM(pi(i)));
   KM_N(pi_N(i)).Swap(KM(pi(i)));
  }

}






void LABRA_TG::update_orbit(int j)
{
 int i,k,l,p,q;


 newpoints.Clear();
 Sohn_start(j-1);
 while(! IsLastSohn())
  {
   PERMUT<short>& g=Sohn(j-1);
   for(p=1;p<=grad;p++)
    {
     if(orbitlist[p] == 1)
      {
       q=pi_i(g[pi(p)]);
       if(orbit[q] == 0)
        {
         orbit.Set(q);
         cosetrep[q]=cosetrep[p];
         cosetrep[q]*=g;
         newpoints.Set(q);
        }
      }
    }
  }

 while(! newpoints.IsEmpty())
  {
   orbitlist |= newpoints;
   pointlist=newpoints;
   newpoints.Clear();
   StabErz_start(j-1);
   while(! IsLastStabErz())
    {
     PERMUT<short>& g=StabErz(j-1);
     for(p=1;p<=grad;p++)
      {
       if(pointlist[p] == 1)
        {
         q=pi_i(g[pi(p)]);
         if(orbit[q] == 0)
          {
           orbit.Set(q);
           cosetrep[q]=cosetrep[p];
           cosetrep[q]*=g;
           newpoints.Set(q);
          }  
        }
      }
    }
  }
}



//br_a_soehne[i] ist ein Bitvektor mit den Soehnen
//von pi(i).
//br_a_soehne[i][j]==1 => pi(j) ist Sohn von pi(i)

void LABRA_TG::update_soehne()
{
 int i;

 for(i=1;i<=grad;i++)
  br_a_soehne[i].Clear();

 for(i=grad;i>0;i--)
  {
   br_a_soehne[i].Set(i);
   br_a_soehne[HV(i)] |= br_a_soehne[i];  
  }
}



//Zeile (1) von cycle_node_middle in DA

void LABRA_TG::init_data()
{
 int i;

 update_soehne();
 orbit=br_a_soehne[S]; 
 cosetrep[S].Id();
 
 for(i=S+1;i<=grad;i++)
  {
   if(orbit[i] == 1) //d.h. pi(i) liegt im Teilbaum von pi(S)
    {
     cosetrep[i]=cosetrep[HV(i)];
     if(HV(i) != i)
      cosetrep[i]*=KM(pi(i));
    }
  }
 orbitlist=br_a_soehne[S];
}




void LABRA_TG::Cycle(int r,int s)
{
 R=r;
 S=s;
 
 cycle_node_bottom();
 cycle_node_middle();
 cycle_node_top();

 basis.Swap(basis_neu);
 basis_inv.Swap(basis_neu_inv);
 vater.Swap(vater_neu);
 kantenmarken.Swap(kantenmarken_neu);
 eckenmarken.Swap(eckenmarken_neu);
}




void LABRA_TG::CycleId()
{
 int i;

 for(i=1;i<=grad;i++)
  {
   if(pi(i) != i)
    Cycle(i,pi_i(i));
  }
}


void LABRA_TG::ConjStart(PERMUT<short>& per_v)
{
 int i,j,anz,d;
 int s,z,k;

 VEKTOR<short> z_p,s_p;
 VEKTOR<short> s_u,s_o,z_u,z_o;
 LABRA_TG G,T;

 s=grad;
 z=s;
 s_p.Init(s);
 z_p.Init(z);
 for(i=1;i<=z;i++)
  z_p[i]=i;
 for(i=1;i<=s;i++)
  s_p[i]=i+z;
 G.Init(z+s);
 G.VerdoppeleGruppe(*this);
 ORD=new ORDTREU_CONJ_CLASSES;
 ORD->GetMAX_VAL() = 1;
 ORD->Spalten()=s;
 ORD->Zeilen()=z;
 ORD->Anz()=s;
 ORD->GetGROUP_IS_ID()=0;
 ORD->GetIND_GROUP_IS_ID()=0;
 ORD->GetIS_NULL_REP()=0;
 ORD->Gruppe().Init(G.Dim()); 
 ORD->AutGruppe().Init(G.Dim()); 
 ORD->Gruppe()=G;
 ORD->GetKette().Init(s);
 basis_inv = basis;
 basis_inv.Inv();
 T.Init(s);
 T = (*this);
 for(i=1;i<=grad;i++)
  {
   if(T.pi(i) != per_v[i])
    T.Cycle(i,T.pi_i(per_v[i]));
  }
 ORD->GetKette()=T;
 ORD->SetPERMUT_NUMBERING(per_v);
 ORD->Init(1);
 ORD->GetENABLE_AUT()=1;
 ORD->GetPRINT_SOLUTIONS()=0;
 ORD->GetPRINT_ANZ_CANDIDATES()=0;
 ORD->GetPRINT_CANDIDATES()=0;
 for(i=1;i<=z;i++)
  ORD->Zei_Nr()[i]=z_p[i];
 for(i=1;i<=s;i++)
  ORD->Sp_Nr()[i]=s_p[i];
 ORD->Inv_sz().ReAlloc(G.Dim());
 for(i=1;i<=z;i++)
  ORD->Inv_sz()[z_p[i]]=i;
 for(i=1;i<=s;i++)
  ORD->Inv_sz()[s_p[i]]=i;
 ConjAnz=0;
 L1=0; 
 Ordnung();
}



void LABRA_TG::ConjStart()
{
 int i,j,anz,d;
 int s,z,k;

 VEKTOR<short> z_p,s_p;
 VEKTOR<short> s_u,s_o,z_u,z_o;
 LABRA_TG G;

 s=grad;
 z=s;
 s_p.Init(s);
 z_p.Init(z);
 for(i=1;i<=z;i++)
  z_p[i]=i;
 for(i=1;i<=s;i++)
  s_p[i]=i+z;
 G.Init(z+s);
 G.VerdoppeleGruppe(*this);
 ORD=new ORDTREU_CONJ_CLASSES;
 ORD->GetMAX_VAL() = 1;
 ORD->Spalten()=s;
 ORD->Zeilen()=z;
 ORD->Anz()=s;
 ORD->GetGROUP_IS_ID()=0;
 ORD->GetIND_GROUP_IS_ID()=0;
 ORD->GetIS_NULL_REP()=0;
 ORD->Gruppe().Init(G.Dim()); 
 ORD->AutGruppe().Init(G.Dim()); 
 ORD->Gruppe()=G;
 ORD->GetKette().Init(s);
 basis_inv = basis;
 basis_inv.Inv();
 ORD->GetKette()=(*this);

 ORD->SetROWWISE_NUMBERING();

 ORD->SetLOW_MEM();
 ORD->Init(1);
 ORD->GetENABLE_AUT()=1;
 ORD->GetPRINT_SOLUTIONS()=0;
 ORD->GetPRINT_ANZ_CANDIDATES()=0;
 ORD->GetPRINT_CANDIDATES()=0;
 for(i=1;i<=z;i++)
  ORD->Zei_Nr()[i]=z_p[i];
 for(i=1;i<=s;i++)
  ORD->Sp_Nr()[i]=s_p[i];
 ORD->Inv_sz().ReAlloc(G.Dim());
 for(i=1;i<=z;i++)
  ORD->Inv_sz()[z_p[i]]=i;
 for(i=1;i<=s;i++)
  ORD->Inv_sz()[s_p[i]]=i;
 ConjAnz=0;
 L1=0; 
 Ordnung().Print(0);
 fflush(stdout);
}





int LABRA_TG::NextConjClass()
{
 int i,j; 

 if(L1==order)
   {
    delete ORD;
    ORD=NULL;
    return(0);
   } 
 if(ORD->NextRep())
  {
   L2=order;

   L2/=ORD->AutGruppe().Ordnung();
   L1+=L2;
   ConjAnz++;
   for(i=1;i<=grad;i++)
    {
     for(j=1;j<=grad;j++)
      {
       if(ORD->Erg(i,j) == 1)
        {
         ConjRep[i]=j;
         break;
        }
      } 
    }  
   return(1);
  }
 delete ORD;
 return(0);
}








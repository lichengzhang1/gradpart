#include "impldata.h"
#include "bitvec.h"

void impl::operator=(impl& q)
{
 int i,j;

 first_col_nr = q.first_col_nr;
 l_dim = q.l_dim;
 r_dim = q.r_dim;
 n = q.n;
 k = q.k;
 n_i = q.n_i;
 fak = q.fak;
 change_rows = q.change_rows;
 idx = q.idx;
 constr_idx = q.constr_idx;
 m_i = q.m_i;
 ab = q.ab;
 nr = q.nr; 
}



IMPL_DATA::IMPL_DATA(int _dim)
{
 Init(_dim);
}


void IMPL_DATA::Init(int _dim)
{
 dim=_dim;
 mat.REALLOC(dim,dim);
 hilf_mat.REALLOC(dim,dim);
 erg.Init(dim);
 constr.Init(dim);
 imp_str.Used()=0;
}



void IMPL_DATA::ConstrStart()
{
 int i,j;

 is_last=0;
 COMP=1;
 PROD=1;
 for(i=1;i<=imp_str.Used();i++)
  {
   for(j=1;j<=imp_str[i].Used();j++)
     PROD*=imp_str[i].GetNr(j).fak;
  }
}




int IMPL_DATA::ConstructNextSolution()
{
 if(is_last==1)
  return(0);
 if(COMP == PROD)
  is_last=1;

 Comp_Rep(COMP);
 COMP+=1;
 return(1);
}



void IMPL_DATA::Comp_Rep(LANGZAHL &L)
{
 int i,j,k,l,m,io,jo,lo,mo,nr;
 VEKTOR < short >   sums;
 BITVEK             bi; 

 if((imp_str.Used() == 0)||
    ((imp_str.Used()==1)&&(imp_str[1].Used()==0)))
  {
   constr.GetNBList() = erg.GetNBList();
   constr.GetNBWert() = erg.GetNBWert();
   if(erg.IsSplit())
    {
     constr.GetSplitTree()=erg.GetSplitTree();
     constr.IsSplit()=1;
    }
   else
    constr.IsSplit()=0; 
   return; 
  }

 for(i=1;i<=dim;i++)
  mat[i].Clear();
 for(i=1;i<=dim;i++)
  {
   for(j=1;j<=erg.GetNBList()[i].Used();j++)
    {
     mat[i][erg.GetNBList()[i][j]] = erg.GetNBWert()[i][j];
     mat[erg.GetNBList()[i][j]][i] = mat[i][erg.GetNBList()[i][j]];
    }  
  }

 k=0;
 for(nr=1;nr<=imp_str.Used();nr++)
  k+=imp_str[nr].Used();
 a_counter.Setk(k);
 j=0;
 for(nr=1;nr<=imp_str.Used();nr++)
  for(i=1;i<=imp_str[nr].Used();i++)
   a_counter.SetZ(++j,imp_str[nr].GetNr(i).fak);

 a_counter.Start(L);
 
 j=0;
 for(nr=1;nr<=imp_str.Used();nr++)
  for(i=1;i<=imp_str[nr].Used();i++)
   imp_str[nr].GetNr(i).nr=a_counter.Getnr_i(++j);

 i=0;
 for(l=1;l<=imp_str.Used();l++)
  {
   for(m=1;m<=imp_str[l].Used();m++)
    {
     i++;
     impl& IM = imp_str[l].GetNr(m);
     a_unrank_multi.Setn(IM.n);
     a_unrank_multi.Setk(IM.k);
     for(k=1;k<=IM.k;k++)
      a_unrank_multi.Setn_i(k,IM.n_i[k]); 
     a_unrank_multi.Start(a_counter.Getnr_i(i));     
     sums.ReAlloc(IM.n);
     bi.ReAlloc(IM.n);
     sums.Clear();
     bi.Clear();
     if(IM.change_rows == 1)
      {
       for(k=1;k<=IM.n;k++)
        for(j=IM.ab;j<=IM.ab + IM.r_dim -1;j++)
         sums[k] += mat[IM.idx[k]][j];
      }
     else
      {
      //l_dim ist nur im ersten struct gespeichert, weil fuer 
      //alle anderen gleich 
       for(k=1;k<=IM.n;k++)
        for(j=IM.ab;j>= IM.ab - imp_str[l].GetNr(1).l_dim +1;j--)
         sums[k] += mat[j][IM.idx[k]];
      } 
     //ordne IM.idx so, dass bzgl. der Belegung Uebereinstimmung
     //mit IM.n_i herrscht. ( nur zur Sicherheit )    
     io=0;                                   
     for(j=1;j<=IM.k;j++)
      {
       jo=1;lo=0;
       while(1)
        {
         while(bi[jo]==1)jo++;
         lo=1;
         for(mo=1;mo<=IM.n;mo++)
          if((mo != jo)&&(bi[mo]==0)&&(sums[mo]==sums[jo]))
           lo++;
         if(lo ==  IM.n_i[j])
          break; 
         jo++;
        } 
       for(mo=1;mo<=IM.n;mo++)
        if((bi[mo]==0)&&(sums[mo]==sums[jo]))
          {
           bi.Set(mo);
           IM.constr_idx[++io]=IM.idx[mo];
          }
      }
     IM.idx.Swap(IM.constr_idx);
     //belege nun IM.m_i
     lo=0;
     for(io=1;io<=IM.k;io++)
      {
       for(jo=1;jo<=IM.n;jo++)
        {
         if(a_unrank_multi.GetLoes()[jo] == io)
          IM.m_i[++lo]=jo;
        }
      }
    }
  } 
 
 //jetzt muss die Matrix manipuliert werden
 for(l=1;l<=imp_str.Used();l++)
  {
   for(m=1;m<=imp_str[l].Used();m++)
    {
     impl& IM = imp_str[l].GetNr(m);
     IM.constr_idx=IM.idx;
    }
  } 
 for(l=1;l<=imp_str.Used();l++)
  {
   for(m=1;m<=imp_str[l].Used();m++)
    {
     impl& IM = imp_str[l].GetNr(m);
     if(IM.change_rows == 1)
      {
       for(i=1;i<=IM.n;i++)
	{
         for(j=IM.ab;j<=dim;j++)
          hilf_mat[IM.constr_idx[IM.m_i[i]]][j] =
            mat[IM.constr_idx[i]][j];
         for(j=1;j<imp_str[l].GetNr(1).first_col_nr;j++)
          hilf_mat[j][IM.constr_idx[IM.m_i[i]]]=
            mat[j][IM.constr_idx[i]];
	}
       for(i=1;i<=IM.n;i++)
	{
         for(j=IM.ab;j<=dim;j++)
          mat[IM.constr_idx[i]][j]=hilf_mat[IM.constr_idx[i]][j];
         for(j=1;j<imp_str[l].GetNr(1).first_col_nr;j++)
          mat[j][IM.constr_idx[i]]=hilf_mat[j][IM.constr_idx[i]];
        }
       //Zeilen in mat sind vertauscht.
       //constr_idx der folgenden structs muss angepasst werden
       for(io=l;io<=imp_str.Used();io++)
        {
         if(io==l)jo=m+1;
         else jo=1;
         for(lo=jo;lo<=imp_str[io].Used();lo++)
          {
           impl& IM2 = imp_str[io].GetNr(lo);
           for(i=1;i<=IM2.n;i++)
            {
             for(j=1;j<=IM.n;j++)
              {
               if(IM2.constr_idx[i] == IM.constr_idx[j])
                {
                 IM2.constr_idx[i]=IM.constr_idx[IM.m_i[j]];
                 break;                  
                }
              }
            }
          }
        }
      }
     else //d.h. tausche Spalten
      {
       for(i=1;i<=IM.n;i++)
	{
         for(j=1;j<=IM.ab;j++)
           hilf_mat[j][IM.constr_idx[IM.m_i[i]]] =
             mat[j][IM.constr_idx[i]];
         for(j=imp_str[l].GetNr(1).first_col_nr+imp_str[l].GetNr(1).l_dim+
               imp_str[l].GetNr(1).r_dim;j<=dim;j++)
           hilf_mat[IM.constr_idx[IM.m_i[i]]][j]=  
             mat[IM.constr_idx[i]][j];  
	}
       for(i=1;i<=IM.n;i++)
	{
         for(j=1;j<=IM.ab;j++)
          mat[j][IM.constr_idx[i]]=hilf_mat[j][IM.constr_idx[i]];
         for(j=imp_str[l].GetNr(1).first_col_nr+imp_str[l].GetNr(1).l_dim+
               imp_str[l].GetNr(1).r_dim;j<=dim;j++)
          mat[IM.constr_idx[i]][j]=hilf_mat[IM.constr_idx[i]][j];
	}
       //Spalten in mat sind vertauscht
       //constr_idx der folgenden structs muss angepasst werden
       for(io=l;io<=imp_str.Used();io++)
        {
         if(io==l)jo=m+1;
         else jo=1;
         for(lo=jo;lo<=imp_str[io].Used();lo++)
          {
           impl& IM2 = imp_str[io].GetNr(lo);
           for(i=1;i<=IM2.n;i++)
            {
             for(j=1;j<=IM.n;j++)
              {
               if(IM2.constr_idx[i] == IM.constr_idx[j])
                {
                 IM2.constr_idx[i]=IM.constr_idx[IM.m_i[j]];
                 break;                  
                }
              }
            }
          }
        }
      }   
    }
  }   


 //jetzt die Loesung in constr speichern

 constr.IsSplit()=1;
 constr.GetNBList().Used() = dim;
 constr.GetNBWert().Used() = dim;
 for(i=1;i<=dim;i++)
  {
   constr.GetNBList()[i].Used()=0;
   constr.GetNBWert()[i].Used()=0;
  } 
 for(i=1;i<=dim;i++)
  {
   for(j=i+1;j<=dim;j++)
    {
     if(mat[i][j] > 0)
      {
       constr.GetNBList()[i][++constr.GetNBList()[i].Used()]=j;
       constr.GetNBWert()[i][++constr.GetNBWert()[i].Used()]=mat[i][j];
      } 
    }  
  }

 #ifdef DEBUG_TG
 //pruefen, ob die Gradpartition von constr mit der von 
 //erg uebereinstimmt

 VEKTOR < short >  part1,part2;
 VEKTOR < short >  q1,q2;

 q1.ReAlloc(dim);
 q2.ReAlloc(dim);
 q1.Clear();
 q2.Clear();
 for(i=1;i<=dim;i++)
  {
   for(j=1;j<=erg.GetNBList()[i].Used();j++)
    {
     q1[i] += erg.GetNBWert()[i][j];
     q1[erg.GetNBList()[i][j]] += erg.GetNBWert()[i][j];
    }
   for(j=1;j<=constr.GetNBList()[i].Used();j++)
    {
     q2[i] += constr.GetNBWert()[i][j];
     q2[constr.GetNBList()[i][j]] += constr.GetNBWert()[i][j];
    }
  }
 part1.ReAlloc(dim);
 part2.ReAlloc(dim);
 part1.Clear();
 part2.Clear();
 part1.SetAb0();
 part2.SetAb0();
 for(i=1;i<=dim;i++)
  {
   part1[q1[i]]++;
   part2[q2[i]]++;
  }
 for(i=1;i<=dim;i++)
  if(part1[i] != part2[i])
   {
    fprintf(stderr,"different degree partitions in IMPL_DATA::CompRep\n");
    fprintf(stderr,"part1=\n");
    part1.Print(stderr,0);
    fprintf(stderr,"part2=\n");
    part2.Print(stderr,0);
    exit(0);
   }

 #endif

 //SPLIT-TREE uebertragen.
 constr.GetSplitTree()=erg.GetSplitTree();
 constr.IsSplit()=1;
}




void IMPL_DATA::Del(int f_c_nr,int l_dim)
{
 int i;

 if((i=imp_str.Used()) > 0)
  {
   if((imp_str[i].GetFirst().first_col_nr==f_c_nr)&&
      (imp_str[i].GetFirst().l_dim==l_dim))
    {
     imp_str.Used()--; 
    }
  }
}



//Von Gradpart aus muss diese Funktion gerufen
//werden, um fuer die jeweilige Stufe zu initialisieren.

void IMPL_DATA::Init(int f_c_nr,int l_dim)
{
 int i,j;

// printf("Hier IMPL_DATA::Init(%d,%d)\n",f_c_nr,l_dim);

 if(imp_str.Used()==0)
  imp_str.Used()++;
 else
  { 
   if(imp_str[imp_str.Used()].Used() > 0)
    imp_str.Used()++;
  }  

 act_idx=imp_str.Used(); 
 imp_str.ReAlloc(imp_str.Used());
 if(! imp_str.IsAlloc(imp_str.Used()))
  imp_str.Add(imp_str.Used(),1);
 if(imp_str[imp_str.Used()].Anz() == 0)
  { 
   impl* a_impl=new impl;
   if(a_impl==NULL)
    {
     fprintf(stderr,"no memory in IMPL_DATA::Init\n");
     exit(0);
    }
   imp_str[act_idx].Insert((*a_impl),1);
   delete a_impl;
  } 
 imp_str[act_idx].Used()=0;
 imp_str[act_idx].GetFirst().first_col_nr = f_c_nr;
 imp_str[act_idx].GetFirst().l_dim = l_dim;

}



ARRAY < VEKTOR < short > >& IMPL_DATA::GetNBList()
{
 return(erg.GetNBList());
}


ARRAY < VEKTOR < short > >& IMPL_DATA::GetNBWert()
{
 return(erg.GetNBWert());
}


ARRAY < VEKTOR < short > >& IMPL_DATA::GetNewNBList()
{
 return(constr.GetNBList());
}

ARRAY < VEKTOR < short > >& IMPL_DATA::GetNewNBWert()
{
 return(constr.GetNBWert());
}



void IMPL_DATA::Set_n(int _n)
{
 imp_str[act_idx].Used()++;
 if(imp_str[act_idx].Used() > imp_str[act_idx].Anz())
  {
   impl* a_impl2=new impl;
   if(a_impl2==NULL)
    {
     fprintf(stderr,"no memory in IMPL_DATA::Init\n");
     exit(0);
    }
   imp_str[act_idx].InsertEnd((*a_impl2),1);
   delete a_impl2;
  }
 impl& a_impl3 = imp_str[act_idx].GetNr(imp_str[act_idx].Used());
 a_impl3.n = _n;
 a_impl3.idx.ReAlloc(_n);
 a_impl3.constr_idx.ReAlloc(_n);
 a_impl3.m_i.ReAlloc(_n);
}




void IMPL_DATA::Set_k(int _k)
{
 impl& a_impl4 = imp_str[act_idx].GetNr(imp_str[act_idx].Used());
 a_impl4.k = _k;
 a_impl4.n_i.ReAlloc(_k);
}


void IMPL_DATA::Set_n_i(int idx,int wert)
{
 impl& a_impl5 = imp_str[act_idx].GetNr(imp_str[act_idx].Used());
 #ifdef DEBUG_TG
  if((idx < 0)||(idx > a_impl5.k))
   {
    fprintf(stderr,"wrong idx in IMPL_DATA::Set_n_i\n");
    exit(0);
   } 
  if(wert > a_impl5.n)
   {
    fprintf(stderr,"wrong wert in IMPL_DATA::Set_n_i\n");
    exit(0);
   }
 #endif

 a_impl5.n_i[idx]=wert;
}



void IMPL_DATA::Set_ch_rows(char w)
{
 impl& a_impl6 = imp_str[act_idx].GetNr(imp_str[act_idx].Used());
 a_impl6.change_rows = w;
}



void IMPL_DATA::Setr_dim(int _r_dim)
{
 impl& a_impl17 = imp_str[act_idx].GetNr(imp_str[act_idx].Used());
 a_impl17.r_dim = _r_dim;
}


void IMPL_DATA::Set_ab(int _ab)
{
 impl& a_impl7 = imp_str[act_idx].GetNr(imp_str[act_idx].Used());
 a_impl7.ab = _ab;
}


void IMPL_DATA::Set_idx(int nr,int wert)
{
 impl& a_impl8 = imp_str[act_idx].GetNr(imp_str[act_idx].Used());
 #ifdef DEBUG_TG
  if((nr < 0)||(nr > a_impl8.n))
   {
    fprintf(stderr,"wrong nr in IMPL_DATA::Set_idx\n");
    exit(0);
   }
  if((wert < 0)||(wert > dim))
   {
    fprintf(stderr,"wrong wert in IMPL_DATA::Set_idx\n");
    exit(0);  
   }
 #endif

 a_impl8.idx[nr]=wert;
}


void IMPL_DATA::ComputeNewFak(int a,int b)
{
 int i,j;

 impl& a_impl9 = imp_str[a].GetNr(b);
 a_impl9.fak=1;
 for(i=2;i<=a_impl9.n;i++)
  a_impl9.fak *= i;
 for(i=1;i<=a_impl9.k;i++)
  {
   for(j=2;j<=a_impl9.n_i[i];j++)
    a_impl9.fak /= j;
  }  
}



void IMPL_DATA::ComputeFak()
{
 int i,k;

 COMP=1;
 for(i=1;i<=imp_str.Used();i++)
  {
   for(k=1;k<=imp_str[i].Used();k++)
    {
     impl& a_impl9 = imp_str[i].GetNr(k);
     ComputeNewFak(i,k);
     COMP*=a_impl9.fak; 
    }   
  }  
}


LANGZAHL& IMPL_DATA::GetFak()
{
 return(COMP);
}



//prints imp_str[nr] to stdout
void IMPL_DATA::Print(FILE *fp,int nr)
{
 int i,j;

 fprintf(fp,"%d structs on step %d\n",imp_str[nr].Used(),nr);
 fprintf(fp,"first_col_nr=%d   l_dim=%d   r_dim=%d\n",
          imp_str[nr].GetNr(1).first_col_nr,
          imp_str[nr].GetNr(1).l_dim,
          imp_str[nr].GetNr(1).r_dim);

 for(i=1;i<=imp_str[nr].Used();i++)
  {
   impl& a_impl11 = imp_str[nr].GetNr(i);
   fprintf(fp,"  struct Nr.%d\n",i);

   fprintf(fp,"    n=%d  k=%d\n",a_impl11.n,a_impl11.k);
   fprintf(fp,"    n_i=\n");    
   fprintf(fp,"    ");    
   for(j=1;j<=a_impl11.k;j++)
    fprintf(fp,"%d ",a_impl11.n_i[j]);
   fprintf(fp,"\n");
   if(a_impl11.change_rows == 1)
    fprintf(fp,"    change rows\n");
   else 
    fprintf(fp,"    change columns\n");
   if(a_impl11.change_rows == 1)
    fprintf(fp,"    row-numbers:\n");
   else
    fprintf(fp,"    column-numbers\n");
   fprintf(fp,"    ");
   for(j=1;j<=a_impl11.n;j++)
    fprintf(fp,"%d ",a_impl11.idx[j]);
   fprintf(fp,"\n");
   fprintf(fp,"    ab=%d\n",a_impl11.ab);   
   fprintf(fp,"    factor=\n");
   a_impl11.fak.Print(fp,4);
   fprintf(fp,"\n");
  }
}


//prints imp_str to stdout
void IMPL_DATA::Print(FILE *fp)
{
 int i,k;

 fprintf(fp,"dim=%d\n",dim);
 fprintf(fp,"NBList=\n");
 for(i=1;i<=erg.GetNBList().Used();i++)
  {
   fprintf(fp,"ARRAY Nr.%d\n",i);
   fprintf(fp,"   ");
   for(k=1;k<=erg.GetNBList()[i].Used();k++)
    {
     fprintf(fp,"%d %d  ",erg.GetNBList()[i][k],
                          erg.GetNBWert()[i][k]);
    }
   fprintf(fp,"\n"); 
  }
 if(imp_str.Used() > 0)
  {
   if(imp_str[imp_str.Used()].Used() == 0)
    k=imp_str.Used()-1;
   else
    k=imp_str.Used(); 
  }
 else
  k=0;  
 fprintf(fp,"%d steps\n",k);
 for(i=1;i<=k;i++)
   Print(fp,i);
 if(erg.IsSplit())
   erg.PrintSplitTree(fp);
}


static void ERR(int flag)
{
 fprintf(stderr,"%d : wrong file-format in IMPL_DATA::ReadInput\n",flag);
 exit(0);
}


static int ReadNextLine(char* z,FILE* fp)
{
 if(fgets(z,100,fp) == NULL)
  return(0);
 return(1); 
}


void IMPL_DATA::ReadInput(FILE *fp)
{
 int i,j,k,l,m,n,o,p,ret,__r_dim;
 char  zeile[100];
 char  *hilf;

 PROD=1;
 ReadNextLine(zeile,fp);
 ret=sscanf(zeile,"dim=%d",&i);
 if(ret != 1) ERR(1);
 Init(i);
 erg.ReadNBList(fp);
 ReadNextLine(zeile,fp);
 ret=sscanf(zeile,"%d steps\n",&i);
 if(ret != 1) ERR(2);
 p=i;
 for(i=1;i<=p;i++)
  {
   ReadNextLine(zeile,fp);
   ret=sscanf(zeile,"%d structs on step %d\n",&k,&j);
   if(ret != 2) ERR(3);
   ReadNextLine(zeile,fp);
   ret=sscanf(zeile,"first_col_nr=%d  l_dim=%d   r_dim=%d\n",&l,&m,&__r_dim);
   if(ret != 3) ERR(4);
   Init(l,m);
   for(j=1;j<=k;j++)
    {
     ReadNextLine(zeile,fp);
     ret=sscanf(zeile,"  struct Nr.%d\n",&l);
     if(ret != 1) ERR(5);  
     ReadNextLine(zeile,fp);
     ret=sscanf(zeile,"   n=%d  k=%d\n",&l,&m);
     if(ret != 2) ERR(6);  
     Set_n(l);
     Set_k(m);
     ReadNextLine(zeile,fp);
     ReadNextLine(zeile,fp);
     n=0;
     hilf=zeile;
     while(1) 
      {
       while(isspace(hilf[0]))
        hilf++;
       ret=sscanf(hilf,"%d",&o);
       if(ret != 1)break;
       Set_n_i(++n,o);
       while(isdigit(hilf[0]))
        hilf++; 
      }         
     ReadNextLine(zeile,fp);
     if(strcmp("    change rows\n",zeile) == 0)
      Set_ch_rows(1);
     else 
      Set_ch_rows(0);
     ReadNextLine(zeile,fp);
     ReadNextLine(zeile,fp);
     n=0;
     hilf=zeile;
     while(1) 
      {
       while(isspace(hilf[0]))
        hilf++;
       ret=sscanf(hilf,"%d",&o);
       if(ret != 1)break;
       Set_idx(++n,o);
       while(isdigit(hilf[0]))
        hilf++; 
      }
     ReadNextLine(zeile,fp);
     ret=sscanf(zeile,"   ab=%d\n",&o);
     if(ret != 1) ERR(7);
     Set_ab(o);
     Setr_dim(__r_dim);
     ReadNextLine(zeile,fp);
     ReadNextLine(zeile,fp);
     ComputeNewFak(act_idx,imp_str[act_idx].Used());
     PROD*=imp_str[act_idx].GetNr(imp_str[act_idx].Used()).fak; 
    }   
  }
 while(1) 
  {
   if(ReadNextLine(zeile,fp) == 0)
    {
     erg.Init(0,0);
     return;
    }
   else
    {
     if(strcmp(zeile,"SPLIT_TREE=\n") == 0)
      break;
    }  
  } 
 erg.ScanSplitTree(fp);
}


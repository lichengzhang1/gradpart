#include "koord.h"
#include "defs.h"


ORD_KOORD::ORD_KOORD() : KOORD_BASE()
{
 return; 
}


ORD_KOORD::~ORD_KOORD()
{
 return;
}


void ORD_KOORD::Del(int z,int sp)
{
 for(int i=0;i<restr_func_anz;i++)
  (*RestrDel)(z,sp);
}


int ORD_KOORD::Set(int z,int sp,int wert)
{
 for(int i=0;i<restr_func_anz;i++)
  if( (*RestrSet)(z,sp,wert) == 0)
   return(0);
 return(1);
}


void ORD_KOORD::SetRestr(RS set,RD del)
{
 if(restr_func_anz == MAX_RESTR_FUNC)
  {
   printf("Can't set another restriction !\n");
   exit(0);
  }
 RestrSet[restr_func_anz] = set;
 RestrDel[restr_func_anz] = del;
 restr_func_anz++;
}


void ORD_KOORD::BerechneAufteilung()
{

 //first fill orbits

 int i,j,delta,anf,end,m;
 BITVEK             bits((Sp > Zei) ? Sp : Zei);
 BITVEK             dummy((Sp > Zei) ? Sp : Zei);
 VEKTOR < short >   merke((Sp > Zei) ? Sp : Zei);

 if(! GROUP_IS_ID)
  {
   z_orbits.Used()=0;
   bits.Clear();
   for(i=1;i <= Zei;i++)
    {
     if(bits[i] == 0)
      {
       dummy.Clear();
       dummy.Set(i);
       merke[1]=i;
       anf=1;end=1;
       m=1;
       while(anf <= end)
        {
         G.StabErz_start(0);
         while(! G.IsLastStabErz())
          { 
           PERMUT<short>& perm=G.StabErz(0);
           delta=perm[merke[anf]];
           if(dummy[delta] == 0)
            {
             m++;
             dummy.Set(delta);
             merke[++end]=delta;
            }
          }
         anf++;
        }
       bits |= dummy;
       z_orbits.Used()++;
       z_orbits.ReAlloc(z_orbits.Used());
       if(! z_orbits.IsAlloc(z_orbits.Used()))
        z_orbits.Add(z_orbits.Used(),m);
       z_orbits[z_orbits.Used()].ReAlloc(m);
       z_orbits[z_orbits.Used()].Used()=m;
       m=0;
       for(j=1;j<=Zei;j++)
        {
         if(dummy[j] == 1)
          z_orbits[z_orbits.Used()][++m]=j;
        }  
      }
    }
  }
 else
  {
   z_orbits.Used()=Zei;
   z_orbits.ReAlloc(Zei);
   for(i=1;i<=Zei;i++)
    {
     if(! z_orbits.IsAlloc(i))
      z_orbits.Add(i,1);
     z_orbits[i].Used()=1;
     z_orbits[i][1]=i;
    }
  }


 //now z_orbits is filled

 if(! GROUP_IS_ID)
  {
   sp_orbits.Used()=0;
   bits.Clear();
   for(i=1;i <= Sp;i++)
    {
     if(bits[i] == 0)
      {
       dummy.Clear();
       dummy.Set(i);
       merke[1]=i;
       anf=1;end=1;
       m=1;
       while(anf <= end)
        {
         G.StabErz_start(0);
         while(! G.IsLastStabErz())
          { 
           PERMUT<short>& perm=G.StabErz(0);
           delta=perm[Zei+merke[anf]]-Zei;
           if(dummy[delta] == 0)
            {
             m++;
             dummy.Set(delta);
             merke[++end]=delta;
            }
          }
         anf++;
        }
       bits |= dummy;
       sp_orbits.Used()++;
       sp_orbits.ReAlloc(sp_orbits.Used());
       if(! sp_orbits.IsAlloc(sp_orbits.Used()))
        sp_orbits.Add(sp_orbits.Used(),m);
       sp_orbits[sp_orbits.Used()].ReAlloc(m);
       sp_orbits[sp_orbits.Used()].Used()=m;
       m=0;
       for(j=1;j<=Sp;j++)
        {
         if(dummy[j] == 1)
          sp_orbits[sp_orbits.Used()][++m]=j;
        }  
      }
    }
  }
 else
  {
   sp_orbits.Used()=Sp;
   sp_orbits.ReAlloc(Sp);
   for(i=1;i<=Sp;i++)
    {
     if(! sp_orbits.IsAlloc(i))
      sp_orbits.Add(i,1);
     sp_orbits[i].Used()=1;
     sp_orbits[i][1]=i;
    }
  }


 //sp_orbits is filled


 //now ZeilenZerlegung and SpaltenZerlegung have to be filled
 //using a heuristic algorithm

 if(Sp*Zei > GALE_LIMIT)
  {
   //in this case the matrix is filled in rowwise stripes
   //and the Gale-Ryser-Test is used to determine, if
   //the partially filled matrix can be completed.
   SUCHE_ORD_GROESSE=3;
   ABWEICHUNG=1;
  }
 else
  {
   if(UNTERTEILE)
    {
     SUCHE_ORD_GROESSE=6;
     ABWEICHUNG=1;
    }
   else
    {
     SUCHE_ORD_GROESSE=1000;
     ABWEICHUNG=1;
    }    
  }

 
 ZeilenZerlegung.Used()=0;
 bits.Clear();
 anf=1;
 while(anf <= z_orbits.Used())
  {
   if(bits[anf] == 0)
    {
     ZeilenZerlegung.Used()++;
     j=ZeilenZerlegung.Used();
     ZeilenZerlegung.ReAlloc(j);
     if(! ZeilenZerlegung.IsAlloc(j))
      ZeilenZerlegung.Add(j,SUCHE_ORD_GROESSE+ABWEICHUNG);
     ZeilenZerlegung[j].ReAlloc(z_orbits[anf].Used());
     for(i=1;i<=z_orbits[anf].Used();i++)
      ZeilenZerlegung[j][i]=z_orbits[anf][i];
     ZeilenZerlegung[j].Used()=z_orbits[anf].Used();
     for(i=anf+1;i<=z_orbits.Used();i++)
      {
       if((SUCHE_ORD_GROESSE-ABWEICHUNG <= ZeilenZerlegung[j].Used())&&
          (SUCHE_ORD_GROESSE+ABWEICHUNG >= ZeilenZerlegung[j].Used()))
        break;
       if(bits[i] == 0)
        {
         if(ZeilenZerlegung[j].Used()+z_orbits[i].Used() <=
            SUCHE_ORD_GROESSE+ABWEICHUNG)
          {
           for(m=1;m<=z_orbits[i].Used();m++)
            ZeilenZerlegung[j][ZeilenZerlegung[j].Used()+m]=z_orbits[i][m];
           ZeilenZerlegung[j].Used()+=z_orbits[i].Used();             
           bits.Set(i);
          }     
        }
      }     
     bits.Set(anf);
    }
   anf++;
  }

if(0)
 {
  printf("ZeilenZerlegung=\n");
  for(i=1;i<=ZeilenZerlegung.Used();i++)
   ZeilenZerlegung[i].PrintUsed(0);
  fflush(stdout);
 }

 if(UNTERTEILE)
  {
   SUCHE_ORD_GROESSE=6;
   ABWEICHUNG=1;

   SpaltenZerlegung.Used()=0;
   bits.Clear();
   anf=1;
   while(anf <= sp_orbits.Used())
    {
     if(bits[anf] == 0)
      {
       SpaltenZerlegung.Used()++;
       j=SpaltenZerlegung.Used();
       SpaltenZerlegung.ReAlloc(j);
       if(! SpaltenZerlegung.IsAlloc(j))
        SpaltenZerlegung.Add(j,SUCHE_ORD_GROESSE+ABWEICHUNG);
       SpaltenZerlegung[j].ReAlloc(sp_orbits[anf].Used());
       for(i=1;i<=sp_orbits[anf].Used();i++)
        SpaltenZerlegung[j][i]=sp_orbits[anf][i];
       SpaltenZerlegung[j].Used()=sp_orbits[anf].Used();
       for(i=anf+1;i<=sp_orbits.Used();i++)
        {
         if((SUCHE_ORD_GROESSE-ABWEICHUNG <= SpaltenZerlegung[j].Used())&&
            (SUCHE_ORD_GROESSE+ABWEICHUNG >= SpaltenZerlegung[j].Used()))
          break;
         if(bits[i] == 0)
          {
           if(SpaltenZerlegung[j].Used()+sp_orbits[i].Used() <=
              SUCHE_ORD_GROESSE+ABWEICHUNG)
            {
             for(m=1;m<=sp_orbits[i].Used();m++)
              SpaltenZerlegung[j][SpaltenZerlegung[j].Used()+m]=sp_orbits[i][m];
             SpaltenZerlegung[j].Used()+=sp_orbits[i].Used();             
             bits.Set(i);
            }     
          }
        }     
       bits.Set(anf);
      }
     anf++;
    }
  }
 else
  {
   //Identitaet
   SpaltenZerlegung.Used()=1;
   j=SpaltenZerlegung.Used();
   SpaltenZerlegung.ReAlloc(j);
   if(! SpaltenZerlegung.IsAlloc(j))
    SpaltenZerlegung.Add(j,Sp);
   SpaltenZerlegung[j].ReAlloc(Sp);
   for(i=1;i<=Sp;i++)
     SpaltenZerlegung[j][i]=i;
   SpaltenZerlegung[j].Used()=Sp;
  }

if(0)
 {
  printf("SpaltenZerlegung=\n");
  for(i=1;i<=SpaltenZerlegung.Used();i++)
   SpaltenZerlegung[i].PrintUsed(0);
  fflush(stdout);
 }

 schritte=SpaltenZerlegung.Used()*ZeilenZerlegung.Used();
 
if(0)
 {
  printf("schritte=%d\n",schritte);
  fflush(stdout);
 }

 ConnWert.REALLOC(Zei,Sp);
 ConnList.REALLOC(Zei,Sp);
 for(i=1;i<=Zei;i++)
  ConnList[i].Used()=0;
 ConnUsed.REALLOC(schritte,Zei);
 for(i=1;i<=Zei;i++)
  ConnUsed[1][i]=0;

 reihenf_zeile.ReAlloc(schritte);
 reihenf_spalte.ReAlloc(schritte);

 if(Sp*Zei > GALE_LIMIT)
  {
   //rowwise order
   BITVEK b(ZeilenZerlegung.Used());
   b.Clear();
   for(i=1;i<=schritte;i++)
     reihenf_spalte[i]=((i-1)%SpaltenZerlegung.Used())+1;
   int io,jo,lo;
   lo=0;
   for(i=1;i<=ZeilenZerlegung.Used();i++)
    {
     j=1;
     while(b[j] == 1)j++;
     jo=j;
     for(io=j+1;io<=ZeilenZerlegung.Used();io++)
      if((b[io] == 0)&&
         (ZeilenZerlegung[io].Used() < ZeilenZerlegung[jo].Used()))
        jo=io;
     b.Set(jo);
     for(j=1;j<=SpaltenZerlegung.Used();j++)
      reihenf_zeile[++lo]=jo;
    }
  }
 else
  {
   //ascending number of places of the partial matrices
   BITVEK  b(schritte);   
   b.Clear();
   VEKTOR < short > platz_anz(schritte);
   m=0;
   for(i=1;i<=ZeilenZerlegung.Used();i++)
    {
     for(j=1;j<=SpaltenZerlegung.Used();j++)
      {
       platz_anz[++m]=
        ZeilenZerlegung[i].Used()*SpaltenZerlegung[j].Used();
      }
    }
   platz_anz.Used()=schritte;
   platz_anz.Sort();

  if(0)
   {
    printf("platz_anz aufsteigend=\n");
    platz_anz.Print(0);
    fflush(stdout);
   }

   for(i=1;i<=schritte;i++)
    {
     j=1; //Zeilenindex
     m=1; //Spaltenindex
     while((b[(j-1)*SpaltenZerlegung.Used()+m] == 1) || 
           (ZeilenZerlegung[j].Used()*SpaltenZerlegung[m].Used() != platz_anz[i]))
      {
       if(m < SpaltenZerlegung.Used())
        m++;
       else
        {
         m=1;
         j++;
        } 
      }
     reihenf_zeile[i]=j;
     reihenf_spalte[i]=m;
     b.Set((j-1)*SpaltenZerlegung.Used()+m);
    }
  }

if(0)
 {
  printf("Reihenfolge=\n");
  for(i=1;i<=schritte;i++)
    printf("(%d,%d) ",reihenf_zeile[i],reihenf_spalte[i]);
  printf("\n");
   fflush(stdout);
 }

 is_first.ReAlloc(schritte);
 is_first.Clear();
 ~is_first;

}





LABRA_TG& ORD_KOORD::GetAut()
{
 #ifdef DEBUG_TG
  if(ords[schritte]==NULL)
   {
    FatalMess("error in ORD_KOORD::GetAut\n");
    exit(0);
   } 
 #endif

 return(ords[schritte]->AutGruppe());
}




void ORD_KOORD::NotiereLoesung()
{
 AUT_IS_ID=ords[schritte]->GetAUT_IS_ID();
}



void ORD_KOORD::PrintLoesung()
{
 int i,j,k;
 ARRAY < VEKTOR < short > > M;

 M.REALLOC(Zei,Sp);
 for(i=1;i<=Zei;i++)
  M[i].Clear();
 for(i=1;i<=Zei;i++)
   for(j=1;j<=ConnList[i].Used();j++)
     M[i][ConnList[i][j]] = ConnWert[i][j];  
    
 for(i=1;i<=Zei;i++)
  {
   for(j=1;j<=Sp;j++)
    printf("%d ",M[i][j]);
   printf("\n");
  }
 printf("\n");   
} 



void ORD_KOORD::FREE()
{
 z_orbits.FREE();
 sp_orbits.FREE();
 ZeilenZerlegung.FREE();
 SpaltenZerlegung.FREE();
 reihenf_zeile.FREE();
 reihenf_spalte.FREE();

 KOORD_BASE::FREE();
}



void ORD_KOORD::NotiereTeilLoesung(int index)
{
 int i,j,k,w;

 for(i=1;i<=Zei;i++)
  ConnList[i].Used()=ConnUsed[index][i];

 for(j=1;j<=ords[index]->Zeilen();j++)
  {
   for(k=1;k<=ords[index]->Spalten();k++)
    {
     if( (w=ords[index]->Erg(j,k)) > 0 )
      {
       i=(++ConnList[ords[index]->Zei_Nr()[j]].Used());
       ConnList[ords[index]->Zei_Nr()[j]][i] =
          ords[index]->Sp_Nr()[k]-Zei;
       ConnWert[ords[index]->Zei_Nr()[j]][i] = w;
      }
    }
  }
 
 if(index < schritte)
  {
   for(i=1;i<=Zei;i++)
    ConnUsed[index+1][i]=ConnList[i].Used();
  }
}




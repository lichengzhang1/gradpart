#include <time.h>

clock_t time1;
int VERBOSE; 
int HASH_LENGTH;
int GALE_LIMIT;
int SPLIT_KLEIN;
int SPLIT_MIN;
int SHIFT_PARTITIONS;
int STEPS_TO_SAVE;
int STEPS_SAVED;
int DEBUG_LINE;
char DEBUG_FILE[100];



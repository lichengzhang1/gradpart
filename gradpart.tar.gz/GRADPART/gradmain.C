#include <unistd.h>
#include "gradmain.h"
#include "div.h"


//#define MULTICODE
//#define WRITE_ALL

extern IMPL_DATA a_IMPL;

void GRAD_MAIN::StartConstr(int argc,char* argv[])
{
 int n,i,j,k,ret,bis;
 char zeile[250];

#ifndef MULTICODE
 printf("\n");
#endif

 FILE *pid_f;
 i=getpid();
 pid_f=fopen("HELP_PID","a");
 fprintf(pid_f,"%d\n",i);
 fclose(pid_f);

 LOES = 0; 
 system("rm -f ERG/*");
 ReadParameters(GO_IMPL,S_50_50,S_MIDDLE,S_MAX,PRECOMPUTE_SPLITS,RECONSTRUCT_ALL);
 STEPS_SAVED=0;
 if(argc != 1)
  {
   fprintf(stderr,"wrong number of parameters\n");
   exit(0);
  }


 ret=scanf("CRITICAL_GRAPHS %d\n",&j);
 if(ret==1)
  {
   CRITICAL_GRAD = j;
   ret=scanf("VERT_ANZ %d\n",&j);
   if(ret != 1)
    {
     printf("VERT_ANZ = ?\n");
     exit(0);
    }
   CR_V_ANZ = j;
   ComputeCriticalGraphs(); 
   return;
  }
  
 ret=scanf("TREES_ONLY %d\n",&j);
 if(ret != 1)
  {
   printf("TREES_ONLY = ?\n");
   exit(0);
  }
 TREES_ONLY = j; 
 ret=scanf("GIRTH %d\n",&GIRTH);
 if(ret != 1)
  {
   printf("GIRTH = ?\n");
   exit(0);
  }
 ret=scanf("MAXBOND %d\n",&MAXBOND);
 if(ret != 1)
  {
   printf("MAXBOND = ?\n");
   exit(0);
  }
 if((MAXBOND > 1)&&(TREES_ONLY))
  {
   printf("if TREES_ONLY==1  ==>  MAXBOND==1\n");
   exit(0);
  }
 ret=scanf("CONN %d\n",&CONN_GRAPHS);
 if(ret != 1)
  {
   printf("CONN = ?\n");
   exit(0);
  }
 ret = ReadNextLine(zeile,stdin); 
 if(ret == 0)
  {
   printf("input error !\n");
   exit(0); 
  }

 if(strstr(zeile,"MAXGRAD") != NULL)
  {
   //Gradpartition einlesen
   ret=sscanf(zeile,"MAXGRAD %d\n",&i);
   if(ret != 1)
    {
     printf("MAXGRAD = ?\n");
     exit(0);
    }
   if(i==0)
    {
     printf("maximal degree must be > 0\n");
     exit(0);
    }  
   partition.ReAlloc((i>0)?i:1);
   partition.Used()=i;
   partition.SetAb0();
   for(j=0;j<=i;j++)
    {
     ret=scanf("%d",&k);
     if(ret != 1)
      {
       printf("partition[%d] = ?\n",j);
       exit(0);
      }
     partition[j]=k;
    }

   TestePartition();

   if(((knoten > SPLIT_MIN)&&(! is_regular))||
      ((TREES_ONLY == 1)&&(! is_regular)))
    SpalteAuf();
   else
    ConstrOrdtreu();  

   if(((knoten > SPLIT_MIN)&&(! is_regular))||
      ((TREES_ONLY == 1)&&(! is_regular)))
    {
#ifndef MULTICODE
     fprintf(stdout,"\ntotal number: ");
     PART.GetLOES().Print(stdout,0);
     fprintf(stdout,"\n");
     fflush(stdout);
#endif
    }  
   else
    {
#ifndef MULTICODE
     fprintf(stdout,"\ntotal number: %d\n",anz);
     fflush(stdout);
#endif
    }
   return; 
  } 
      
 if(strstr(zeile,"VERTICES") != NULL)
  {
   if(strstr(zeile,"EDGES") != NULL)
    {
     ret = sscanf(zeile,"VERTICES %d EDGES %d",&knoten,&kanten); 
     if(ret != 2)
      {
       printf("VERTICES/EDGES = ?\n");
       exit(0);
      }
     unlink("AUSGABE");
     if(TREES_ONLY==1)
      {
       if(((CONN_GRAPHS==1)&&(knoten != kanten+1))||
          ((CONN_GRAPHS==0)&&(knoten <= kanten)))
        {
#ifndef MULTICODE
         printf("\nnumber of graphs: 0\n ");
#endif
        }
       else
        Berechne_n_k(knoten,kanten);
      } 
     else 
      Berechne_n_k(knoten,kanten);
#ifndef MULTICODE
     printf("computation completed\n");
     fflush(stdout);
#endif
     return;
    }
   else
    { 
     ret = sscanf(zeile,"VERTICES %d",&knoten); 
     if(ret != 1)
      {
       printf("VERTICES = ?\n");
       exit(0);
      }
     unlink("AUSGABE");
     if((GIRTH==3)&&(CONN_GRAPHS==0)&&(TREES_ONLY==0))
      bis=knoten*(knoten-1)/4 * MAXBOND;
     else
      bis=knoten*(knoten-1)/2 * MAXBOND;
     if(TREES_ONLY==1)
      {
       for(k=0;k<=bis;k++)
        {
         if( !(((CONN_GRAPHS==1)&&(knoten != k+1))||
	       ((CONN_GRAPHS==0)&&(knoten <= k))))
          Berechne_n_k(knoten,k);
        }
      }
     else
      { 
       for(k=0;k<=bis;k++)
        Berechne_n_k(knoten,k);
      }  
#ifndef MULTICODE
     printf("computation completed\n");
     fflush(stdout);
#endif
     return;      
    }
  }
}


void GRAD_MAIN::SaveRep()
{
 int k,l;

#ifdef MULTICODE
char schreib=0;
#ifdef WRITE_ALL
 schreib=1;
#else
 if(STEPS_SAVED < STEPS_TO_SAVE)
  schreib=1; 
#endif
 if(schreib)
  { 
   ARRAY < VEKTOR < short > >* NA;
   if(UsePART == 1)
    NA = &PART.GetNBList();
   else
    NA = &a_graph.GetNBlist();
   ARRAY < VEKTOR < short > >& NA2 = (*NA);
   int KNO = knoten;
   unsigned char code[11000];
   code[0]=KNO;
   l=0;
   for(k=1;k<=NA2[1].Used();k++)
    code[++l] = NA2[1][k];
   int io;
   for(k=2;k<KNO;k++)
    {
     code[++l] = 0;
     for(io=1;io<=NA2[k].Used();io++)
      code[++l] = NA2[k][io];
    }
   code[++l] = 0;
 /*for(io=0;io<=l;io++)
   printf("%d ",code[io]);
   printf("\n\n\n");
 */

   for(k=0;k<=l;k++)
    printf("%c",code[k]);
  }
 fflush(stdout);
 STEPS_SAVED++;
 return;
#endif

 FILE *fp;
 if(STEPS_SAVED < STEPS_TO_SAVE)
  {
   if(UsePART == 1)
    {
     a_IMPL.GetNBList() = PART.GetNBList();
     a_IMPL.GetNBWert() = PART.GetNBWert();
     PART.SaveSplitTree();
     STEPS_SAVED++;
     sprintf(filename,"./ERG/dat%d",STEPS_SAVED);
     fp=fopen(filename,"w");
     a_IMPL.Print(fp);
     fclose(fp);
     A = LOES;
     A +=PART.GetLOES();
     fp=NULL;
     while(fp == NULL)
      fp=fopen("./ERG/ANZAHLEN","a");
     A.Print(fp,0); 
     fprintf(fp,"\n");
     fclose(fp);
     fp=NULL;
     while(fp == NULL)
      fp=fopen("./ERG/GESAMT","w");
     A.Print(fp,0); 
     fprintf(fp,"\n");
     fclose(fp);
    }
   else
    {
     STEPS_SAVED++;
     sprintf(filename,"./ERG/dat%d",STEPS_SAVED);
     fp=fopen(filename,"w");
     fprintf(fp,"dim=%d\n",knoten);
     fprintf(fp,"NBList=\n");
     for(k=1;k<=a_graph.GetNBlist().Used();k++)
      {
       fprintf(fp,"ARRAY Nr.%d\n",k);
       fprintf(fp,"   ");
       for(l=1;l<=a_graph.GetNBlist()[k].Used();l++)
        fprintf(fp,"%d %d  ",a_graph.GetNBlist()[k][l],
			     a_graph.GetNBwert()[k][l]);   
       fprintf(fp,"\n");
      }
     fprintf(fp,"0 steps\n");
     fclose(fp);
     fp=NULL;
     while(fp == NULL)
      fp=fopen("./ERG/ANZAHLEN","a");
     fprintf(fp,"%d\n",STEPS_SAVED);
     fclose(fp);
     fp=NULL;
     while(fp == NULL)
      fp=fopen("./ERG/GESAMT","w");
     fprintf(fp,"%d\n",STEPS_SAVED);
     fclose(fp);
    }      
  }
}



void GRAD_MAIN::ComputeCriticalGraphs()
{
 int i,j,k,anz,ges,class2,critical;
 int kant_max;
 int DELTA = CRITICAL_GRAD; 
 COLOR_EDGES a_col_edge;
 CRITICAL_TEST a_cri_test;

 UsePART = 1;
 kant_max = ((CR_V_ANZ-2)*DELTA)/2 + (DELTA-1) - 1;
 //siehe UB
 partition.ReAlloc(CR_V_ANZ);

 printf("kant_max=%d\n",kant_max);
 ges = 0;
 class2=0;
 critical = 0;
 for(i=1;i<=kant_max;i++)
  {
   printf("\n%d Kanten:",i);
   a_schl.Init(CR_V_ANZ,i,1L,CRITICAL_GRAD);
   while(a_schl.NextRep())
    {
     j = CR_V_ANZ-1;
     while(a_schl.GetVertAnz(j) == 0)
      j--;
     for(k=0;k<=j;k++)
      partition[k] = a_schl.GetVertAnz(k);
     partition.Used() = j; 
     if(MaybeCriticalPartition())
      {
       printf("\nPOSSIBLE PARTITION:");
       partition.PrintUsed(0);
       anz = 0;
       PART.GetPart().ReAlloc(i);
       PART.GetPart().SetAb0();
       PART.GetTIEFE()=1;
       PART.GetMAXVAL() = 1;
       PART.GetGO_IMPL()=0;
       PART.GetCONN() = 1;
       PART.GetIMP_IF_CONN() = 0;
       PART.GetGIRTH() = 3;
       PART.GetGIRTH_AND_IMPL() = 0;
       PART.GetFIRST_COL_NR()=1; 
       PART.GetTREES_ONLY() = 0;
       PART.GetPart().Used()=partition.Used(); 
       for(j=0;j<=partition.Used();j++)
        PART.GetPart()[j]=a_schl.GetVertAnz(j);
       PART.EnableSPLIT_MAX();
       PART.SetCRITICAL(CRITICAL_GRAD);
       PART.Init();   
       while(PART.NextRep())
        {
         anz++;ges++;
         int chr_ind;
         chr_ind = a_col_edge.ChromaticIndex(PART.GetNBList());
         if(chr_ind == CRITICAL_GRAD+1)
          {
           class2++;
           if(a_cri_test.IsCritical(PART.GetNBList()))
            {
             critical++;
             SaveRep();
            } 
          } 
         printf("\rges=%d anz=%d class2=%d critical=%d",ges,anz,class2,critical);
         fflush(stdout); 
        }
      }
    }
  }
}


int GRAD_MAIN::MaybeCriticalPartition()
{
 int i,j,k;

 if(partition.Used() != CRITICAL_GRAD)
  return(0);
 if((partition[0] > 0)||(partition[1] > 0))
  return(0);
 
 //Knoten vom Grad 2 muessen mit maximalen Knoten verbunden sein
 i = 2 * partition[2];
 if(partition[CRITICAL_GRAD] < i)
  return(0);

 if( partition[2] )
  {
   if( partition[CRITICAL_GRAD] < CRITICAL_GRAD)
    return(0);
  }	
 
 if(CRITICAL_GRAD > 3)
  {
   i = 3 * partition[3];
   //Knoten vomn Grad 3 muessen mit Knoten vom Grad CRITICAL_GRAD oder
   //CRITICAL_GRAD-1 verbunden sein
   if(partition[CRITICAL_GRAD] + partition[CRITICAL_GRAD-1] < i)
    return(0);
  }

 if(CRITICAL_GRAD > 4)
  {
   i = 4*partition[4];
   if(partition[CRITICAL_GRAD] + 
      partition[CRITICAL_GRAD-1] +
      partition[CRITICAL_GRAD-2] < i)
    return(0);
  }

 int ecken = 0;
 for(i=2;i<=CRITICAL_GRAD;i++)
  ecken += partition[i] * i;
 ecken /= 2;

 int knoten = 0;
 for(i=2;i<=CRITICAL_GRAD;i++)
  knoten += partition[i];

 int mingrad = 2;
 while(partition[mingrad]==0)
  mingrad++;

 if(ecken > ((knoten-2)*CRITICAL_GRAD)/2 - 1 + mingrad )
  return(0);


 return(1);
}





void GRAD_MAIN::Berechne_n_k(int n,int k)
{
 FILE *fp;
 int i,j,o,p,kn,ka;
 int anz=0;

 Sum=0;

 PrintPartitions = 0;  
#ifndef MULTICODE
 printf("(%d,%d)\n",n,k);  
 fflush(stdout);
#endif  

 PART.FREE();
 a_schl.Init(n,k,MAXBOND);

 /******************************/
// a_schl.SetDeg_gr_0();
 /* falls keine Knoten vom Grad 0 erlaubt sind. */
 /******************************/

 a_graph.ResetTicks();

 NEXT_PART:
 while(a_schl.NextRep())
  {
   if(TREES_ONLY==1)
    {
     if(((CONN_GRAPHS==1)&&((n != k+1)||(a_schl.GetVertAnz(0L) > 0L)))||
	((CONN_GRAPHS==0)&&(n-a_schl.GetVertAnz(0L) <= k)&&(k > 0)) )
      goto NEXT_PART; 
    }

   i = (n-1)*MAXBOND;
   while(a_schl.GetVertAnz(i) == 0)
    i--;

#ifndef MULTICODE
   if(PrintPartitions)
    {
     for(j=0;j<=i;j++)
      printf("%d ",a_schl.GetVertAnz(j));
     printf(" :\n");
     fflush(stdout);
    }
#endif

   is_regular=1;
   for(o=0;o < i;o++)
    if(a_schl.GetVertAnz(o) != 0)
     is_regular=0;

   if(((knoten > SPLIT_MIN)&&(! is_regular))||
      ((TREES_ONLY == 1)&&(! is_regular)))
    {
     a_IMPL.Init(n);
     UsePART = 1;
     PART.GetPart().ReAlloc(i);
     PART.GetPart().SetAb0();
     PART.GetTIEFE()=1;
     PART.GetMAXVAL() = MAXBOND;
     PART.GetGO_IMPL()=GO_IMPL;
     PART.GetCONN() = CONN_GRAPHS;
     PART.GetIMP_IF_CONN() = 0;
     PART.GetGIRTH() = GIRTH;
     PART.GetGIRTH_AND_IMPL() = 1;
     PART.GetFIRST_COL_NR()=1; 
     PART.GetPart().Used()=i; 
     PART.GetTREES_ONLY() = TREES_ONLY;
     for(j=0;j<=i;j++)
      PART.GetPart()[j]=a_schl.GetVertAnz(j);
     if(S_MAX == 1) 
      PART.EnableSPLIT_MAX();
     if(S_MIDDLE == 1) 
      PART.EnableSPLIT_MIDDLE();
     if(S_50_50 == 1) 
      PART.EnableSPLIT_50_50();
     PART.Init();     
     while(PART.NextRep())
      {
       anz++;
       if((GO_IMPL)&&(RECONSTRUCT_ALL))
        {
         a_IMPL.GetNBList()=PART.GetNBList();
         a_IMPL.ConstrStart();
         while(a_IMPL.ConstructNextSolution())
          {
           ARRAY < VEKTOR < short > >&  nbliste = a_IMPL.GetNewNBList();
           //do something with neighbourhood-list nbliste
          }  
        }
       SaveRep(); 
      }
     Sum+=PART.GetLOES();
     LOES += PART.GetLOES();
#ifndef MULTICODE
     if(PrintPartitions)
      {
       Sum.Print(stdout,0);
       printf("\n");
      } 
     else 
      {
       printf("\r");
       Sum.Print(stdout,0);
      } 
     fflush(stdout);
#endif
    }
   else
    {
     UsePART = 0;
     a_graph.GetDim()=n;
     a_graph.GetENABLE_AUT()=1;
     a_graph.GetMAXGRAD()=i;
     a_graph.GetMAXVAL()=MAXBOND;
     a_graph.GetPARTITION().ReAlloc((i > 1)?i:1);
     for(j=1;j<=i;j++)
      a_graph.GetPARTITION()[j]=a_schl.GetVertAnz(j);
     a_graph.GetZSHG()=CONN_GRAPHS;
     if(TREES_ONLY)
      a_graph.GetGirth()=n+1;
     else
      a_graph.GetGirth()=GIRTH;
     a_graph.Init();

     while(a_graph.NextRep())
      {
       anz++;
       SaveRep();
#ifndef MULTICODE
       if(PrintPartitions == 0)
        {
         if((anz < 100)||(anz % 50 == 0))
          {
           fprintf(stdout,"\r%d",anz);
           fflush(stdout);
          }
        }
#endif
      }
     LOES += anz;
#ifndef MULTICODE 
     if(PrintPartitions)
       printf("%d\n",anz);
#endif
    } 
  }

#ifndef MULTICODE
 if(UsePART == 0)
   printf("\n%d Loesungen\n\n",anz);
 else
  {
   printf("\n");
   Sum.Print(stdout,0);
   printf(" Loesungen\n\n");
  }  
 printf("**************************************************\n");
 fflush(stdout);
#endif

// LOES += Sum;
}






void GRAD_MAIN::TestePartition()
{
 int j;
/******************************************************************/
/*  Teste eingegebene Partition                                   */

 kanten=knoten=0;
 for(j=0;j<=partition.Used();j++)
  {
   knoten+=partition[j];
   kanten+=partition[j] * j;
  }
 if(kanten % 2 == 1)
  {
   fprintf(stderr,"degree-sum is not divisible by 2 !!\n");
   exit(0);
  }
 kanten /= 2;
 G_PART.Init(knoten,kanten,MAXBOND);
 if(partition.Used() > (knoten-1)*MAXBOND)
  {
   fprintf(stderr,"no graphical partition !!\n");
   exit(0);
  }
 for(j=0;j<=partition.Used();j++)
  G_PART.GetVertAnz(j)=partition[j];
 if(! G_PART.IsGraphic())
  {
   fprintf(stderr,"no graphical partition !!\n");
   exit(0);
  }
 is_regular=1;  
 for(j=0;j<partition.Used();j++)
  if(partition[j] > 0)
    is_regular=0;

 if(TREES_ONLY==1)
  {
   if(((CONN_GRAPHS==1)&&((knoten != kanten+1)||(partition[0] > 0)))||
      ((CONN_GRAPHS==0)&&(knoten-partition[0] <= kanten)))
    {   
#ifndef MULTICODE
     printf("\ntotal number: 0\n ");
#endif
     exit(0);
    } 
  } 
/******************************************************************/

}




void GRAD_MAIN::SpalteAuf()
{
 int j;
 char filename[100];
 FILE *fp;
 int old_split=1;

     
 UsePART = 1;
 a_IMPL.Init(knoten);
 PART.GetPart().ReAlloc(partition.Used());
 PART.GetPart().SetAb0();
 PART.GetTIEFE()=1;
 PART.GetMAXVAL() = MAXBOND;
 PART.GetCONN() = CONN_GRAPHS;
 PART.GetGIRTH() = GIRTH;
 PART.GetGIRTH_AND_IMPL() = 1;
 PART.GetIMP_IF_CONN() = 0;
 PART.GetFIRST_COL_NR()=1;
 PART.GetGO_IMPL()=GO_IMPL;
 PART.GetTREES_ONLY() = TREES_ONLY;
 PART.GetPart().Used()=partition.Used();
 for(j=0;j<=partition.Used();j++)
   PART.GetPart()[j]=partition[j];

 if(S_50_50 == 1)
   PART.EnableSPLIT_50_50();
 if(S_MIDDLE == 1)
   PART.EnableSPLIT_MIDDLE();
 if(S_MAX == 1)
   PART.EnableSPLIT_MAX();
 PART.Init();

 if(PRECOMPUTE_SPLITS == 1)
  {
   PART.ComputePossibleSplits();
   fprintf(stdout,"%d degree-partition splits possible\n",PART.GetPossSplits());
   PART.SetPRINT_SPLITS();
  }

 anz=0;
 while(PART.NextRep())
  {
   if(! GO_IMPL)
    {
     anz++;
     if((anz < 50)||
        ((anz > 50)&&(anz % 25 == 0)))
      {
       if(PRECOMPUTE_SPLITS == 1)
        {
         if(old_split != PART.GetSplitsUntilNow())
          printf("\n");
         fprintf(stdout,"\rnumber of graphs=%d splits=%d",anz,PART.GetSplitsUntilNow());
         old_split=PART.GetSplitsUntilNow(); 
        }
       else
        {
#ifndef MULTICODE
         fprintf(stdout,"\n%d",anz);
#endif
        }   
       fflush(stdout);
      }
     SaveRep();
    }
   else
    {
     fprintf(stdout,"\r");
     fprintf(stdout,"number of graphs=");
     PART.GetLOES().Print(stdout,0); 
     if(PRECOMPUTE_SPLITS == 1)
      {
       printf(" splits=%d",PART.GetSplitsUntilNow());
       old_split=PART.GetSplitsUntilNow(); 
      }
     fflush(stdout);
     SaveRep();
     if(RECONSTRUCT_ALL == 1)
      {
       a_IMPL.GetNBList()=PART.GetNBList();
       a_IMPL.GetNBWert()=PART.GetNBWert();
       a_IMPL.ConstrStart();

       while(a_IMPL.ConstructNextSolution())
        {
         ARRAY < VEKTOR < short > >&  nbliste = a_IMPL.GetNewNBList();
         ARRAY < VEKTOR < short > >&  nbwerte = a_IMPL.GetNewNBWert();
         //do something with neighbourhood-list nbliste

        }
      }  
    }   
  }
}




void GRAD_MAIN::ConstrOrdtreu()
{
 int j,k,l;
 char filename[100];
 FILE *fp;

 UsePART = 0;
 a_graph.GetDim()=knoten;
 a_graph.GetENABLE_AUT()=1;
 a_graph.GetMAXGRAD()=partition.Used();
 a_graph.GetMAXVAL()=MAXBOND;

 a_graph.GetPARTITION().ReAlloc((partition.Used() > 0)?partition.Used():1);
 for(j=1;j<=partition.Used();j++)
  a_graph.GetPARTITION()[j]=partition[j];
 a_graph.GetZSHG()=CONN_GRAPHS;
 if(TREES_ONLY)
  a_graph.GetGirth() = knoten+1;
 else
  a_graph.GetGirth() = GIRTH;
 a_graph.Init(); 
 anz=0;
 while(a_graph.NextRep())
  {
   SaveRep();
   anz++;
#ifndef MULTICODE
   if((anz < 50)||
      ((anz > 50)&&(anz % 25 == 0)))
    {  
     fprintf(stdout,"\rnumber of graphs=%d",anz); 
     fflush(stdout);
    } 
#endif
  }
} 



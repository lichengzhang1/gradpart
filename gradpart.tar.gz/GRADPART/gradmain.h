#ifndef MAIN_H

#include "gradpart.h"
#include "div.h"
#include "impldata.h"
#include "defs.h"



static int ReadNextLine(char* z,FILE* fp)
{
 if(fgets(z,200,fp) == NULL)
  return(0);
 return(1); 
}



class GRAD_MAIN
{
 private:
  int               anz;
  int               kanten,knoten;
  VEKTOR < short >       partition; 
  char                   TREES_ONLY;
  int               GIRTH;
  int               MAXBOND;
  int               CONN_GRAPHS;
  GRADPART               PART;
  MULTGRAPH              a_graph;
  GRAPH_PART             G_PART;
  DEPTH_FIRST_SCHLICHT   a_schl;
  char                   S_50_50,S_MIDDLE,S_MAX;
  char                   PRECOMPUTE_SPLITS; 
  char                   is_regular; 
  char                   GO_IMPL;
  char                   RECONSTRUCT_ALL;
  char                   filename[100];
  char                   UsePART;
  LANGZAHL               Sum,LOES,A;
  char                   PrintPartitions; 
 
  char                   CRITICAL_GRAD;
  char                   CR_V_ANZ; 
 
 /*************************************************************/
  void                   SaveRep();
  void                   TestePartition();
  void                   SpalteAuf();
  void                   ConstrOrdtreu();
  
  void                   ComputeCriticalGraphs();
  int                    MaybeCriticalPartition();
  
  void                   Berechne_n_k(int n,int k);
 /*************************************************************/
 public:
                         GRAD_MAIN() { return; }

  void                   StartConstr(int argc,char* argv[]);                       
};



#define MAIN_H
#endif

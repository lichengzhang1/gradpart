
#include "bitvec.h"
#include "mess.h"


BITVEK::BITVEK(short dim)
{
 #ifdef DEBUG_TG
  if(dim < 1L)
   {
    FatalMess("BITVEK-Konstruktor mit dim < 1L !!\n");
    EXIT();
   }
 #endif

 INT_SIZE = 8 * sizeof(long int);
 Init(dim);

}



void BITVEK::Init(int dim)
{
 #ifdef DEBUG_TG
  if(dim < 1L)
   {
    FatalMess("BITVEK-Init mit dim < 1L !!\n");
    EXIT();
   }
 #endif

 bits=dim;
 anz=dim/INT_SIZE + (dim%INT_SIZE == 0 ? 0 : 1L);
 vec=new long int[anz];
 if(vec==NULL)
  {
   FatalMess("Kein Speicher bei BITVEK-Konstruktor \n");
   EXIT();
  }
 for(int i=0;i < anz; i++)
  vec[i]=0;

}




int BITVEK::IsEmpty()
{
 for(int i=0;i<anz;i++)
  if(vec[i])
   return(0);

 return(1);
}




void BITVEK::Clear()
{
 for(int i=0;i < anz; i++)
  vec[i]=0;

}



void BITVEK::FREE()
{
 anz=0;
 bits=0;
 if(vec != NULL)
  delete[] vec;
 vec=NULL;
}



BITVEK::~BITVEK()
{
 if(vec != NULL)
  delete[] vec;
}



void BITVEK::ReAlloc(int i)
{
 int j;

 #ifdef DEBUG_TG
  if(i < 1)
   {
    FatalMess("BITVEK-ReAlloc mit i < 1 !!\n");
    EXIT();
   }
 #endif

 if(vec == NULL)
  Init(i);
 else
  { 
   if(i <= bits)return;

   bits=i;

   int n_anz;
   n_anz=i/INT_SIZE + (i%INT_SIZE == 0 ? 0 : 1);
   if(n_anz == anz)
    return;
   long int* vec2 = new long int[n_anz];
   if(vec2 == NULL)
    {
     FatalMess("Kein Speicher bei BITVEK-Realloc \n");
     EXIT();
    }
   for(j=0;j < anz;j++)
    vec2[j] = vec[j];
   long int* vec3 = vec;
   vec = vec2;
   delete[] vec3;  
   for(j=anz;j < n_anz; j++)
    vec[j]=0;
   anz=n_anz;
  }
}



void BITVEK::Print(FILE *fp,int einrueck)
{
 int i;

 for(i=1;i<=einrueck;i++)
  fprintf(fp," ");
 for(i=1;i<=bits;i++)
 fprintf(fp,"%d",(*this)[i]);
 fprintf(fp,"\n");
}




void BITVEK::Print(int einrueck)
{
 int i;

 for(i=1;i<=einrueck;i++)
  printf(" ");
 for(i=1;i<=bits;i++)
  printf("%d",(*this)[i]);
 printf("\n");
 fflush(stdout);
}




void BITVEK::Scan()
{
 int _dim,w;

 scanf("%d",&_dim);
 Init(_dim);

 for(int i=1;i<=bits;i++)
  {
   scanf("%d",&w);
   if(w == 1)Set(i);
   if((w != 1)&&(w != 0))
    {
     FatalMess("Fehler bei BITVEK.Scan\n");
     EXIT();
    }
  }
}






#ifndef LABRA_TG_H

#include "permut.t"
#include "array.t"
#include "bitvec.h"
#include "langzahl.h"



class ORDTREU_CONJ_CLASSES;
class SIMS;



class LABRA_BASE
{
 protected:
  short                         grad,R,S;

  PERMUT<short>                 basis,basis_inv;
  VEKTOR<short>                 vater;
  ARRAY< PERMUT <short > >      kantenmarken,eckenmarken;
  LANGZAHL                      order;


  short                         ret_stab_nr,is_last_st;
  short                         sohn_nr,is_last_sohn; 
  short                         nachfolger_nr,is_last_Nachfolger; 


  ARRAY < PERMUT <short > >     *_G_i,*_G_i_min_1; 
  VEKTOR < short >              *_V;
  int                      G_i_min_1_anz;
  BITVEK                        Delta,IsInv; 
  PERMUT<short>                 SiftEin,SN;



  ARRAY < PERMUT <short > >&   U_i()  
                                { return(kantenmarken); }
  ARRAY < PERMUT <short > >&   U_i_inv()  
                                { return(eckenmarken); }
  VEKTOR < short >&            V() 
                                { return(*_V); }
  ARRAY < PERMUT <short > >&   G_i() 
                                { return(*_G_i); }
  ARRAY < PERMUT <short > >&   G_i_min_1() 
                                { return(*_G_i_min_1); }


  /*************************************************/
  /* Interne Funktionen zum Umwandeln der Erzeuger */
  /* (Mark Jerrum: A Compact Representation for    */
  /*               Permutation Groups, Journal of  */
  /*               Algorithms 7, 60-78 (1986) )    */
  /*************************************************/
  void                         gens_to_labra(); 
  void                         Augment_U_i(int j);
  void                         Schreier_und_Sift(int j);
  void                         Sift(PERMUT <short>& p,int i);


  char                         IS_INIT;


 public:
                       LABRA_BASE() { IS_INIT=0; grad=0; }
                       LABRA_BASE(int n);
                       LABRA_BASE(SIMS& Kette);
                       LABRA_BASE(ARRAY< PERMUT <short > >& gens);

  void                 Init(int n);
  void                 FREE();
  void                 operator=(LABRA_BASE& quelle);  
  void                 operator=(SIMS& Kette);  
  void                 operator=(ARRAY < PERMUT < short > >& gens);  

  void                 ScanErz(); 
  void                 InitErz(int nb_gen, int *gen);
  void                 GetGens(ARRAY < PERMUT < short > >& gens);
  void                 Print();
  void                 update_eckenmarken(); 

  PERMUT<short>&       KM(int i)   //Kantenmarken
                        { return(kantenmarken[i]); }
  PERMUT<short>&       EM(int i)   //Eckenmarken
                        { return(eckenmarken[i]); }
  short&               HV(int i)   //HoleVater von i
                        { return(vater[i]); }
  short                HR(int i); //HoleRoot(i)
  int             PathExists(int i,int k);
  
  short&               pi(int i)   //BAsis[i]
                        { return(basis[i]); }
  short&               pi_i(int i) //BAsis_Inv[i]
                        { return(basis_inv[i]); }

  void                 StabErz_start(int i);
  int             IsLastStabErz() 
                        { return(is_last_st); } 
  PERMUT<short>&       StabErz(int i,int& km_nr);
  PERMUT<short>&       StabErz(int i);

  void                 Sohn_start(int i); 
  int             IsLastSohn()
                        { return(is_last_sohn); }
  PERMUT<short>&       Sohn(int i); 
  
  void                 Nachfolger_start(int i); 
  int             IsLastNachfolger()
                        { return(is_last_Nachfolger); }
  int             Nachfolger(int i); 
   
  int             Stabilizes(int x);

  int             Dim() { return(grad); }
  LANGZAHL&            Ordnung();

  void Print(int i) { return; }
  void Print(FILE* f,int i) { return; }
  void PrintUsed(FILE* f,int i) { return; }
};






class LABRA_TG : public LABRA_BASE
{
 private:

  /***********************************************/
  /* Interne Strukturen fuer den Basiswechsel    */
  /*  ( siehe Diplomarbeit )                     */
  /***********************************************/
  PERMUT<short>               basis_neu,basis_neu_inv,dummy;
  VEKTOR<short>               vater_neu;
  ARRAY< PERMUT <short > >    kantenmarken_neu,eckenmarken_neu;

  BITVEK                      root,coseflag,orbitlist,newpoints,
                              pointlist,orbit,delta; 

  VEKTOR<short>               bo_m;

  ARRAY< PERMUT <short > >    cosetrep;
  ARRAY<BITVEK>               br_a_soehne;


  /***********************************************/
  /* Interne Funktionen fuer den Basiswechsel    */
  /***********************************************/
  void                        cycle_node_bottom();
  void                        cycle_node_middle();
  void                        cycle_node_top();
  void                        init_data();
  void                        update_orbit(int j);
  void                        update_soehne();
 
  PERMUT<short>&              KM_N(int i)   //Kantenmarken (neu)
                              { return(kantenmarken_neu[i]); }
  PERMUT<short>&              EM_N(int i)   //Eckenmarken  (neu)
                              { return(eckenmarken_neu[i]); }
  short&                      HV_N(int i)   //HoleVater von i (neu)
                              { return(vater_neu[i]); }
  short&                      pi_N(int i)   //BAsis[i] (neu)
                              { return(basis_neu[i]); }
  short&                      pi_i_N(int i) //BAsis_Inv[i] (neu)
                              { return(basis_neu_inv[i]); }

  LANGZAHL                    L1,L2;
  PERMUT<short>               ConjRep;
  ORDTREU_CONJ_CLASSES        *ORD;
  int                    ConjAnz;   
 public:
                       LABRA_TG() { IS_INIT=0; grad=0; }
                       LABRA_TG(int n);
                       LABRA_TG(SIMS& Kette);
                       LABRA_TG(ARRAY< PERMUT <short > >& gens);

  void                 operator=(LABRA_TG& quelle);
  void                 Init(int n);
  void                 FREE();
  void                 DirProd(LABRA_TG& LeftGroup,LABRA_TG& RightGroup);
  void                 VerdoppeleGruppe(LABRA_TG& L);
  void                 SetYoung(VEKTOR < short >& dim_vektor); 
  void                 SetSym(); 
  void                 SetDn();

  void                 Cycle(int r,int s); 
  //Zyklisches Tauschen der Basis von r nach s
  void                 CycleId();

  void                 ConjStart();
  void                 ConjStart(PERMUT<short>& per_v);
  int             NextConjClass();
  PERMUT<short>&       GetConjRep() { return(ConjRep);} 
  ORDTREU_CONJ_CLASSES &GetORD() { return(*ORD); }
  // Aufruf bitte erst nach Initialisierung durch ConjStart()
  // Basis muss id sein !!!!!!!!!!!!!!

  void                 CopyStab(LABRA_TG& Q,int i);

  
  /*Phantomfunktionen       */
  void                 Add(int i,int j) { return; }
  void                 REALLOC(int i,int j) { return; }
  void                 ReAlloc(int i) { return; }
  void                 Scan() { return; }   
  
 };
 



#define LABRA_TG_H
#endif





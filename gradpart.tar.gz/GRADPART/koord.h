#ifndef ORD_KOORD_H

#include "koorbase.h"

#define MAX_RESTR_FUNC 10

typedef void (*RD)(int z,int sp);
typedef int  (*RS)(int z,int sp,int wert);


class ORD_KOORD : public KOORD_BASE 
{
 protected:

  short                       SUCHE_ORD_GROESSE;

  short                       ABWEICHUNG;

  char                        UNTERTEILE;
  //==1, falls die Gesamtmatrix mithilfe von Homomorphismen
  //     aufgeteilt werden soll.

  short                       Sp;
  //number of columns 

  ARRAY < VEKTOR < short > >  ConnList;
  //contains the computed representative
  //as a neighbourhood-list

  ARRAY < VEKTOR < short > >  ConnWert;
  //connection-multiplicities

  ARRAY < VEKTOR < short > >  ConnUsed;

  ARRAY < VEKTOR < short > >  z_orbits;
  //contains the orbits of G on the rows. 
  //here the rows have numbers 1,...,Zei 

  ARRAY < VEKTOR < short > >  sp_orbits;
  //contains the orbits of G on the columns 
  //here the columns have the numbers 1,...,Sp

  ARRAY < VEKTOR < short > >  ZeilenZerlegung;
  //partition of the rows

  ARRAY < VEKTOR < short > >  SpaltenZerlegung;
  //partition of the columns

  VEKTOR < short >            reihenf_zeile;
  VEKTOR < short >            reihenf_spalte;
  //vectors which have at least length schritte.
  //(reihenf_zeile[i],reihenf_spalte[i]) determines the i-th box
  //of the matrix

  int                         restr_func_anz;
  //Anzahl der Funktionen, die zu rufen sind, um zu pruefen, ob
  //ein Wert an einer bestimmten Stelle gesetzt werden darf.

  RD                          RestrDel[MAX_RESTR_FUNC];
  RS                          RestrSet[MAX_RESTR_FUNC];

 public:
                              ORD_KOORD();
                              ~ORD_KOORD();

  void                        FREE();
  virtual void                Del(int z,int sp); 
  virtual int                 Set(int z,int sp,int wert);
  virtual void                Init() { restr_func_anz = 0; UNTERTEILE = 1; }   
  virtual void                BerechneAufteilung();
  void                        NotiereLoesung();
  virtual void                NotiereTeilLoesung(int idx);
  void                        PrintLoesung();
  void                        SetRestr(RS set,RD del); 
  LABRA_TG&                   GetAut();
  ARRAY < VEKTOR < short > >& GetConnWert()
                               { return(ConnWert); }
  ARRAY < VEKTOR < short > >& GetConnList()
                               { return(ConnList); }
  short&                      GetSp()    { return(Sp); }
  short                       GetDim() { return(Sp+Zei); } 
  char&                       GetUNTERTEILE() { return(UNTERTEILE); } 
};



#define ORD_KOORD_H
#endif



#ifndef LANGZAHL_H
#include <stdio.h>
#include <limits.h>
#include "vector.t"



//natuerliche Zahlen werden zur Basis 10 dargestellt
//koeff ist ein dynamisches Feld von Koeffizienten, das
//bei Bedarf verlaengert wird.

class LANGZAHL
{
 private:
  VEKTOR<int>     koeff; 

  VEKTOR<int>     temp1;

  int             GrEq(LANGZAHL& l,int hoch_i);
  void                 minus(int ziffer,int hoch_i);
  void                 minus(LANGZAHL& l,int hoch_i); 
  int             MaxExp(int l);
 public:
                       LANGZAHL();
                       LANGZAHL(int z);
  
  void                 operator+=(int l);
  void                 operator-=(int l);
  void                 operator*=(int l);
  void                 operator/=(int l);
  void                 operator=(int l);
  int             operator==(int l);
  int             operator>=(int l);
  int             operator>(int l);
  int             operator<=(int l);
  int             operator<(int l);

  void                 operator+=(LANGZAHL& l);
  void                 operator-=(LANGZAHL& l);
  void                 operator*=(LANGZAHL& l);
  void                 operator/=(LANGZAHL& l);
  void                 operator=(LANGZAHL& l);
  int             operator==(LANGZAHL& l);
  int             operator>=(LANGZAHL& l);
  int             operator>(LANGZAHL& l);
  int             operator<=(LANGZAHL& l);
  int             operator<(LANGZAHL& l);

  void                 Bin(int k,int n);

  int             lang_to_int();
  void                 Print(int einrueck);
  void                 Print(FILE* fp,int einrueck);
  char*                StrPrint();
  void                 StrScan(char *str);
  void                 PrintUsed(FILE* fp,int einrueck);
  void                 Scan(FILE *fp);
  VEKTOR<int>&    Koeff()  { return(koeff); }

  void                 Add(int i,int j) { return; }
  void                 REALLOC(int i,int j) { return; }
  void                 ReAlloc(int i) { return; }
  void                 Scan() { return; }
  int             Dim() { return(koeff.Dim()); }
};



#define LANGZAHL_H
#endif



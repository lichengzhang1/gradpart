#include "div.h"
#include "defs.h"
#include "molplaz.h"


GRAPH_PART::GRAPH_PART(int n,int k,int _c)
{
 Init(n,k,_c);
}


void GRAPH_PART::Init(int n,int k,int _c)
{
 knoten=n;
 kanten=k;
 c = _c;

 part.ReAlloc(c*(n-1));
 part.SetAb0();
 d.ReAlloc(n);
 part.Clear();

 //d.h. knoten mal Grad 0
}



int GRAPH_PART::IsGraphic()
{
 int i,j,k,r,li,re;

 i=1;
 for(j = c*(knoten-1);j>=0;j--)
  for(k=1;k<=part[j];k++)
   d[i++]=j;

 for(r=1;r<=knoten-1;r++)
  {
   li=0;
   for(i=1;i<=r;i++)
    li+=d[i];
   re=c*r*(r-1);
   for(i=r+1;i<=knoten;i++)
    re += (c*r < d[i])?c*r:d[i];
   if(li > re)return(0);
  }
 return(1);
}



short& GRAPH_PART::GetVertAnz(int grad)
{
 #ifdef DEBUG_TG
  if((grad < 0)||(grad > c*(knoten-1)))
   {
    fprintf(stderr,"Falscher Grad bei SCHLICHT_PART::GetVertAnz\n");
    fprintf(stderr,"grad=%d knoten=%d\n",grad,knoten);
    exit(0);
   }
 #endif

 return(part[grad]);
}


/**************************************************************/


SCHLICHT_PART::SCHLICHT_PART(int n,int k,int _c) : GRAPH_PART(n,k,_c)
{
 part[c*(knoten-1)]=knoten;
}



void SCHLICHT_PART::Init(int n,int k,int _c)
{
 knoten=n;
 kanten=k;
 c = _c;

 part.ReAlloc(c*(n-1));
 part.SetAb0();
 d.ReAlloc(n);
 part.Clear();
 part[c*(knoten-1)]=knoten;
}


int SCHLICHT_PART::NextRep()
{
 int j,l,h,k,i;

 while(1)
  {
   if(part[0] == knoten)
    return(0);
   j = 0;
   l = c*(knoten-1);
   while(part[j] == 0)j++; 
   while(part[l] == 0)l--; 
   if(l > j+1){ part[l-1]++;h=part[l];part[l]=0;part[c*(knoten-1)]+=(h-1);}
   if(l==j+1) { part[j]++;part[l]=0;part[c*(knoten-1)]=knoten-part[j];}
   if(l==j)   { part[j]=0;part[j-1]=1;part[c*(knoten-1)]=knoten-1; }
   k=0;
   for(i=1;i<=c*(knoten-1);i++)
    k+=part[i]*i;
   if(k%2 == 0) 
    {

     k/=2;
     if((k == kanten)&&(IsGraphic()))
      return(1);
    }
  }
}


/**************************************************************/


DEPTH_FIRST_SCHLICHT::DEPTH_FIRST_SCHLICHT(int n,int k,int _c)
 {
  Init(n,k,_c);
 }


void DEPTH_FIRST_SCHLICHT::Init(int n,int k,int _c,int _max_entry)
{
 max_entry = _max_entry;
 knoten=n;
 kanten=k;
 c = _c;

 degree_gr_0 = 0;
 part.ReAlloc(c*(knoten-1));
 part.SetAb0();
 d.ReAlloc(knoten);
 for(int i=1;i<=knoten;i++)
  d[i] = max_entry+1;
}


void DEPTH_FIRST_SCHLICHT::Init(int n,int k,int _c)
{
 knoten=n;
 kanten=k;
 c = _c;
 max_entry = c*(knoten-1);

 degree_gr_0 = 0;
 part.ReAlloc(c*(knoten-1));
 part.SetAb0();
 d.ReAlloc(knoten);
 for(int i=1;i<=knoten;i++)
  d[i] = max_entry+1;
}


short DEPTH_FIRST_SCHLICHT::GetVertAnz(int grad)
{
 #ifdef DEBUG_TG
  if((grad < 0)||(grad > c*(knoten-1)))
   {
    fprintf(stderr,"Falscher Grad bei DEPTH_FIRST_SCHLICHT::GetVertAnz\n");
    fprintf(stderr,"grad=%d knoten=%d\n",grad,knoten);
    exit(0);
   }
 #endif

 return(part[grad]);
}


int DEPTH_FIRST_SCHLICHT::IsAnfStueck(int t)
{
 int i,j,k,r,l_su,r_su;

 for(i=1;i<=t;i++)
  if(d[i] > max_entry)
   return(0);
 i=0;
 for(j=1;j<=t;j++)
  i+=d[j];
 if(i > 2*kanten)
  return(0); 
 if(i + (knoten-t)*d[t] < 2*kanten)
  return(0);
 l_su=0; 
 for(r=1;r<=t;r++)
  {
   l_su += d[r];
   r_su = 0;
   for(i=r+1;i<=t;i++)
    r_su+=(c*r < d[i])?c*r:d[i];
   if(l_su > c*r*(r-1)+r_su+(knoten-t)*d[t])
    return(0);
  }
 return(1);
}


int DEPTH_FIRST_SCHLICHT::NextRep()
{
 int i,j,k;
 int lim;

 if(degree_gr_0)
  lim = 1;
 else
  lim = 0;

 if(d[1]==lim)
  return(0);
 i = knoten;
 while(d[i]==lim)i--;
 d[i]--;

 while(1)
  { 
   j=IsAnfStueck(i);

   if((j==0)&&(i==1)&&(d[1]==lim))return(0);
   if(j==0)
    {
     k=i;
     while((k >=1)&&(d[k] == lim))k--;
     if(k == 0)
      return(0);
     d[k]--;
     i=k; 
    }
   else
    {
     if(i==knoten)
      {
       part.Clear();
       for(k=1;k<=knoten;k++)
        part[d[k]]++; 
       return(1);
      }
     else
      { 
       i++;
       d[i]=d[i-1]; 
      } 
    }
  }
}



/**************************************************************/


ALL_PART::~ALL_PART()
{
 return;
}


int ALL_PART::NextRep()
{
 part.ReAlloc((max < 1)?1:max);
 return(NextRep(part));
}


//first initialize max,summe and first.
//Then use this function to enable or disable shift. 
void ALL_PART::SetShift()
{
 int i,l;

 shift_v.ReAlloc((max < 1)?1:max);
 if(SHIFT_PARTITIONS == 0)
  {
   for(i=0;i<=max;i++)
    shift_v[i]=i;
  }
 if(SHIFT_PARTITIONS == 1)
  {
   l=max/2;
   for(i=0;i <= max-l;i++)
    shift_v[i]=i+l;
   for(i=max-l+1;i<=max;i++)
    shift_v[i]=i-(max-l+1);
  }
 if(SHIFT_PARTITIONS == 2)
  {
   for(i=0;i<=max;i++)
    shift_v[i]=max-i;
  }

}




int ALL_PART::Klein_part(VEKTOR < short >& a,int i,int r,char is_erster)
{
 int h,A=1,l,m,k,j,_i,_j,_r,o,p,max_block_anz,blocks;
 VEKTOR < short >& S = shift_v;
 

 if(is_erster)
  {
   for(j=0;j<=i;j++)a[S[j]]=0;
   if(r==0)return(1);
   max_block_anz=((i+1)<r)?(i+1):r;
   l=i;
   for(j=1;j<=max_block_anz;j++)
    a[S[l--]]=1;
   a[S[i]]+=r-max_block_anz;
   return(1);
  }

 if(r==0)
  { 
   return(0);
  } 
 nr[0]=0;
 for(j=0;j<=i;j++)
  if(a[S[j]])
   nr[++nr[0]]=j;
 blocks=nr[0];

 _r=r-blocks;
 _i=blocks;
 for(l=1;l<=blocks;l++)
  hilf[l]=a[S[nr[l]]]-1;

 if(_r == 0)A=0;
 else
  {
   j=1;l=_i;
   while(hilf[l]==0)l--;
   while(hilf[j]==0)j++;
   if(l>j+1){hilf[l-1]++;h=hilf[l];hilf[l]=0;hilf[_i]+=(h-1);}
   if(l==j+1){hilf[j]++;hilf[l]=0;hilf[_i]=_r-hilf[j];}
   if((l==j)&&(j>1)){hilf[j]=0;hilf[j-1]=1;hilf[_i]=_r-1;}
   if((l==j)&&(j==1))A=0;  
  } 

 if(A)
  { 
   for(l=0;l<=i;l++)a[S[l]]=0;
   for(l=1;l<=blocks;l++)
    a[S[nr[l]]]=hilf[l]+1;
   return(1);
  }     

 for(l=0;l<=i;l++)hilf[l]=0;
 for(j=1;j<=blocks;j++)
  hilf[nr[j]]=1;
 hilf[nr[blocks]]+=r-blocks;

 l=i;
 while((l>0) && (!((hilf[l] > 0) && (hilf[l-1]==0))))l--;
 if(l>0)
  {
   for(j=0;j<=l-2;j++)
    a[S[j]]=hilf[j];
   a[S[l-1]]=hilf[l];
   a[S[l]]=0;
   for(j=l+1;j<=i;j++)a[S[j]]=0;
   k=i;
   while((hilf[k]==0) && (k>l))k--;
   o=i;
   if(k > l)
    {
     for(j=k;j>l;j--)
      a[S[o--]]=hilf[j];
    }  
   return(1);
  }   
 else
  {
   if(blocks==1)
    {
     return(0);
    } 
   blocks--; 
   for(j=0;j<=i;j++)a[S[j]]=0;
   l=i;
   for(j=1;j<=blocks;j++)
    a[S[l--]]=1;
   a[S[i]]+=r-blocks;
   return(1);
  }          
}





int ALL_PART::NextRep(VEKTOR < short >& V)
{
 int j,l,h;

 #ifdef DEBUG_TG
  if(max > V.Dim())
   {
    fprintf(stderr,"Wrong dimension in ALL_PART::NextRep\n");
    exit(0);
   }

 #endif

 if(! SPLIT_KLEIN)
  {
   if(first)
    {
     V.Clear();
     V[shift_v[max]]=summe;
     return(1);
    }

   if(V[shift_v[0]] == summe)
    return(0);
   j=0;l=max;
   while(V[shift_v[j]]==0)j++;
   while(V[shift_v[l]]==0)l--;
   if(l > j+1)
    { 
     V[shift_v[l-1]]++;
     h=V[shift_v[l]];
     V[shift_v[l]]=0;
     V[shift_v[max]]+=(h-1);
    }
   if(l==j+1) 
    { 
     V[shift_v[j]]++;
     V[shift_v[l]]=0;
     V[shift_v[max]]=summe-V[shift_v[j]];
    }
   if(l==j)   
    { 
     V[shift_v[j]]=0;
     V[shift_v[j-1]]=1;
     V[shift_v[max]]=summe-1; 
    }
   return(1);
  }
 else
  {
   if(first)V.Clear();
   nr.ReAlloc((1<(max+1))?(max+1):1);
   hilf.ReAlloc((1<(max+1))?(max+1):1);
   return(Klein_part(V,max,summe,first));
  } 
} 



short ALL_PART::GetPart(int i)
{
 return(part[i]);
}



/**************************************************************/


void DescPart::Init(int sum)
{
 summe = sum;
 part.ReAlloc(summe);
}




int DescPart::NextRep(VEKTOR < short >& PA,char first)
{
 int i,j;

 if(first)
  {
   PA.Used() = 1;
   PA[1] = summe;
   first = 0;
  }
 else
  {
   if(PA.Used() == summe)
    return(0);
   i = PA.Used()-1;
   while((i>=1)&&(PA[PA.Used()]-PA[i] < 2))
    i--;
   if(i==0)
    {
     PA.Used()++;
     for(j=1;j<=PA.Used();j++)
      PA[j] = 1;
    }
   else
    {
     for(j=PA.Used()-1;j>=i;j--)
      PA[j] = PA[i]+1;
    }
  }
 PA[PA.Used()] = summe;
 for(i=1;i<PA.Used();i++)
  PA[PA.Used()] -= PA[i];
 return(1);
}



int DescPart::NextRep(char first)
{
 int i,j;

 if(first)
  {
   part.Used() = 1;
   part[1] = summe;
   first = 0;
  }
 else
  {
   if(part.Used() == summe)
    return(0);
   i = part.Used()-1;
   while((i>=1)&&(part[part.Used()]-part[i] < 2))
    i--;
   if(i==0)
    {
     part.Used()++;
     for(j=1;j<=part.Used();j++)
      part[j] = 1;
    }
   else
    {
     for(j=part.Used()-1;j>=i;j--)
      part[j] = part[i]+1;
    }
  }
 part[part.Used()] = summe;
 for(i=1;i<part.Used();i++)
  part[part.Used()] -= part[i];
 return(1);
}



/**************************************************************/


void ALL_HYBRID::Init(long int _dim,long int maxgrad)
{
 dim = _dim;
 grade.ReAlloc(dim);
 klassen.ReAlloc(dim);
 parts.REALLOC(dim,maxgrad);
 first = 1;
}



void ALL_HYBRID::SetGrad(long int idx,long int wert)
{
 grade[idx] = wert;
}



long int ALL_HYBRID::NextRep()
{
 int idx,i,j,_k,k,l,m,best,io,jo;


 if(first)
  {
   first=0;
   idx = 1;
   mult1.ReAlloc(100);
   mult2.ReAlloc(100);
   hybrid_anz.ReAlloc(dim);
   hybrid_anz.Clear();
   hybrid_bed_in_row.ReAlloc(dim);
  }
 else
  {
   idx = dim;
   if(hybrid_bed_in_row[idx])
    {
//     printf("hybrid_anz[%d]--\n",hybrid_bed_in_row[idx]);
     hybrid_anz[hybrid_bed_in_row[idx]]--;
    }
   hybrid_bed_in_row[idx]=0;
   k = 0;
   goto ALL_HYBRID_NEXT;
  }

 while(1)
  {
   k = 1;
   ALL_HYBRID_NEXT:
   a_desc.Init(grade[idx]);
   if(a_desc.NextRep(parts[idx],k))
    {
     l = idx;
     _k = l-1;
     while((_k >= 1)&&(klassen[_k] != klassen[l]))_k--;
     best=1;
     if(_k > 0)
      {
       //parts[_k] muss >= parts[l] sein
       if(parts[_k].Used() > parts[l].Used())
        { best=0; goto F1; }
       if(parts[_k].Used() == parts[l].Used())
        {
         for(m=1;m<=parts[_k].Used();m++)
          {
           if(parts[_k][m] > parts[l][m])
            { best=0; goto F1; }
           if(parts[_k][m] < parts[l][m])
            break;
          }
        }
      }

     F1:
     hybrid_bed_in_row[idx] = 0;
     if(best)
      {
       if(parts[idx][1] > MAXVAL)
        best=0;
      }
     if(best)
      {
       //stelle fest, ob die aktuelle Zeile einer
       //Hybridisierungsbed. genuegt.
       mult2.Clear();
       mult2[1] += H_numbers[idx];
       for(io=1;io<=parts[idx].Used();io++)
        mult2[parts[idx][io]]++;
       for(i=1;i<=hybridisierungen.Used();i++)
        {
         mult1.Clear();
         for(io=1;io<=hybridisierungen[i].Used();io++)
          mult1[hybridisierungen[i][io]]++;
         mult1.Used() = 100;
         while(mult1[mult1.Used()]==0)
          mult1.Used()--;

         jo = 1;
         if(hybrid_typnummern[i] != multi[idx])
          jo=0;
         if(jo)
          for(io=1;io<=mult1.Used();io++)
           if(mult1[io] != mult2[io])
            { jo = 0; break; }
         if((jo==1)&&(Hybr_H_anz[i] > -1))
          {
           if(H_numbers[idx] != Hybr_H_anz[i])
            jo = 0;
          }
         if(jo)
          {
           hybrid_bed_in_row[idx] = i;
           hybrid_anz[i]++;
//printf("hybrid_bed_in_row[%d]=%d\n",idx,i);
//printf("hybrid_anz[%d]++\n",i);
           if(hybrid_anz[i] > hybrid_max_anz[i])
            {
//             printf("best=0 wegen hybrid_anz[i] > hybrid_max_anz[i]\n");
             best=0;
            }
           break;
          }
        }
       if(best)
        {
         m=0;
         for(j=idx+1;j<=dim;j++)
          if(multi[j] == multi[idx])m++;
         l = 0;
         for(j=1;j<=hybridisierungen.Used();j++)
          if(hybrid_typnummern[j]==multi[idx])
           if(hybrid_anz[j] < hybrid_min_anz[j])
            l += (hybrid_min_anz[j]-hybrid_anz[j]);
         //es muessen noch mind. l Zeilen mit einer best. Hybr.
         //festgelegt werden.
         if( l > m)
          {
  //         printf("best=0 wegen l > m\n");

           best = 0;
          }
        }
      }
     if(best==1)
      {
       if(idx==dim)return(1);
       else idx++;
      }
     else
      {
       if(hybrid_bed_in_row[idx])
        {
//         printf("hybrid_anz[%d]--\n",hybrid_bed_in_row[idx]);
         hybrid_anz[hybrid_bed_in_row[idx]]--;
        }
       hybrid_bed_in_row[idx]=0;
       k=0; goto ALL_HYBRID_NEXT;
      }
    }
   else
    {
     if(idx==1)
      return(0);
     else
      {
       if(hybrid_bed_in_row[idx])
        {
  //       printf("hybrid_anz[%d]--\n",hybrid_bed_in_row[idx]);
         hybrid_anz[hybrid_bed_in_row[idx]]--;
        }
       hybrid_bed_in_row[idx]=0; 
       idx--;
       if(hybrid_bed_in_row[idx])
        {
    //     printf("hybrid_anz[%d]--\n",hybrid_bed_in_row[idx]);
         hybrid_anz[hybrid_bed_in_row[idx]]--;
        }
       hybrid_bed_in_row[idx]=0; 
       k = 0;
       goto ALL_HYBRID_NEXT;
      }
    }
  }
}




/**************************************************************/


void VALID_HYBRID::Init(int _dim)
{
 dim = _dim;
 testpart.ReAlloc(dim);
 mult.ReAlloc(dim);
 mult.SetAb0();
}



int VALID_HYBRID::IsValid()
{
 int i,j,k,n,io;


 for(j=1;j<=2;j++)
  {
   for(i=1;i<=dim;i++)
    testpart[i] = parts[i][j];
   n = dim;
   k = 0;
   for(i=1;i<=dim;i++)
    k += testpart[i];
   if(k % 2 != 0)
    return(0);
   k /= 2;
   a_part.Init(n,k,1);
   mult.Clear();
   for(i=1;i<=dim;i++)
    {
     if(testpart[i] < dim)
      mult[testpart[i]]++;
     else
      return(0); 
    }  
   for(i=0;i<dim;i++)
    a_part.GetVertAnz(i) = mult[i];
   if(! a_part.IsGraphic())
    return(0);   
  }

 for(i=1;i<=dim;i++)
  testpart[i] = parts[i][1] + parts[i][2];
 n = dim;
 k = 0;
 for(i=1;i<=dim;i++)
  k += testpart[i];
 if(k % 2 != 0)
  return(0);
 k /= 2;
 a_part.Init(n,k,1);
 mult.Clear();
 for(i=1;i<=dim;i++)
  {
   if(testpart[i] < dim)
    mult[testpart[i]]++;
   else
    return(0); 
  }  
 for(i=0;i<dim;i++)
  a_part.GetVertAnz(i) = mult[i];
 if(! a_part.IsGraphic())
  return(0);   
 

 for(i=1;i<=dim;i++)
  testpart[i] = parts[i][1] + parts[i][3];
 n = dim;
 k = 0;
 for(i=1;i<=dim;i++)
  k += testpart[i];
 if(k % 2 != 0)
  return(0);
 k /= 2;
 a_part.Init(n,k,1);
 mult.Clear();
 for(i=1;i<=dim;i++)
  {
   if(testpart[i] < dim)
    mult[testpart[i]]++;
   else
    return(0); 
  }  
 for(i=0;i<dim;i++)
  a_part.GetVertAnz(i) = mult[i];
 if(! a_part.IsGraphic())
  return(0);   

 return(1);
}



/**************************************************************/

int GALE::Test()
{
 int i,j,k,l_sum,r_sum;

 s.Used()=n;
 s.SortDesc();

 l_sum=0;
 for(k=1;k < n;k++)
  {
   l_sum+=s[k];
   r_sum=0;
   for(i=1;i<=m;i++)
    r_sum+=((z[i] < c*k)?z[i]:c*k);
   if(l_sum > r_sum)
    return(0);
  }
 l_sum+=s[n];
 r_sum=0;
 for(i=1;i<=m;i++)
  r_sum+=z[i];
 if(r_sum != l_sum)
  return(0);
 return(1);
}



void GALE::Init(int _m,int _n,int _c)
{
 m=_m;
 n=_n;
 c = _c;
 s.ReAlloc(n);
 z.ReAlloc(m);
}



void GALE::SetSp(int idx,int wert)
{
 #ifdef DEBUG_TG
  if((idx > n)||(wert > c*m)||(wert < 0))
   {
    fprintf(stderr,"wrong input in GALE::SetSp\n");
    exit(0);
   }
 #endif

 s[idx]=wert;
} 


void GALE::SetZ(int idx,int wert)
{
 #ifdef DEBUG_TG
  if((idx > m)||(wert > c*n)||(wert < 0))
   {
    fprintf(stderr,"wrong input in GALE::SetZ\n");
    exit(0);
   }
 #endif

 z[idx]=wert;
} 



/**************************************************************/



void KILOMETER_ZAEHLER::Setk(int _k)
{
 k=_k;
 Z.REALLOC(k,1);
 nr_i.REALLOC(k,1);
 Z_intern.REALLOC(k,1);
 nr_i_intern.REALLOC(k,1);
}



LANGZAHL& KILOMETER_ZAEHLER::Getnr_i(int idx)
{
 return(nr_i[idx]);
}



void KILOMETER_ZAEHLER::SetZ(int idx,LANGZAHL& wert)
{
 Z[idx]=wert;
}


//1 <= _nr <= ...       !!!!!!!!!!!!
void KILOMETER_ZAEHLER::Start(LANGZAHL& _nr)
{
 int i,j;
 LANGZAHL dummy,dummy2;

 k_intern=0;
 for(i=1;i<=k;i++)
  {
   if(Z[i] > 1)
    {
     k_intern++;
     Z_intern[k_intern]=Z[i];
    }
  }
 
 nr=_nr;
 nr-=1;
 //0 <= nr < Z_intern[1]*Z_intern[2]*...
 for(i=1;i<=k_intern;i++)
  nr_i_intern[i]=0;
 while(nr >= 1)
  {
   i=k_intern-1;
   dummy=Z[k_intern];
   while(nr >= dummy)
    {
     i--;
     dummy*=Z_intern[i+1];
    }
   i++;
   
   dummy/=Z_intern[i];
   nr_i_intern[i]=Z_intern[i];
   dummy2=dummy;
   dummy2*=nr_i_intern[i];
   while(dummy2 > nr)
    {
     nr_i_intern[i]-=1;
     dummy2=dummy;
     dummy2*=nr_i_intern[i];
    }
   nr-=dummy2;
  }

 j=0;
 for(i=1;i<=k;i++)
  {
   if(Z[i] > 1)
    nr_i[i]=nr_i_intern[++j];
   else
    nr_i[i]=0; 
  }
}




/**************************************************************/




void UNRANK::Setk(int _k)
{
 k=_k;
 v.ReAlloc(k);
}



int UNRANK::Getv(int idx)
{
 return(v[idx]);
}



void UNRANK::Start(LANGZAHL& _m)
{
 int p,i;
 LANGZAHL dummy;

 R=_m;
 for(i=k;i>=1;i--)
  {
   p=i-1;
   do
    {
     p++; 
     dummy.Bin(i,p);   
    }
   while(R >= dummy);
   dummy.Bin(i,p-1);
   R-=dummy;
   v[i]=p; 
  }
}



/**************************************************************/



void UNRANK_MULTI::Setn(int _n)
{
 n=_n;
 m_i.ReAlloc(n);
 i_i.ReAlloc(n);
 ind.ReAlloc(n);
}




void UNRANK_MULTI::Setk(int _k)
{
 k=_k;
 n_i.ReAlloc(k);
 nr_i.REALLOC(k,1);
}



void UNRANK_MULTI::Setn_i(int idx,int wert)
{
 n_i[idx]=wert;
}


VEKTOR < short >& UNRANK_MULTI::GetLoes()
{
 return(m_i);
}


//0 <= nr < ...
void UNRANK_MULTI::Start(LANGZAHL& nr)
{
 int i,j,l,anz;
 LANGZAHL dummy,dummy2; 

 dummy2=nr;
 dummy2+=1;
 a_Z.Setk(k);
 for(i=1;i<=k;i++)
  {
   l=n;
   for(j=1;j<=i-1;j++)
    l-=n_i[j];
   dummy.Bin(n_i[i],l);
   a_Z.SetZ(i,dummy); 
  }
 a_Z.Start(dummy2);
 for(i=1;i<=k;i++)
  nr_i[i]=a_Z.Getnr_i(i);

 for(j=1;j<=n;j++)
  i_i[j]=j;
 anz=n;
 m_i.Clear();
 for(i=1;i<=k;i++)
  {
   a_UR.Setk(n_i[i]);
   a_UR.Start(nr_i[i]);
   for(j=1;j<=n_i[i];j++)
    ind[j]=a_UR.Getv(j);
   for(j=1;j<=n_i[i];j++)
    m_i[i_i[ind[j]]]=i; 
   anz-=n_i[i];
   l=1;
   for(j=1;j<=n;j++)
    {
     if(m_i[j] == 0)
      i_i[l++]=j;
    }
  }
}




/**************************************************************/



void TG_GRAPH::Init(int _dim)
{
 dim=_dim;
 NBlist.REALLOC(dim,dim);
 NBwert.REALLOC(dim,dim);
 x_coordinates.ReAlloc(dim);
 y_coordinates.ReAlloc(dim);
 split_tiefe.REALLOC(dim,dim);
}




//this function should be used after initializing
//NBlist
void TG_GRAPH::Init(int _l_dim,int _is_spl)
{
 int i;

 l_dim=_l_dim;
 is_split=_is_spl;
 SplitTree.FREE();
}



void TG_GRAPH::PrintSplitTree(FILE *fp)
{
 int i;

 fprintf(fp,"SPLIT_TREE=\n");
 SplitTree.PrintTopDown(fp);
}


void TG_GRAPH::ScanSplitTree(FILE *fp)
{
 is_split=1;
 SplitTree.Scan(fp);
}



//it is assumed that dim is ok
void TG_GRAPH::ReadNBList(FILE *fp)
{
 int i,j,k,ret;
 char  zeile[200],*hilf;

 NBlist.Used()=dim;
 fgets(zeile,200,fp);
 for(i=1;i<=dim;i++)
  {  
   fgets(zeile,200,fp);
   fgets(zeile,200,fp);
   NBlist[i].Used()=0;
   NBwert[i].Used()=0;
   hilf=zeile;
   j=0;
   while(1)
    {
     while(isspace(hilf[0]))
      hilf++;
     ret=sscanf(hilf,"%d",&k);
     if(ret != 1)
      break;   
     NBlist[i][++NBlist[i].Used()]=k;
     while(isdigit(hilf[0]))
      hilf++;
     while(isspace(hilf[0]))
      hilf++;
     ret=sscanf(hilf,"%d",&k);
     if(ret != 1)
      break;   
     NBwert[i][++NBwert[i].Used()]=k;
     while(isdigit(hilf[0]))
      hilf++;
    }
  }
}




void TG_GRAPH::Plaziere()
{
 int i,j,k,l,m,n;
 VEKTOR < short >  dummy(dim);
 VEKTOR < short >  dummy2(dim);

 if(is_split == 0)
  {
   CompZshg_and_Plaz(dim,NBlist,x_coordinates,y_coordinates);
   max_tiefe=1;
   line_anz=0;
   split_tiefe.REALLOC(dim,dim);
   for(i=1;i<=dim;i++)
    for(j=1;j<=dim;j++)
     split_tiefe[i][j]=1;
  } 
 else
  {
   //berechne die Nachbarschaftslisten in SplitTree
   //und belege global_nr
   //Laufe zu diesem Zweck in wlr-Ordnung durch SplitTree
   //und ziehe dabei gleich die Trennlinien mit.

   line_anz=0;
   SplitTree.wlrStart();
   while(! SplitTree.IsLast())
    {
     SPLITINFO& SI1 = SplitTree.Next();
     SPLITINFO* SI2 = SplitTree.VaterVonNext();

     if(SI2 == NULL)
      {
       SI1.x1=SI1.y1=1;
       SI1.x2=SI1.y2=1000;
      }
     else
      {
       if(SI1 < (*SI2))
        {
         //d.h. SI1 linker Sohn
         if(SI1.tiefe % 2 == 0)
          {
           //=> teile senkrecht
           SI1.x1 = SI2->x1; 
           SI1.y1 = SI2->y1; 
           SI1.y2 = SI2->y2; 
           SI1.x2 = SI2->x1;
           SI1.x2 += (SI1.dim*(SI2->x2-SI2->x1)) / (SI2->dim);
           line_anz++;
           x1.ReAlloc(line_anz);
           x2.ReAlloc(line_anz);
           y1.ReAlloc(line_anz);
           y2.ReAlloc(line_anz);
           line_tiefe.ReAlloc(line_anz);
           line_tiefe[line_anz]=SI1.tiefe;
           x1[line_anz]=x2[line_anz]=SI1.x2;
           y1[line_anz]=SI1.y1;
           y2[line_anz]=SI1.y2;
          }
         else
          {
           //=>teile waagrecht ( linker Sohn nach oben)
           SI1.x1 = SI2->x1; 
           SI1.y1 = SI2->y1; 
           SI1.x2 = SI2->x2; 
           SI1.y2 = SI2->y1;
           SI1.y2 += (SI1.dim*(SI2->y2-SI2->y1)) / (SI2->dim);
           line_anz++;
           line_tiefe.ReAlloc(line_anz);
           line_tiefe[line_anz]=SI1.tiefe;
           x1.ReAlloc(line_anz);
           x2.ReAlloc(line_anz);
           y1.ReAlloc(line_anz);
           y2.ReAlloc(line_anz);
           y1[line_anz]=y2[line_anz]=SI1.y2;
           x1[line_anz]=SI1.x1;
           x2[line_anz]=SI1.x2;
          }
        }
       else
        {
         //d.h. rechter Sohn
         if(SI1.tiefe % 2 == 0)
          {
           //=> teile senkrecht
           SI1.x1 = SI2->x2;
           SI1.x1 += (SI1.dim*(SI2->x1-SI2->x2)) / (SI2->dim);
           SI1.y1 = SI2->y1; 
           SI1.x2 = SI2->x2; 
           SI1.y2 = SI2->y2; 
          }
         else
          {
           //=>teile waagrecht
           SI1.x2 = SI2->x2; 
           SI1.y2 = SI2->y2;
           SI1.x1 = SI2->x1;
           SI1.y1 = SI2->y2;
           SI1.y1 += (SI1.dim*(SI2->y1-SI2->y2)) / (SI2->dim);
          }
        }
      }   
     //Koordinaten sind festgelegt und evtl. neue Trennlinie
     //gezogen
     if(SI2 == NULL)
      {
       for(i=1;i<=dim;i++)
        {
         SI1.NBlist[i].Used()=NBlist[i].Used();
         for(j=1;j<=NBlist[i].Used();j++)
          SI1.NBlist[i][j]=NBlist[i][j];
         SI1.NBwert[i].Used()=NBwert[i].Used();
         for(j=1;j<=NBwert[i].Used();j++)
          SI1.NBwert[i][j]=NBwert[i][j];
        }
       for(i=1;i<=SI1.dim;i++)
        SI1.global_nr[i]=i;
      }
     else
      {
       dummy.Clear();
       for(i=1;i<=SI2->dim;i++)
        {
         for(j=1;j<=SI2->NBlist[i].Used();j++)
          {
           dummy[i] += SI2->NBwert[i][j];
           dummy[SI2->NBlist[i][j]] += SI2->NBwert[i][j]; 
          }
        }
       //dummy enthaelt jetzt die Knotengrade des Vaters
       k=0;
       VEKTOR < short >* spli;
       if(SI1 < (*SI2))
        spli=&(SI2->split_left);
       else
        spli=&(SI2->split_right);   
       for(i=1;i<=spli->Used();i++)
        {
         for(j=1;j<=SI2->dim;j++)
          {
           if(dummy[j] == (*spli)[i])
            {
             SI1.global_nr[++k]=SI2->global_nr[j];  
             dummy2[k]=j;
            } 
          }
        }

       //dummy2[k] ist die Knotennummer in SI2 
       for(i=1;i<=SI1.dim;i++)
        {
         SI1.NBlist[i].Used()=0;
         SI1.NBwert[i].Used()=0;
        }
       for(i=1;i<=SI1.dim;i++)
        { 
         for(k=1;k<=SI2->NBlist[dummy2[i]].Used();k++)
          {
           for(j=1;j<=SI1.dim;j++)
            if(dummy2[j] == SI2->NBlist[dummy2[i]][k])
             {
              SI1.NBlist[i][++SI1.NBlist[i].Used()] = j;
              SI1.NBwert[i][++SI1.NBwert[i].Used()] = 
                SI2->NBwert[dummy2[i]][k];
             }
          } 
        }
      }
    } //Ende von while 


   //belege jetzt split_tiefe

   max_tiefe=0;
   for(i=1;i<=dim;i++)
    split_tiefe[i].Clear();
   SplitTree.lrwStart();
   while(! SplitTree.IsLast())
    {
     SPLITINFO& SI1 = SplitTree.Next();

     if(SI1.tiefe > max_tiefe)
      max_tiefe=SI1.tiefe;
     for(i=1;i<=SI1.dim;i++)
      {
       for(j=1;j<=SI1.NBlist[i].Used();j++)
        {
         //SI1.global_nr[i] ist verbunden mit 
         //SI1.global_nr[SI1.NBlist[i][j]]
         if(split_tiefe[SI1.global_nr[i]][SI1.global_nr[SI1.NBlist[i][j]]]==0)
          {
           split_tiefe[SI1.global_nr[i]][SI1.global_nr[SI1.NBlist[i][j]]] =
             SI1.tiefe;
           split_tiefe[SI1.global_nr[SI1.NBlist[i][j]]][SI1.global_nr[i]] =
             SI1.tiefe;
          }    
        }
      }
    }
   //Durchlaufe die Blaetter von SplitTree und plaziere diese.


   SplitTree.LeafStart();
   while(! SplitTree.IsLast())
    {
     SPLITINFO& SI1 = SplitTree.Next();
     CompZshg_and_Plaz(SI1.dim,SI1.NBlist,SI1.x_coordinates,
                       SI1.y_coordinates);
    }


   //rechne die Koordinaten der Blaetter jetzt um,
   //und belege x_coordinates und y_coordinates

   SplitTree.LeafStart();
   while(! SplitTree.IsLast())
    {
     SPLITINFO& SI1 = SplitTree.Next();
     for(i=1;i<=SI1.dim;i++)
      {
       j=SI1.x_coordinates[i];
       k=SI1.y_coordinates[i];
       j=((SI1.x2-SI1.x1)*j)/1000;
       k=((SI1.y2-SI1.y1)*k)/1000;
       x_coordinates[SI1.global_nr[i]] = SI1.x1+j;
       y_coordinates[SI1.global_nr[i]] = SI1.y1+k; 
      }
    }
  }
}



/**************************************************************/

int CONN_TEST::IsZshg(ARRAY < VEKTOR < short > >& NB,int anz,int flag)
{
 int i,j,k;
 dim = anz;
 VEKTOR < short > keller;

if(flag)
 {
 printf("Hier IsZshg\n");
 for(i=1;i<=dim;i++)
  {
   printf("%d : ",i);
   for(j=1;j<=NB[i].Used();j++)
    printf("%d ",NB[i][j]);
   printf("\n"); 
  }

}
 BITVEK bits;
 bits.Init(dim);
 bits.Clear();
 keller.Init(dim);
 keller.Used() = 1;
 keller[1] = 1;
 bits.Set(1);
 k = 1;
 while(keller.Used() > 0)
  {
   i = keller[keller.Used()];
   if(flag)
    {
     printf("i=%d\n",i);
    }
   keller.Used()--;
   for(j=1;j<=NB[i].Used();j++)
    {  
     if(bits[NB[i][j]]==0)
      {
      if(flag)
       printf("bits.Set(%d)\n",NB[i][j]);

       bits.Set(NB[i][j]);
       k++;
       if(k==dim)
        return(1);
       keller[++keller.Used()] = NB[i][j];
      }
    }
  }
 if(k < dim)
  return(0);
 return(1);

}



/**************************************************************/


void BrFiSe::Init(ARRAY < VEKTOR < short > >& A,int _dim)
{
 dim = _dim;
 NB = &A;
 bits.ReAlloc(dim);
 bits.Clear();
 levels.REALLOC(dim,dim);
}


//berechne die levels bis zum Abstand maxabst
void BrFiSe::ComputeLevels(int a,int maxabst)
{
 int i,j,k,l;

 levels[1][1] = a;
 levels[1].Used() = 1;
 bits.Clear();
 bits.Set(a);
 for(i=2;i<=dim;i++)
  levels[i].Used() = 0;
 i = 1;
 while((i < dim)&&(i <= maxabst)&&(levels[i].Used() > 0))
  {
   for(j=1;j<=levels[i].Used();j++)
    {
     for(k=1;k<=(*NB)[levels[i][j]].Used();k++)
      {
       if(bits[(*NB)[levels[i][j]][k]] == 0)
        {
         bits.Set((*NB)[levels[i][j]][k]);
         levels[i+1][++levels[i+1].Used()] = (*NB)[levels[i][j]][k];
        }
      }
    } 
   i++;  
  }
}


void BrFiSe::ComputeLevels(int a)
{
 int i,j,k,l;

 levels[1][1] = a;
 levels[1].Used() = 1;
 bits.Clear();
 bits.Set(a);
 for(i=2;i<=dim;i++)
  levels[i].Used() = 0;
 i = 1;
 while((i < dim)&&(levels[i].Used() > 0))
  {
   for(j=1;j<=levels[i].Used();j++)
    {
     for(k=1;k<=(*NB)[levels[i][j]].Used();k++)
      {
       if(bits[(*NB)[levels[i][j]][k]] == 0)
        {
         bits.Set((*NB)[levels[i][j]][k]);
         levels[i+1][++levels[i+1].Used()] = (*NB)[levels[i][j]][k];
        }
      }
    } 
   i++;  
  }
}


int BrFiSe::IsMinAbstand(int a,int b,int abst)
{
 int i,j,k,l;

 if(abst == 1)
  return(1);
  
 levels[1][1] = a;
 levels[1].Used() = 1;
 bits.Clear();
 bits.Set(a);
 for(i=2;i<=dim;i++)
  levels[i].Used() = 0;
 i = 1;
 while((i < dim)&&(levels[i].Used() > 0))
  {
   for(j=1;j<=levels[i].Used();j++)
    {
     for(k=1;k<=(*NB)[levels[i][j]].Used();k++)
      {
       if(bits[(*NB)[levels[i][j]][k]] == 0)
        {
         bits.Set((*NB)[levels[i][j]][k]);
         levels[i+1][++levels[i+1].Used()] = (*NB)[levels[i][j]][k];
         if((*NB)[levels[i][j]][k] == b)
          return(0);
        }
      }
    } 
   i++;  
   if(i >= abst)
    return(1); 
  }
 return(1); 
}



int BrFiSe::Abstand(int a,int b)
{
 int i,j,k,l;

 levels[1][1] = a;
 levels[1].Used() = 1;
 bits.Clear();
 bits.Set(a);
 for(i=2;i<=dim;i++)
  levels[i].Used() = 0;
 i = 1;
 while((i < dim)&&(levels[i].Used() > 0))
  {
   for(j=1;j<=levels[i].Used();j++)
    {
     for(k=1;k<=(*NB)[levels[i][j]].Used();k++)
      {
       if(bits[(*NB)[levels[i][j]][k]] == 0)
        {
         bits.Set((*NB)[levels[i][j]][k]);
         levels[i+1][++levels[i+1].Used()] = (*NB)[levels[i][j]][k];
         if((*NB)[levels[i][j]][k] == b)
          return(i);
        }
      }
    } 
   i++;  
  }
 return(-1);
}


/**************************************************************/

//Eingabe ist ein class2-Graph
int CRITICAL_TEST::IsCritical(ARRAY < VEKTOR < short > >& NB)
{
 int i,j,k,l;

 dim = NB.Used();
 maxgrad = 0;
 for(i=1;i<=dim;i++)
  if(NB[i].Used() > maxgrad)
   maxgrad = NB[i].Used();
 testNB.REALLOC(dim,dim);

 //man braucht mind. maxgrad+1 Farben, um die Kanten von NB
 //zu faerben.

 int kant_anz = 0;
 for(i=1;i<=dim;i++)
  kant_anz += NB[i].Used();

 testNB.Used() = dim;
 for(i=1;i<=kant_anz;i++)
  {
   //kopiere NB ohne die i-te Kante nach testNB
   j = 0;
   for(k=1;k<=dim;k++)
    {
     testNB[k].Used()=0;
	 for(l=1;l<=NB[k].Used();l++)
	  {
       j++;
	   if(j != i)
	    testNB[k][++testNB[k].Used()] = NB[k][l];
      }
	}
   if(a_col_edge.ChromaticIndex(testNB) != maxgrad)
    return(0);
  }
 return(1);
}


/**************************************************************/


void COLOR_EDGES::FREE()
{
 lauf.FREE();
 kantenfarben.FREE();
 knotenfarben.FREE();
 kantenliste.FREE();
 Mat.FREE();
 NB.FREE();
 bits.FREE();
 levels.FREE(); 
}


int COLOR_EDGES::ChromaticIndex(ARRAY < VEKTOR < short > >& NBlist)
{
 int i,j,k,l;
 int farbanz=0;

 FREE();
 dim = NBlist.Dim();
 NB.REALLOC(dim,dim);
 for(i=1;i<=dim;i++)
  NB[i].Used() = 0;
 for(i=1;i<=dim;i++)
  {
   for(j=1;j<=NBlist[i].Used();j++)
    {
     k = NBlist[i][j];
     NB[i][++NB[i].Used()] = k;
     NB[k][++NB[k].Used()] = i;
    }
  }	
 bits.ReAlloc(dim);
 levels.REALLOC(dim,dim);
 Mat.REALLOC(dim,dim);
 for(i=1;i<=dim;i++)
  Mat[i].Clear();
 maxgrad = 0;
 for(i=1;i<=dim;i++)
  if(NB[i].Used() > maxgrad)
   maxgrad = NB[i].Used();
 kanten = 0;
 for(i=1;i<=dim;i++)
  kanten += NBlist[i].Used();
 lauf.ReAlloc(kanten);
 kantenfarben.ReAlloc(kanten);
 knotenfarben.REALLOC(dim,maxgrad+1);
 kantenliste.REALLOC(kanten,2);

 int K=1; 
 while(NB[K].Used() != maxgrad)
  K++;
 
 for(i=1;i<=dim;i++)
  knotenfarben[i].Clear();
 for(i=1;i<=maxgrad;i++)
  knotenfarben[K][i] = 1;
 for(i=1;i<=maxgrad;i++)
  knotenfarben[NB[K][i]][i] = 1;

 //fuelle jetzt die Kantenliste
 kantenliste.Used() = 0;
 int a = K;
 levels[1][1] = a;
 levels[1].Used() = 1;
 bits.Clear();
 bits.Set(a);
 for(i=2;i<=dim;i++)
  levels[i].Used() = 0;
 i = 1;
 while(levels[i].Used() > 0)
  {
   for(j=1;j<=levels[i].Used();j++)
    {
     for(k=1;k<=NB[levels[i][j]].Used();k++)
      {
       if((i > 1)&&(Mat[levels[i][j]][NB[levels[i][j]][k]] == 0))
        {
         kantenliste.Used()++;
	 int m = kantenliste.Used();
	 kantenliste[m][1] = levels[i][j];
	 kantenliste[m][2] = NB[levels[i][j]][k];
	 Mat[levels[i][j]][NB[levels[i][j]][k]] = 1;
	 Mat[NB[levels[i][j]][k]][levels[i][j]] = 1;
	}
       if(bits[NB[levels[i][j]][k]] == 0)
        {
         bits.Set(NB[levels[i][j]][k]);
         levels[i+1][++levels[i+1].Used()] = NB[levels[i][j]][k];
	 Mat[levels[i][j]][NB[levels[i][j]][k]] = 1;
	 Mat[NB[levels[i][j]][k]][levels[i][j]] = 1;
        }
      }
    } 
   i++;  
  }
 for(i=1;i<=dim;i++)
  Mat[i].Clear();

 if(kantenliste.Used() != kanten)
  {
   fprintf(stderr,"kantenliste.Used() < kanten !!\n");
   exit(0); 
  }


 int tiefe=1;
 lauf[tiefe]=0;
 kantenfarben[1]=0;
 while(tiefe)
  {
   if(kantenfarben[tiefe])
    {
     //Kante loeschen
     knotenfarben[kantenliste[tiefe][1]][kantenfarben[tiefe]] = 0;
     knotenfarben[kantenliste[tiefe][2]][kantenfarben[tiefe]] = 0;
     kantenfarben[tiefe] = 0;
    }
   if(lauf[tiefe]==maxgrad)
     tiefe--;
   else
    {
     lauf[tiefe]++;
     int col_is_poss = 1;
     if(knotenfarben[kantenliste[tiefe][1]][lauf[tiefe]])
      col_is_poss = 0;
     if(knotenfarben[kantenliste[tiefe][2]][lauf[tiefe]])
      col_is_poss = 0;
     if(col_is_poss)
      {
       kantenfarben[tiefe] = lauf[tiefe];
       knotenfarben[kantenliste[tiefe][1]][lauf[tiefe]] = 1;
       knotenfarben[kantenliste[tiefe][2]][lauf[tiefe]] = 1;
       if(tiefe == kantenliste.Used())
        return(maxgrad);
       else
        {
         tiefe++;
         lauf[tiefe] = 0;
         kantenfarben[tiefe] = 0;
        }
      }
    }
  }

 return(maxgrad+1);
}

/**************************************************************/


SPLITINFO::SPLITINFO(int _dim)
{
 dim=_dim;
 NBlist.REALLOC(dim,dim);
 NBwert.REALLOC(dim,dim);
 global_nr.ReAlloc(dim);
 x_coordinates.ReAlloc(dim);
 y_coordinates.ReAlloc(dim);
 split_left.ReAlloc(dim);
 split_right.ReAlloc(dim);
}



void SPLITINFO::Init(int _dim)
{
 dim=_dim;
 NBlist.REALLOC(dim,dim);
 NBwert.REALLOC(dim,dim);
 global_nr.ReAlloc(dim);
 x_coordinates.ReAlloc(dim);
 y_coordinates.ReAlloc(dim);
 split_left.ReAlloc(dim);
 split_right.ReAlloc(dim);
}



void SPLITINFO::Print(FILE *fp)
{
 int i;

 if(is_split == 1)
  fprintf(fp,"tiefe=%d dim=%d is_split=1 f_c_nr=%d l_dim=%d\n",
              tiefe,dim,first_col_nr,l_dim);
 else
  fprintf(fp,"tiefe=%d dim=%d is_split=0 f_c_nr=%d\n",
              tiefe,dim,first_col_nr);
 if(is_split == 1)
  { 
   fprintf(fp,"split_left=\n");
   for(i=1;i<=split_left.Used();i++)
    fprintf(fp,"%d ",split_left[i]);
   fprintf(fp,"\n");               
   fprintf(fp,"split_right=\n");
   for(i=1;i<=split_right.Used();i++)
    fprintf(fp,"%d ",split_right[i]);
   fprintf(fp,"\n");   
  }             
}


static void ERR(int flag)
{
 fprintf(stderr,"%d : wrong file-format in SPLITINFO::Scan\n",flag);
 exit(0); 
}


static int ReadNextLine(char* z,FILE* fp)
{
 if(fgets(z,100,fp) == NULL)
  return(0);
 return(1); 
}



int SPLITINFO::Scan(FILE *fp)
{
 int ret,i,j,k,l,m,n,o;
 char zeile[100],*hilf;

 while(1)
  {
   i=ReadNextLine(zeile,fp);
   if(i==0)
    return(0);
   i=sscanf(zeile,"tiefe=%d",&j);
   if(i==1)
    break; 
  } 
 ret=sscanf(zeile,"tiefe=%d dim=%d is_split=%d",&i,&k,&j);
 if(ret != 3) ERR(1);
 if(j==1)
  {
   ret=sscanf(zeile,"tiefe=%d dim=%d is_split=%d f_c_nr=%d l_dim=%d\n",
                    &i,&o,&j,&k,&l);
   if(ret != 5)ERR(2); 
   tiefe=i;
   is_split=j;
   first_col_nr=k;
   l_dim=l;
   dim=o;
  }
 else
  {
   ret=sscanf(zeile,"tiefe=%d dim=%d is_split=%d f_c_nr=%d\n",&i,&o,&j,&k);
   if(ret != 4)ERR(3);  
   tiefe=i;
   is_split=j;
   first_col_nr=k;                                         
   dim=o;
  }
 Init(dim); 
 if(is_split == 1)
  {
   ReadNextLine(zeile,fp);
   ReadNextLine(zeile,fp);
   split_left.Used()=0;
   hilf=zeile;
   while(1) 
    {
     while(isspace(hilf[0]))
      hilf++;
     ret=sscanf(hilf,"%d",&o);
     if(ret != 1)break;
     split_left.ReAlloc(split_left.Used()+1);
     split_left[++split_left.Used()]=o;
     while(isdigit(hilf[0]))
      hilf++; 
    }
   ReadNextLine(zeile,fp);
   ReadNextLine(zeile,fp);
   split_right.Used()=0;
   hilf=zeile;
   while(1) 
    {
     while(isspace(hilf[0]))
      hilf++;
     ret=sscanf(hilf,"%d",&o);
     if(ret != 1)break;
     split_right.ReAlloc(split_right.Used()+1);
     split_right[++split_right.Used()]=o;
     while(isdigit(hilf[0]))
      hilf++; 
    }
  }  
 return(1); 
}



int SPLITINFO::operator==(SPLITINFO& I)
{
 if(is_split != I.is_split)
  return(0);
 if(is_split == 1)
  {   
   if((first_col_nr==I.first_col_nr)&&
      (l_dim==I.l_dim))
    return(1);
   else
    return(0);
  }
 if(is_split==0)
  {
   if(first_col_nr==I.first_col_nr)
    return(1);
   else
    return(0); 
  }  
}               



int SPLITINFO::operator>(SPLITINFO& I)
{
 if((is_split==0)&&(I.is_split==0)) 
  {
   if(first_col_nr > I.first_col_nr)
    return(1);
   else
    return(0);
  }
 if(dim > I.dim)
  {
   if(I.first_col_nr > first_col_nr+l_dim-1)
    return(0);
   else
    return(1);
  }
 if(dim < I.dim)
  {
   if(first_col_nr > I.first_col_nr+I.l_dim-1)
    return(1);
   else
    return(0);
  }
 
}


int SPLITINFO::operator<(SPLITINFO& I)
{
 if((is_split==0)&&(I.is_split==0)) 
  {
   if(first_col_nr > I.first_col_nr)
    return(0);
   else
    return(1);
  }
 if(dim > I.dim)
  {
   if(I.first_col_nr > first_col_nr+l_dim-1)
    return(1);
   else
    return(0);
  }
 if(dim < I.dim)
  {
   if(first_col_nr > I.first_col_nr+I.l_dim-1)
    return(0);
   else
    return(1);
  }
 
}


void SPLITINFO::FREE()
{
 NBlist.FREE();
 NBwert.FREE();
 global_nr.FREE();
 x_coordinates.FREE();
 y_coordinates.FREE();
 split_left.FREE();
 split_right.FREE();
}


void SPLITINFO::operator=(SPLITINFO& Q)
{
 int i,j;

 FREE();
 Init(Q.dim);
 tiefe=Q.tiefe;
 first_col_nr=Q.first_col_nr;
 l_dim=Q.l_dim;
 is_split=Q.is_split;
 if((Q.split_left.Used() > 0)&&(is_split))
  split_left.ReAlloc(Q.split_left.Used());
 if((Q.split_right.Used() > 0)&&(is_split))
  split_right.ReAlloc(Q.split_right.Used());
 if(is_split)
  {
   split_left.Used()=Q.split_left.Used();
   for(i=1;i<=split_left.Used();i++)
    split_left[i]=Q.split_left[i];
   split_right.Used()=Q.split_right.Used();
   for(i=1;i<=split_right.Used();i++)
    split_right[i]=Q.split_right[i];
  }  
}


/**************************************************************/



void ReadParameters(char& go,char& S50,char& S_MI,char& S_MA,char& PRE_C,char &REC)
{
 int ret,i;
 FILE *in;
 char zeile[100],zeile2[100];

 in=fopen("FLAGS","r");
 if(in == NULL)
  {
   fprintf(stderr,"no file 'FLAGS' found\n");
   exit(0); 
  }


 //VERBOSE einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("VERBOSE",zeile);

 if(ret != 7)
  {
   fprintf(stderr,"VERBOSE not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+7];

 ret=sscanf(zeile2,"%d",&i);
 VERBOSE=i;
 if((ret == 0) ||
    (! ((VERBOSE==0) || (VERBOSE==1))))
  {
   fprintf(stderr,"VERBOSE = ?\n");
   exit(0);
  }


 //HASH_LENGTH einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("HASH_LENGTH",zeile);

 if(ret != 11)
  {
   fprintf(stderr,"HASH_LENGTH not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+11];

 ret=sscanf(zeile2,"%d",&i);
 HASH_LENGTH=i;
 if((ret == 0)||(HASH_LENGTH <= 0))
  {
   fprintf(stderr,"HASH_LENGTH = ?\n");
   exit(0);
  }


 //GALE_LIMIT einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("GALE_LIMIT",zeile);

 if(ret != 10)
  {
   fprintf(stderr,"GALE_LIMIT not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+10];

 ret=sscanf(zeile2,"%d",&i);
 GALE_LIMIT=i;
 if((ret == 0)||(GALE_LIMIT <= 0))
  {
   fprintf(stderr,"GALE_LIMIT = ?\n");
   exit(0);
  }


 //SPLIT_KLEIN einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("SPLIT_KLEIN",zeile);

 if(ret != 11)
  {
   fprintf(stderr,"SPLIT_KLEIN not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+11];

 ret=sscanf(zeile2,"%d",&i);
 SPLIT_KLEIN=i;
 if((ret == 0)||
    ((SPLIT_KLEIN != 0)&&(SPLIT_KLEIN != 1)))
  {
   fprintf(stderr,"SPLIT_KLEIN = ?\n");
   exit(0);
  }


 //SPLIT_MIN einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("SPLIT_MIN",zeile);

 if(ret != 9)
  {
   fprintf(stderr,"SPLIT_MIN not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+9];

 ret=sscanf(zeile2,"%d",&i);
 SPLIT_MIN=i;
 if((ret == 0)||
    (SPLIT_MIN <= 0))
  {
   fprintf(stderr,"SPLIT_MIN = ?\n");
   exit(0);
  }


 //GO_IMPL einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("GO_IMPL",zeile);

 if(ret != 7)
  {
   fprintf(stderr,"GO_IMPL not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+7];

 ret=sscanf(zeile2,"%d",&i);
 go=i;
 if((ret == 0)||
    ((go != 0)&&(go != 1)))
  {
   fprintf(stderr,"GO_IMPL = ?\n");
   exit(0);
  }


 //RECONSTRUCT_ALL einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("RECONSTRUCT_ALL",zeile);

 if(ret != 15)
  {
   fprintf(stderr,"RECONSTRUCT_ALL not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+15];

 ret=sscanf(zeile2,"%d",&i);
 REC=i;
 if((ret == 0)||
    ((REC != 0)&&(REC != 1)))
  {
   fprintf(stderr,"RECONSTRUCT_ALL = ?\n");
   exit(0);
  }


 //PRECOMPUTE_SPLITS einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("PRECOMPUTE_SPLITS",zeile);

 if(ret != 17)
  {
   fprintf(stderr,"PRECOMPUTE_SPLITS not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+17];

 ret=sscanf(zeile2,"%d",&i);
 PRE_C=i;
 if((ret == 0)||
    ((PRE_C != 0)&&(PRE_C != 1)))
  {
   fprintf(stderr,"PRECOMPUTE_SPLITS = ?\n");
   exit(0);
  }


 //SPLIT einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }

 ret=strspn("SPLIT_50_50",zeile);
 if(ret == 11)
  { S50=1; S_MI=0; S_MA=0; }

 ret=strspn("SPLIT_MIDDLE",zeile);
 if(ret == 12)
  { S50=0; S_MI=1; S_MA=0; }

 ret=strspn("SPLIT_MAX",zeile);
 if(ret == 9)
  { S50=0; S_MI=0; S_MA=1; }


 //SHIFT_PARTITIONS einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("SHIFT_PARTITIONS",zeile);

 if(ret != 16)
  {
   fprintf(stderr,"SHIFT_PARTITIONS not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+16];

 ret=sscanf(zeile2,"%d",&i);
 SHIFT_PARTITIONS=i;
 if((ret == 0)||
    ((SHIFT_PARTITIONS != 0)&&(SHIFT_PARTITIONS != 1)&&
     (SHIFT_PARTITIONS != 2)))
  {
   fprintf(stderr,"SHIFT_PARTITIONS = ?\n");
   exit(0);
  }


 //STEPS_TO_SAVE einlesen

 if(fgets(zeile,100,in)==NULL)
  {
   fprintf(stderr,"wrong format of file 'FLAGS'\n");
   exit(0);
  }
 ret=strspn("STEPS_TO_SAVE",zeile);

 if(ret != 13)
  {
   fprintf(stderr,"STEPS_TO_SAVE not found in file 'FLAGS'\n");
   exit(0);
  } 

 for(i=0;i<80;i++)
  zeile2[i]=zeile[i+13];

 ret=sscanf(zeile2,"%d",&i);
 STEPS_TO_SAVE=i;
 if(ret == 0)
  {
   fprintf(stderr,"STEPS_TO_SAVE = ?\n");
   exit(0);
  }
 fclose(in);  
}


/**************************************************************/

int GIRTH_TEST::IsPossiblePart(VEKTOR < short >& qvek, int g)
{
 int i,j,k,l,s,min,schicht_anz;
 vek = qvek;
 GIRTH = g;

 if(vek.Used() <= 1)
  return(1);
 s = 0;
 for(i=1;i<=vek.Used();i++)
  s += vek[i];
 //s Knoten vom Grad > 0

 min = 0;
 //es werden mind. min Knoten gebraucht
 
 schicht_anz = (GIRTH-1)/2;
 schicht_anz++;
 schichten.REALLOC(schicht_anz,s);
 for(i=1;i<=schicht_anz;i++)
  schichten[i].Used() = 0;

 int maxkettenl;
 if(GIRTH % 2 == 0)
  maxkettenl = GIRTH-1;
 else
  maxkettenl = GIRTH;

 int kettenl;
 //es muss mind. eine Kette aus Knoten max. Grades mit Laenge
 //kettenl existieren.
 int maxnachb = 0;
 //Anzahl Kanten, die von Knoten nicht maximalen Grades ausgehen
 for(i=1;i<vek.Used();i++)
  maxnachb += i * vek[i];
 double mind;
 //Mindestanzahl der Bindungen von Knoten max. Grades zu anderen Knoten


 kettenl = 0;
 do {
     kettenl++;
     i = ( kettenl * vek.Used() ) - (2*(kettenl-1));
     //von einer Kette der Laenge kettenl gehen i Kanten nach aussen
     mind = i;
	    mind /= kettenl;
	    mind *= vek[vek.Used()];
    }
 while((kettenl < maxkettenl)&&
       (mind > maxnachb)&&
	   (kettenl < vek[vek.Used()]));	
  
 vek[vek.Used()] -= kettenl;
 schichten[1].Used() = 1;
 min = kettenl;
 if(kettenl > 1)
  {
   if(kettenl==2)
    schichten[1][1] = vek.Used()-1;
   else 
    schichten[1][1] = vek.Used()-2;
  } 
 else 
  schichten[1][1] = vek.Used();
 kettenl--;
 
 for(i=2;;i++)
  {
   //Anfangsbelegung in Schicht i
   if(kettenl == 0) break;
   if((kettenl==2)||(kettenl==1))
    schichten[i][++schichten[i].Used()] = vek.Used()-1;
   else	
    schichten[i][++schichten[i].Used()] = vek.Used()-2;
   kettenl--;
   if(kettenl == 0) break;
   if((kettenl==2)||(kettenl==1))
    schichten[i][++schichten[i].Used()] = vek.Used()-1;
   else	
    schichten[i][++schichten[i].Used()] = vek.Used()-2;
   kettenl--;
  }

 for(i=2;i<=schicht_anz;i++)
  { 
   //fuelle Schicht i
   if(schichten[i-1].Used() == 0)
    return(1);
   for(j=1;j<=schichten[i-1].Used();j++)
    {
     //durchlaufe Elemente der Schicht i-1
     if(min+schichten[i-1][j] > s)
      return(0);
     //suche schichten[i-1][j] Nachbarn
     for(k=1;k<=schichten[i-1][j];k++)
      {
       l = 1;
       while(vek[l]==0)l++;
       if(l > 1)
         schichten[i][++schichten[i].Used()] = l-1;
       min++;
       vek[l]--; 
      }
    }
  }

 if((GIRTH%2 == 0)&&(schichten[schicht_anz].Used() > 0))
  {
   i=schichten[schicht_anz][1];
   for(j=2;j<=schichten[schicht_anz].Used();j++)
    if(schichten[schicht_anz][j] > i)
     i = schichten[schicht_anz][j];
   if(min + i > s)
    return(0);

   i = 0;
   for(j=1;j<=schichten[schicht_anz].Used();j++)
    i += schichten[schicht_anz][j];
	
   //in der aeussersten Schicht gehen i Kanten nach aussen	
   while(i > 0)
    {
     j = vek.Used();
   	 while((j > 0)&&(vek[j]==0))j--;
	    if(j==0)
	     return(0);
	    i -= j;
	    vek[j]--;
	    min++;
     if(min > s)
      return(0);
	   }
  }

 return(1); 
}




/**************************************************************/



int f_0(int k,int t)
{
 int i,j,l,m,f0;

 f0 = 0;
 if(t % 2 == 1)
  {
   j = 1;
   for(i=1;i<=((t-1)/2);i++)
    {
     f0 += j;
     j *= (k-1);
    }
   f0 *= k;
   f0++;
  }
 else
  {
   j = 1;
   for(i=1;i<=(t/2);i++)
    {
     f0 += j;
     j *= (k-1);
    }
   f0 *= 2;
  }
 return(f0);
}

/**************************************************************/


#define HDD_ANZ 20000

HDD_GIRTH::HDD_GIRTH()
{
 HDDtafel = NULL;
}

HDD_GIRTH::~HDD_GIRTH()
{
 if(HDDtafel)
  {
   for(int i=1;i<=HDD_ANZ;i++)
     delete HDDtafel[i];
   delete[] HDDtafel;
  } 
}



void HDD_GIRTH::Init(int K_N,int GI_N)
{
 K_nr = K_N;
 Girth_nr = GI_N;
}


void HDD_GIRTH::WriteHDDtafel()
{
 int kno_nr;
 int i,j,k,l,m,ret,werte;
 FILE *out;
 char name[200];

 werte=0;
 for(i=1;i<=HDD_ANZ;i++)
  if(HDDtafel[i]->Anz() > 0)
    werte++;

 sprintf(name,"./DATA/K%d/GIRTH%d/hashtafel",K_nr,Girth_nr);
 out = fopen(name,"w");
 if(out==NULL)
  {
   fprintf(stderr,"couldn't open %s for writing\n",name);
   exit(0);
  }
 fprintf(out,"%d\n",werte);
 for(i=1;i<=HDD_ANZ;i++)
  {
   if(HDDtafel[i]->Anz() > 0)
    {
     fprintf(out,"%d %d ",i,HDDtafel[i]->Anz());
     HDDtafel[i]->Start();
     while(! HDDtafel[i]->IsLast())
      {
       j = HDDtafel[i]->GetNext(kno_nr);
       fprintf(out,"%d %d ",j,kno_nr);
      }
     fprintf(out,"\n"); 
    }
  }

 fprintf(out,"\n"); 
 fclose(out);
}


void HDD_GIRTH::ReadHDDtafel()
{
 int i,j,k,l,m,ret,werte,kn;
 FILE *in;
 char name[200];

 if(HDDtafel)
  {
   for(i=1;i<=HDD_ANZ;i++)
    delete HDDtafel[i];
   delete[] HDDtafel;
   HDDtafel = NULL;
  }
 HDDtafel = new LIST_BASE<int>*[HDD_ANZ+1];  
 for(i=1;i<=HDD_ANZ;i++)
  HDDtafel[i] = new LIST_BASE < int >;

 sprintf(name,"./DATA/K%d/GIRTH%d/hashtafel",K_nr,Girth_nr);
 in = fopen(name,"r");
 if(in == NULL)
  {
   fprintf(stderr,"couldn't open %s for reading\n",name);
   exit(0); 
  }
 ret = fscanf(in,"%d",&werte);
 if(ret != 1)
  {
   fprintf(stderr,"couldn't read number of different hash-values\n");
   exit(0);
  }
 for(i=1;i<=werte;i++)
  {
   ret = fscanf(in,"%d",&j);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read hash-value number %d\n",i);
     exit(0);
    }
   if((j > HDD_ANZ)||(j < 1))
    {
     fprintf(stderr,"wrong hash-value\n");
     exit(0);
    }
   ret = fscanf(in,"%d",&k);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read number of entries for hash-value number %d\n",i);
     exit(0);
    }
   for(l=1;l<=k;l++)
    {
     ret = fscanf(in,"%d",&m);
     if(ret != 1)
      {
       fprintf(stderr,"couldn't read entry %d for hash-value number %d\n",l,i);
       exit(0);
      }
     ret = fscanf(in,"%d",&kn);
     if(ret != 1)
      {
       fprintf(stderr,"couldn't read %d-th number of vertices for hash-value number %d\n",l,i);
       exit(0);
      }

     HDDtafel[j]->Insert(m,kn);
    }
  }
 fclose(in);
}



void HDD_GIRTH::InsertHDD(int idx,int wert,int dim)
{
 HDDtafel[idx]->Insert(wert,dim);
}




void HDD_GIRTH::ReadHDD_part(FILE *fp,int startpos)
{
 int i,j,ret,max;

 ret = fseek(fp,startpos,SEEK_SET);
 if(ret != 0)
  {
   fprintf(stderr,"error in fseek in HDD_GIRTH::ReadHDD_part\n");
   exit(0);
  }

 //Format: 'maxgrad' part[1],...,part[maxgrad] 'girth'

 ret = fscanf(fp,"%d",&i);
 if(ret != 1)
  {
   fprintf(stderr,"couldn't read maxgrad in HDD_GIRTH::ReadHDD_part\n");
   exit(0);
  }
 max = i;
 HDD_part.ReAlloc(max);
 for(j=1;j<=max;j++)
  {
   ret = fscanf(fp,"%d",&i);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read HDD_part[%d] in HDD_GIRTH::ReadHDD_part\n",j);
     exit(0);
    }
   HDD_part[j] = i;
  }
 HDD_part.Used() = max; 
 ret = fscanf(fp,"%d",&i);
 if(ret != 1)
  {
   fprintf(stderr,"couldn't read HDD_girth in HDD_GIRTH::ReadHDD_part\n");
   exit(0);
  }
 HDD_girth = i;
}



int HDD_GIRTH::IsPossiblePartition(VEKTOR<short>& bvek)
{
 int kn,i,j,k,hashwert,kn_nr;
 char name[200];
 FILE *db;
 int mal[10];

 mal[0] = 533;mal[1] = 23; mal[2] = 8923; mal[3] = 789; mal[4] = 1111; 
 mal[5] = 2734; mal[6] = 231; mal[7] = 8888; mal[8] = 9090; mal[9] = 77;

 kn = 0;
 for(j=1;j <= bvek.Used();j++)
   kn += bvek[j];

   sprintf(name,"./DATA/K%d/GIRTH%d/vert%d",K_nr,Girth_nr,kn);
   db = fopen(name,"r");
   if(db == NULL)
    {
     fprintf(stderr,"couldn't open %s for reading\n",name);
     exit(0);
    }
   hashwert = 0;
   for(i=1;i<=bvek.Used();i++)
    hashwert += bvek[i] * mal[i % 10];
   hashwert = hashwert % HDD_ANZ;
   if(hashwert < 0)
    hashwert *= -1;
   hashwert++;
 
   HDDtafel[hashwert]->Start();
   HDD_WEITER_GI:
   while(! HDDtafel[hashwert]->IsLast())
    {
     j = HDDtafel[hashwert]->GetNext(kn_nr);
     if(kn_nr == kn)
      {
       ReadHDD_part(db,j);
       k = 1;
       for(i=1;i<=HDD_part.Used();i++)
        if(HDD_part[i] != bvek[i])
         { k = 0; break; }
       if(k == 1)
        { fclose(db); return(HDD_girth); } 
       else
        goto HDD_WEITER_GI;
      }
     else
      goto HDD_WEITER_GI;   
    }

   fclose(db); return(0);  
}

/**************************************************************/

HDD_GIRTH_DATABASE::HDD_GIRTH_DATABASE()
{
 HDDtafel = NULL;
 write_st_gi.SetAb0();
 write_st_gi.Init(50);
 graph_anz_gi.SetAb0();
 graph_anz_gi.Init(50);
}

HDD_GIRTH_DATABASE::~HDD_GIRTH_DATABASE()
{
 if(HDDtafel)
  {
   for(int i=1;i<=HDD_ANZ;i++)
     delete HDDtafel[i];
   delete[] HDDtafel;
  } 
}

void  HDD_GIRTH_DATABASE::InsertHDD(int idx,int wert,int dim)
{
 HDDtafel[idx]->Insert(wert,dim);
}


void  HDD_GIRTH_DATABASE::Init(int K_N,int GI_N)
{
 K_nr = K_N;
 Girth_nr = GI_N;
}

void  HDD_GIRTH_DATABASE::ReadHDDtafel()
{
 int i,j,k,l,m,ret,werte,kn;
 FILE *in;
 char name[200];

 if(HDDtafel)
  {
   for(i=1;i<=HDD_ANZ;i++)
    delete HDDtafel[i];
   delete[] HDDtafel;
   HDDtafel = NULL;
  }
 HDDtafel = new LIST_BASE<int>*[HDD_ANZ+1];  
 for(i=1;i<=HDD_ANZ;i++)
  HDDtafel[i] = new LIST_BASE < int >;

 sprintf(name,"./DATA/K%d/GIRTH%d/hashtafel",K_nr,Girth_nr);
 in = fopen(name,"r");
 if(in == NULL)
  {
   fprintf(stderr,"couldn't open %s for reading\n",name);
   exit(0); 
  }
 ret = fscanf(in,"%d",&werte);
 if(ret != 1)
  {
   fprintf(stderr,"couldn't read number of different hash-values\n");
   exit(0);
  }
 for(i=1;i<=werte;i++)
  {
   ret = fscanf(in,"%d",&j);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read hash-value number %d\n",i);
     exit(0);
    }
   if((j > HDD_ANZ)||(j < 1))
    {
     fprintf(stderr,"wrong hash-value\n");
     exit(0);
    }
   ret = fscanf(in,"%d",&k);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read number of entries for hash-value number %d\n",i);
     exit(0);
    }
   for(l=1;l<=k;l++)
    {
     ret = fscanf(in,"%d",&m);
     if(ret != 1)
      {
       fprintf(stderr,"couldn't read entry %d for hash-value number %d\n",l,i);
       exit(0);
      }
     ret = fscanf(in,"%d",&kn);
     if(ret != 1)
      {
       fprintf(stderr,"couldn't read %d-th number of vertices for hash-value number %d\n",l,i);
       exit(0);
      }
     HDDtafel[j]->Insert(m,kn);
    }
  }
 fclose(in);
}


void  HDD_GIRTH_DATABASE::WriteHDDtafel()
{
 int kno_nr;
 int i,j,k,l,m,ret,werte;
 FILE *out;
 char name[200];

 werte=0;
 for(i=1;i<=HDD_ANZ;i++)
  if(HDDtafel[i]->Anz() > 0)
    werte++;

 sprintf(name,"./DATA/K%d/GIRTH%d/hashtafel",K_nr,Girth_nr);
 out = fopen(name,"w");
 if(out==NULL)
  {
   fprintf(stderr,"couldn't open %s for writing\n",name);
   exit(0);
  }
 fprintf(out,"%d\n",werte);
 for(i=1;i<=HDD_ANZ;i++)
  {
   if(HDDtafel[i]->Anz() > 0)
    {
     fprintf(out,"%d %d ",i,HDDtafel[i]->Anz());
     HDDtafel[i]->Start();
     while(! HDDtafel[i]->IsLast())
      {
       j = HDDtafel[i]->GetNext(kno_nr);
       fprintf(out,"%d %d ",j,kno_nr);
      }
     fprintf(out,"\n"); 
    }
  }

 fprintf(out,"\n"); 
 fclose(out);
}

void  HDD_GIRTH_DATABASE::ReadHDD_part(FILE *fp,int startpos)
{
 int i,j,ret,max;

 graph_anz_gi.Clear();
 write_st_gi.Clear();
 ret = fseek(fp,startpos,SEEK_SET);
 if(ret != 0)
  {
   fprintf(stderr,"error in fseek in HDD_GIRTH_DATABASE::ReadHDD_part\n");
   exit(0);
  }

 //Format: 'maxgrad' part[1],...,part[maxgrad] 'max_kand_girth' 
 //        'wr_st_0' 'gr_anz_0' 'wr_st_Girth_nr' 'gr_anz_Girth_nr' ....
 //        'wr_st_max_kand_girth' 'gr_anz_max_kand_girth'          

 ret = fscanf(fp,"%d",&i);
 if(ret != 1)
  {
   fprintf(stderr,"couldn't read maxgrad in HDD_GIRTH_DATABASE::ReadHDD_part\n");
   exit(0);
  }
 max = i;
 HDD_part.ReAlloc(max);
 for(j=1;j<=max;j++)
  {
   ret = fscanf(fp,"%d",&i);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read HDD_part[%d] in HDD_GIRTH_DATABASE::ReadHDD_part\n",j);
     exit(0);
    }
   HDD_part[j] = i;
  }
 HDD_part.Used() = max; 
 ret = fscanf(fp,"%d",&i);
 max_kand_girth = i;

 ret = fscanf(fp,"%d",&i);
 if(ret != 1)
  {
   fprintf(stderr,"couldn't read write_st_gi[0] in HDD_GIRTH_DATABASE::ReadHDD_part\n");
   exit(0);
  }
 write_st_gi[0] = i;
 ret = fscanf(fp,"%d",&i);
 if(ret != 1)
  {
   fprintf(stderr,"couldn't read graph_anz_gi[0] in HDD_GIRTH_DATABASE::ReadHDD_part\n");
   exit(0);
  }
 graph_anz_gi[0] = i;

 for(j=Girth_nr;j<=max_kand_girth;j++)
  {
   ret = fscanf(fp,"%d",&i);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read write_st_gi[%d] in HDD_GIRTH_DATABASE::ReadHDD_part\n",j);
     exit(0);
    }
   write_st_gi[j] = i;
   ret = fscanf(fp,"%d",&i);
   if(ret != 1)
    {
     fprintf(stderr,"couldn't read graph_anz_gi[%d] in HDD_GIRTH_DATABASE::ReadHDD_part\n",j);
     exit(0);
    }
   graph_anz_gi[j] = i;	
  }
 HDD_graph_anz = graph_anz_gi[0];
 for(j=Girth_nr;j<=max_kand_girth;j++)
  HDD_graph_anz += graph_anz_gi[j];

 HDD_write_start = -1;
 for(j=0;j<=max_kand_girth;j++)
  {
   if(graph_anz_gi[j] > 0)
    {
     if((HDD_write_start==-1)||(write_st_gi[j] < HDD_write_start))
      HDD_write_start = write_st_gi[j];	
    }
  }
}



int   HDD_GIRTH_DATABASE::IsPossiblePartition(VEKTOR<short>& bvek)
{
 int kn,i,j,k,hashwert,kn_nr;
 char name[200];
 FILE *db;
 int mal[10];

 mal[0] = 533;mal[1] = 23; mal[2] = 8923; mal[3] = 789; mal[4] = 1111; 
 mal[5] = 2734; mal[6] = 231; mal[7] = 8888; mal[8] = 9090; mal[9] = 77;

 kn = 0;
 for(j=1;j <= bvek.Used();j++)
   kn += bvek[j];

 sprintf(name,"./DATA/K%d/GIRTH%d/vert%d",K_nr,Girth_nr,kn);
 db = fopen(name,"r");
 if(db == NULL)
  {
   return(1);
//   fprintf(stderr,"couldn't open %s for reading\n",name);
//   exit(0);
  }
 hashwert = 0;
 for(i=1;i<=bvek.Used();i++)
  hashwert += bvek[i] * mal[i % 10];
 hashwert = hashwert % HDD_ANZ;
 if(hashwert < 0)
  hashwert *= -1;
 hashwert++;

 HDDtafel[hashwert]->Start();
 HDD_WEITER_DATA:
 while(! HDDtafel[hashwert]->IsLast())
  {
   j = HDDtafel[hashwert]->GetNext(kn_nr);
   if(kn_nr == kn)
    {
     ReadHDD_part(db,j);
     k = 1;
     for(i=1;i<=HDD_part.Used();i++)
      if(HDD_part[i] != bvek[i])
       { k = 0; break; }
     if(k == 1)
      { fclose(db); return(1); } 
     else
      goto HDD_WEITER_DATA;
    }
   else
    goto HDD_WEITER_DATA;   
  }

 fclose(db); 
 return(0);  
}


int   HDD_GIRTH_DATABASE::IsPossiblePartition(VEKTOR<short>& bvek,int GI)
{
 int kn,i,j,k,hashwert,kn_nr;
 char name[200];
 FILE *db;
 int mal[10];

 mal[0] = 533;mal[1] = 23; mal[2] = 8923; mal[3] = 789; mal[4] = 1111; 
 mal[5] = 2734; mal[6] = 231; mal[7] = 8888; mal[8] = 9090; mal[9] = 77;

 kn = 0;
 for(j=1;j <= bvek.Used();j++)
   kn += bvek[j];

 sprintf(name,"./DATA/K%d/GIRTH%d/vert%d",K_nr,Girth_nr,kn);
 db = fopen(name,"r");
 if(db == NULL)
  {
   return(1);
//   fprintf(stderr,"couldn't open %s for reading\n",name);
//   exit(0);
  }
 hashwert = 0;
 for(i=1;i<=bvek.Used();i++)
  hashwert += bvek[i] * mal[i % 10];
 hashwert = hashwert % HDD_ANZ;
 if(hashwert < 0)
  hashwert *= -1;
 hashwert++;

 HDDtafel[hashwert]->Start();
 HDD_WEITER_DATA:
 while(! HDDtafel[hashwert]->IsLast())
  {
   j = HDDtafel[hashwert]->GetNext(kn_nr);
   if(kn_nr == kn)
    {
     ReadHDD_part(db,j);
     k = 1;
     for(i=1;i<=HDD_part.Used();i++)
      if(HDD_part[i] != bvek[i])
       { k = 0; break; }
     if((graph_anz_gi[0]==0)&&(max_kand_girth < GI))
      k = 0;
     if(k == 1)
      { fclose(db); return(1); } 
     else
      goto HDD_WEITER_DATA;
    }
   else
    goto HDD_WEITER_DATA;   
  }

 fclose(db); 
 return(0);  
}



/**************************************************************/



void GIRTH_DAT_READ::Init(int KNR,int GNR,int RST,int RA,
                          int DIM,int DIMGR,int KA)
{
 K_nr = KNR;
 Girth_nr = GNR;
 read_start = RST;
 read_anz = RA;
 dim = DIM;
 dim_gr_0 = DIMGR;
 kant_anz = KA;
 NBList.REALLOC(dim,dim);
 NBListKompr.ReAlloc(dim + kant_anz);
 ZSums.ReAlloc(dim);
 char name[200];
 sprintf(name,"./DATA/K%d/GIRTH%d/graphs%d",K_nr,Girth_nr,dim_gr_0);
 in = fopen(name,"rb");
 if(in == NULL)
  {
   fprintf(stderr,"GIRTH_DAT_READ::Init: couldn't open %s for reading\n",name);
   exit(0);
  }

 if(fseek(in,read_start,SEEK_SET))
  {
   fprintf(stderr,"GIRTH_DAT_READ::Init: error in fseek\n");
   exit(0);
 }
 read_until = 0;
}



void GIRTH_DAT_READ::ReadNB(FILE *f,VEKTOR < short >& N,int _dim,int& gi)
{
 int k,j,i,l,ret;
 unsigned char a;

 j = 0;
 for(i=1;i<=_dim;i++)
  {
   ret = fscanf(f,"%c",&a);
   if(ret != 1)
    {
     fprintf(stderr,"ReadNB: error in fscanf\n");
     exit(0);
    }
   N[++j] = a;
   k = a;
   for(l=1;l<=k;l++)
    {
     ret = fscanf(f,"%c",&a);
     if(ret != 1)
      {
       fprintf(stderr,"ReadNB: error in fscanf\n");
       exit(0);
      }
     N[++j] = a; 
    }
  }
 N.Used() = j; 
 ret = fscanf(f,"%c",&a);
 if(ret != 1)
  {
   fprintf(stderr,"ReadNB: error in fscanf\n");
   exit(0);
  }
 gi = a;
}



int GIRTH_DAT_READ::NextRep(int& gi)
{
 int i,j,k;

 if(read_until == read_anz)
   { fclose(in); return(0); }
 ReadNB(in,NBListKompr,dim_gr_0,gi); 
 //baue jetzt NBList auf. Fuege dabei evtl. Knoten
 //vom Grad 0 hinzu.
 for(i=1;i<=dim;i++)
  {
   ZSums[i] = 0;
   NBList[i].Used() = 0;
  }
 j = 0; 
 for(i=1;i<=dim_gr_0;i++)
  {
   NBList[i].Used() = NBListKompr[++j];
   for(k=1;k<=NBList[i].Used();k++)
    NBList[i][k] = NBListKompr[++j];    
  }

 for(i=1;i<=dim;i++)
  {
   for(j=1;j<=NBList[i].Used();j++)
    {
     ZSums[i]++;
     ZSums[NBList[i][j]]++;
    }
  }
 read_until++; 
 return(1); 
}




/**************************************************************/


void FIND_CIRCLES::ComputeCircles(ARRAY < VEKTOR < short > >& NB,
                                  ARRAY < VEKTOR < short > >& kreis_list,
                                  int GIRTH)
{
 int i,j,k,l,io;

 int dim = NB.Dim();
 nb.FREE();
 nb.REALLOC(dim,dim);
 for(i=1;i<=dim;i++)
  nb[i].Used() = 0;
 for(i=1;i<=dim;i++)
  {
   for(j=1;j<=NB[i].Used();j++)
    {
     k = NB[i][j];
     nb[i][++nb[i].Used()] = k;
     nb[k][++nb[k].Used()] = i;
    }
  }  
 bits.ReAlloc(dim);
 bits.Clear();
 dpf.ReAlloc(GIRTH+1);
 ind.ReAlloc(GIRTH);
 kreis_list.FREE();
 kreis_list.REALLOC(3,GIRTH);
 kreis_list.Used() = 0;
 for(i=1;i<=dim-GIRTH+1;i++)
  {
   if(nb[i].Used() > 1)
    {
     //suche alle Taillenkreise, die i, aber keinen Knoten < i 
     //enthalten. 
     dpf.Clear();
     dpf[1] = i;
     bits.Clear();
     bits.Set(i);
     j = 1;
     ind[1] = 0;

     while(j)
      {
       ind[j]++;
       if((ind[j] <= nb[dpf[j]].Used())&&(j <= GIRTH))
        {
         io = nb[dpf[j]][ind[j]];
         if((io >= i)&&(nb[io].Used() > 1)) 
          {
           if((bits[io] == 0)||
              ((j==GIRTH)&&(io == i)))
            {
             if(io == i)
              {
               if(j == GIRTH)
                {
                 kreis_list.REALLOC(kreis_list.Used()+1,GIRTH);
                 kreis_list.Used()++;
                 for(k=1;k<=j;k++) 
                  kreis_list[kreis_list.Used()][k] = dpf[k];
                }
              }
             else
              {
               if(j < GIRTH)
                {
                 if(dpf[j+1])
                  bits.Reset(dpf[j+1]);
                 dpf[j+1] = io;
                 bits.Set(dpf[j+1]);
                 j++;
                 dpf[j+1] = 0;
                 ind[j] = 0;
                }
              }       
            }   
          }    
        }
       else
        {
         bits.Reset(dpf[j]);
         j--; 
        } 
      } //Ende von while
    }
  }
}



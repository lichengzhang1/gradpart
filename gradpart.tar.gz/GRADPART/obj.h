/* obj.h */

#include <array.t>
#include <bitvec.h>
#include <labra.h>
#include <langzahl.h>
#include <ordConj.h>
#include <ordSpZ.h>
#include <ordhash.h>
#include <ordtreu.h>
#include <permut.t>
#include <sims.h>
#include <vector.t>

/* classes.C: */
int conj_classes(int deg, int nb_gen, int *gen, 
	int f_verbose, int f_very_verbose, 
	int *nb_classes, int **class_reps, ARRAY<LABRA_TG>& Stab);


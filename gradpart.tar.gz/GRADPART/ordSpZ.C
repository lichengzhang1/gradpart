#include "ordSpZ.h"



void ORDTREU_SP_Z_SUMS::Init(int alone)
{
 ORDTREU::Init(alone);
 
 s_u.ReAlloc(s);
 s_o.ReAlloc(s);
 z_u.ReAlloc(z);
 z_o.ReAlloc(z);
}



void ORDTREU_SP_Z_SUMS::Init(KOORD_BASE *_VATER)
{
 ORDTREU::Init(_VATER);
 
 s_u.ReAlloc(s);
 s_o.ReAlloc(s);
 z_u.ReAlloc(z);
 z_o.ReAlloc(z);
}



VEKTOR<char>& ORDTREU_SP_Z_SUMS::Sp_U_Gr()
{
 return(s_u);
}

VEKTOR<char>& ORDTREU_SP_Z_SUMS::Sp_O_Gr()
{
 return(s_o);
}

VEKTOR<char>& ORDTREU_SP_Z_SUMS::Zei_U_Gr()
{
 return(z_u);
}

VEKTOR<char>& ORDTREU_SP_Z_SUMS::Zei_O_Gr()
{
 return(z_o);
}



ORDTREU_SP_Z_SUMS::ORDTREU_SP_Z_SUMS():ORDTREU()
{
 return;
}

ORDTREU_SP_Z_SUMS::~ORDTREU_SP_Z_SUMS()
{
 return;
}







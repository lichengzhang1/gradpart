/* gp.C */

#include "XGrad.h"

XmFontList fontlist;

char *text_default_value = 
"\n"
"\n"
"  ####   #####     ##    #####   #####     ##    #####    #####\n"
" #    #  #    #   #  #   #    #  #    #   #  #   #    #     #\n"
" #       #    #  #    #  #    #  #    #  #    #  #    #     #\n"
" #  ###  #####   ######  #    #  #####   ######  #####      #\n"
" #    #  #   #   #    #  #    #  #       #    #  #   #      #\n"
"  ####   #    #  #    #  #####   #       #    #  #    #     #\n"
"\n"
"     -  the famous graph generator\n"
"\n";

XmStringCharSet gp_cs = "ISOLatin1";
char *the_font = /* "fixed" */ "-misc-fixed-*-*-*-*-15-*-*-*-*-*-*-*" ; 

String fallbacks[] = {
"multi_font*fontList:\
-misc-fixed-*-*-*-*-15-*-*-*-*-*-*-*=TAG1,\
-*-courier-*-r-*--12-*=TAG2,\
-*-courier-bold-o-*--14-*=TAG3",
NULL
};


void insert_text(char *message)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmTextPosition curpos;
 XmTextPosition found;


 curpos=XmTextGetInsertionPosition( dial->scrolled_text );
 if(message[0] == '\r')
  {
   message++;

   if(XmTextFindString(dial->scrolled_text,curpos,"\n",
        XmTEXT_BACKWARD,&found) == True)
    {
     XmTextReplace(dial->scrolled_text,found+1,found+1+strlen(message),
                   message); 
     curpos=found+1+strlen(message);
     XmTextShowPosition(dial->scrolled_text,curpos);
     XmTextSetInsertionPosition(dial->scrolled_text,curpos); 
     return;
    }      
  }

 curpos=XmTextGetInsertionPosition( dial->scrolled_text );
 curpos+=strlen(message);
 XmTextInsert(dial->scrolled_text,curpos,message);

 XmTextShowPosition(dial->scrolled_text,curpos);
 XmTextSetInsertionPosition(dial->scrolled_text,curpos);

}


void time_output(void *poi,XtIntervalId *id)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;


 if(delay==100)
  {
   //um 0.1 sec erhoehen
   seconds_10++;
   if(seconds_10 == 10)
    {
     seconds_10=0;
     seconds++;
     if(seconds == 60)
      {
       delay=1000;
       seconds=0;
       minutes++;
       if(minutes==60)
        {
         minutes=0;
         hours++;
         if(hours==24)
          {
           hours=0;
           days++; 
          }
        }
      }
    }
  } 
 else
  {
   //delay==1000 msec.
   seconds++;
   if(seconds == 60)
    {
     seconds=0;
     minutes++;
     if(minutes==60)
      {
       minutes=0;
       hours++;
       if(hours==24)
        {
         hours=0;
         days++; 
        }
      }
    }
  }


 char time_str[200],add[50];
 strcpy(time_str,"time elapsed: ");
 char w=0;
 if(days > 0)
  {
   w=1;
   sprintf(add,"%d d ",days);
   strcat(time_str,add);
  }
 if((hours > 0)||(w==1))
  {
   w=1;
   sprintf(add,"%d h ",hours);
   strcat(time_str,add); 
  }
 if((minutes > 0)||(w==1))
  {
   w=1;
   sprintf(add,"%d min ",minutes);
   strcat(time_str,add);
  }
  
 if(delay==100)
  {
   sprintf(add,"%d.%d sec ",seconds,seconds_10);
   strcat(time_str,add);
  }
 else
  {
   sprintf(add,"%d sec ",seconds);
   strcat(time_str,add);
  }

 
 XmString str = (XmString) NULL;
 str=XmStringCreateLocalized(time_str);
 XtVaSetValues(dial->time_label,
               XmNlabelString,str,
               XmNfontList,fontlist,
               NULL);
 XmStringFree(str);

 TimeId =
  XtAppAddTimeOut(XtWidgetToApplicationContext(dial->time_label),
                  delay,time_output,(XtPointer)NULL);

}


#include <errno.h>
#include <sys/stat.h>

void get_pipe_input(void *poi,XtIntervalId *id)
{
 static char buf[10000];
 static char buf2[10100];
 int anz;
 int i,j,k;
 GP_DIAL *dial;
 dial = gl_gp_dial;
 
#ifdef DEC_ALPHA
 struct pollfd pollfds[1];
 pollfds[0].fd=fileno(erg_pipe);
 pollfds[0].events = POLLIN;
 i=poll(pollfds,1,10);
 if(i < 0)
  {
   FatalMess("error in poll\n");
   exit(0);
  }
 i=pollfds[0].revents;
 if(i == 0)
  {
   PipeId =
    XtAppAddTimeOut(gl_app,
                  100,get_pipe_input,dial->scrolled_text);
   return;
  }
 anz=read(fileno(erg_pipe),buf,10000);
 if(anz==-1)
  {
   PipeId =
    XtAppAddTimeOut(gl_app,
                  100,get_pipe_input,dial->scrolled_text);
   return;
  }
#else
 anz=read(fileno(erg_pipe),buf,10000);
 if(anz==-1)
  {
   PipeId =
    XtAppAddTimeOut(gl_app,
                  100,get_pipe_input,dial->scrolled_text);
   return;
  }
#endif


 char *st1,*st2;
 XmTextDisableRedisplay(dial->scrolled_text);
 if((((st1 = strstr(buf,"total number")) != NULL)&&
     (st1-buf < anz))||
    (((st2 = strstr(buf,"computation completed")) != NULL)&&
     (st2-buf < anz)))
  {
   FILE *h_f=NULL;
   while(h_f==NULL)
     h_f=fopen("HELP_PID","r");
   fscanf(h_f,"%d",&help_pid);
   fclose(h_f);
   kill(help_pid,9);
   XtRemoveTimeOut(PipeId);
   XtRemoveTimeOut(TimeId);
   pclose(erg_pipe);
   is_running=0;
  }

 i=0;
 j=anz-1;

 while(i <= j)
  {
   buf2[0]=buf[i];
   k=1;
   i++;
   while((i <= j)&&(buf[i] != '\r'))
    {
     buf2[k]=buf[i]; 
     i++;
     k++;
    }
   buf2[k]='\0';
   insert_text(buf2);  
  }

 PipeId =
  XtAppAddTimeOut(gl_app,
                  100,get_pipe_input,dial->scrolled_text);
 XmTextEnableRedisplay(dial->scrolled_text);
}



int main(int argc, char **argv)
{
 int argc1 = (int) argc;
 int i;
 GP_DIAL *dial;
 dial = gl_gp_dial;

 unlink("Z");
 OP_ACTIVE=SPLIT_ACTIVE=CONSTR_ACTIVE=RESTR_ACTIVE=0;

 XtSetLanguageProc(NULL,NULL,NULL);
 wnd_toplevel = XtVaAppInitialize(&gl_app,"GP",NULL,0,&argc,
                                  argv,fallbacks,NULL);

 GetColors();
 InitFlags();
 is_running=0;
 if (i_var())
  {
   XtRealizeWidget(wnd_toplevel);
   XtAppMainLoop(gl_app);
  }

 return(0);
}



void InitFlags()
{
 _PRECOMPUTE_SPLITS_=0;
 _VERBOSE_=0;
 _GO_IMPL_=1;
 _RECONSTRUCT_ALL_=0;
 _SPLIT_MIN_=6;
 SPLIT_STRATEGY=2;
 _SPLIT_KLEIN_=1;
 _SHIFT_PARTITIONS_=1;
 GIRTH=3;
 MAXBOND=1;
 CONN_GRAPHS=0;
 TREES_ONLY = 0;
}


void GetColors()
{

 Colormap cmap = DefaultColormapOfScreen(XtScreen(wnd_toplevel));
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,AppCol,
                       &exact,&Appcolor))
  {
   FatalMess("Couldn't XAlloc Appcolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,FrameCol,
                       &exact,&Framecolor))
  {
   FatalMess("Couldn't XAlloc Framecolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,SelectCol,
                       &exact,&Selectcolor))
  {
   FatalMess("Couldn't XAlloc Selectcolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,ButtonCol,
                       &exact,&Buttoncolor))
  {
   FatalMess("Couldn't XAlloc Buttoncolor!!\n");
  // exit(1);
  }
 if(! XAllocNamedColor(XtDisplay(wnd_toplevel),cmap,ErrCol,
                       &exact,&ErrorColor))
  {
   FatalMess("Couldn't XAlloc Errorcolor!!\n");
  // exit(1);
  }


}



int i_var()
{
 i_gp_dlg();
// create_op_dial();
// create_ss_dial();
// create_co_dial();
 return TRUE;
}




int i_gp_dlg(void)
{
 Arg args[64];
 char s[256];
 XmString str = (XmString) NULL;
 GP_DIAL *dial;
 int i, j, height, bottom_margin;

 gl_gp_dial = (GP_DIAL *) malloc(sizeof(GP_DIAL));
 if (gl_gp_dial == NULL) 
  {
   printf("i_km_dlg() no memory for gp_dial\n");
   fflush(stdout);
   return FALSE;
  }
 dial = gl_gp_dial;

 gp_fnt = XLoadQueryFont(XtDisplay(wnd_toplevel), the_font);
 gp_font1 = XmFontListCreate(gp_fnt, gp_cs);
 gp_curfont = gp_font1;


 XmFontListEntry entry1;

 entry1 = XmFontListEntryLoad(XtDisplay(wnd_toplevel),
          "-*-courier-*-r-*--14-*",XmFONT_IS_FONT,"TAG1");
 fontlist = XmFontListAppendEntry(NULL,entry1);
 XmFontListEntryFree(&entry1);


 i = 0;
 XtSetArg(args[i], XmNautoUnmanage, FALSE); i++;
 dial->all_form = 
  XtVaCreateWidget("all_form",xmFormWidgetClass,
                   wnd_toplevel,
                   XmNbackground,Appcolor.pixel,
                   XmNbuttonFontList,fontlist,
                   XmNfontList,fontlist,
                   NULL);


 dial->param_form =
  XtVaCreateManagedWidget("param_form",xmFormWidgetClass,
                   dial->all_form,
                   XmNtopAttachment,XmATTACH_FORM,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNbackground,Appcolor.pixel,
                   NULL);

 dial->param_frame =
  XtVaCreateManagedWidget("param_frame",xmFrameWidgetClass,
                   dial->param_form,
                   XmNtopAttachment,XmATTACH_FORM,
                   XmNbottomAttachment,XmATTACH_FORM,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNbackground,Framecolor.pixel,
                   NULL);

 dial->param_frame_form =
  XtVaCreateManagedWidget("param_frame_form",xmFormWidgetClass,
                   dial->param_frame, 
                   XmNfractionBase, 1000,
                   XmNbackground,Appcolor.pixel,
                   NULL);

 dial->dp_form =
  XtVaCreateManagedWidget("dp_form",xmFormWidgetClass,
                   dial->param_frame_form,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNtopAttachment, XmATTACH_POSITION,
                   XmNtopPosition, 0,
                   XmNbottomAttachment, XmATTACH_POSITION,
                   XmNbottomPosition, 200,
                   XmNbackground,Appcolor.pixel,
                   NULL);


 str=XmStringCreateLocalized("degree partition: ");
 dial->dp_label =
  XtVaCreateManagedWidget("dp_label",
			xmLabelWidgetClass, dial->dp_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_FORM,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);

 dial->dp_file =
  XtVaCreateManagedWidget("file",xmPushButtonWidgetClass,
                          dial->dp_form,
			  XmNrightAttachment,XmATTACH_FORM,
			  XmNtopAttachment,XmATTACH_FORM,
			  XmNbottomAttachment,XmATTACH_FORM,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->dp_file,
               XmNactivateCallback,
               dp_file_callback,
               NULL);
			
 dial->dp_text =
  XtVaCreateManagedWidget("dp_text",
			xmTextFieldWidgetClass, dial->dp_form,
			XmNtraversalOn,      True,
			XmNrightAttachment,  XmATTACH_WIDGET,
			XmNrightWidget, dial->dp_file,
			XmNleftAttachment,   XmATTACH_WIDGET,
			XmNleftWidget, dial->dp_label,
			XmNvalue,"2x1 10x2 8x3 11x4 5x5 8x6 1x7 2x8 1x9 1x11 1x12",
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,  
			NULL);
			
 dial->mode_form =
  XtVaCreateManagedWidget("mode_form",xmFormWidgetClass,
                   dial->param_frame_form,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNtopAttachment, XmATTACH_POSITION,
                   XmNtopPosition, 200,
                   XmNbottomAttachment, XmATTACH_POSITION,
                   XmNbottomPosition, 800,
                   XmNbackground,Appcolor.pixel,
                   NULL);


 dial->dp_vert_frame =
  XtVaCreateManagedWidget("dp_vert_frame",xmFrameWidgetClass,
                          dial->mode_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 0,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 0,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 35,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 100,
                          XmNbackground,Framecolor.pixel,
                          NULL);

 dial->dp_vert_form =
  XtVaCreateManagedWidget("dp_vert_form",xmFormWidgetClass,
                   dial->dp_vert_frame, 
                   XmNbackground,Appcolor.pixel,
                   NULL);


 str=XmStringCreateLocalized("mode: ");
 dial->dp_vert_label =
  XtVaCreateManagedWidget("dp_vert_label",
			xmLabelWidgetClass, dial->dp_vert_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_FORM,
			XmNtopAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNforeground,Framecolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);


 //verwende ausfuehrliche Form fuer richtiges attachment
 dial->dp_vert_radiobox =
  XtVaCreateManagedWidget("dp_vert_radiobox",
                        xmRowColumnWidgetClass, dial->dp_vert_form,
			XmNleftAttachment,XmATTACH_FORM,
			XmNrightAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNtopAttachment,XmATTACH_WIDGET,
                        XmNtopWidget, dial->dp_vert_label,
                        XmNradioBehavior, True,
                        XmNradioAlwaysOne, True,
                        XmNisHomogeneous, True,
                        XmNentryClass, xmToggleButtonWidgetClass,
                        XmNpacking, XmPACK_COLUMN,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        NULL);

 dial->degree_toggle =
  XtVaCreateManagedWidget("degree partition",
                        xmToggleButtonWidgetClass, 
                        dial->dp_vert_radiobox,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        NULL); 
 XmToggleButtonSetState(dial->degree_toggle,TRUE,FALSE);



 dial->vertex_toggle =
  XtVaCreateManagedWidget("vertex/edge restriction",
                        xmToggleButtonWidgetClass, 
                        dial->dp_vert_radiobox,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        NULL); 
 XmToggleButtonSetState(dial->vertex_toggle,FALSE,FALSE);



 dial->vert_edge_frame =
  XtVaCreateManagedWidget("vert_edge_frame",xmFrameWidgetClass,
                          dial->mode_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 0,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 35,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 65,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 100,
                          XmNbackground,Framecolor.pixel,
                          NULL);

 dial->vert_edge_form =
  XtVaCreateManagedWidget("vert_edge_form",xmFormWidgetClass,
                   dial->vert_edge_frame, 
                   XmNbackground,Appcolor.pixel,
                   NULL);


 str=XmStringCreateLocalized("vertex / edge restriction:");
 dial->vert_edge_label =
  XtVaCreateManagedWidget("vert_edge_label",
			xmLabelWidgetClass, dial->vert_edge_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_FORM,
			XmNtopAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNforeground,Framecolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);


 dial->vert_edge_up_form =
  XtVaCreateManagedWidget("vert_edge_left_form",xmFormWidgetClass,
                   dial->vert_edge_form,
                   XmNtopAttachment,XmATTACH_WIDGET,
                   XmNtopWidget, dial->vert_edge_label,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNfractionBase, 100,
                   XmNbackground,Appcolor.pixel,
                   NULL);

 str=XmStringCreateLocalized("# vertices:");
 dial->vert_edge_up_label =
  XtVaCreateManagedWidget("vert_edge_up_label",
			xmLabelWidgetClass, 
			dial->vert_edge_up_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_FORM,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);



 dial->vert_edge_up_text =
  XtVaCreateManagedWidget("vert_edge_up_text",
			xmTextFieldWidgetClass, 
			dial->vert_edge_up_form,
			XmNtraversalOn,      True,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
			XmNrightAttachment,  XmATTACH_FORM,
			XmNleftAttachment,   XmATTACH_POSITION,
                        XmNleftPosition, 50,
			XmNvalue,"",
			XmNcolumns,10,
                        XmNbackground,Appcolor.pixel,
			NULL);


 dial->vert_edge_down_form =
  XtVaCreateManagedWidget("vert_edge_down_form",xmFormWidgetClass,
                   dial->vert_edge_form,
                   XmNtopAttachment,XmATTACH_WIDGET,
                   XmNtopWidget, dial->vert_edge_up_form,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNbottomAttachment,XmATTACH_FORM,
                   XmNfractionBase, 100,
                   XmNbackground,Appcolor.pixel,
                   NULL);

 str=XmStringCreateLocalized("# edges:");
 dial->vert_edge_down_label =
  XtVaCreateManagedWidget("vert_edge_down_label",
			xmLabelWidgetClass, 
			dial->vert_edge_down_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_FORM,
			XmNtopAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);



 dial->vert_edge_down_text =
  XtVaCreateManagedWidget("vert_edge_down_text",
			xmTextFieldWidgetClass, 
			dial->vert_edge_down_form,
			XmNtraversalOn,      True,
			XmNtopAttachment,XmATTACH_FORM,
			XmNrightAttachment,  XmATTACH_FORM,
			XmNleftAttachment,   XmATTACH_POSITION,
                        XmNleftPosition, 50,
			XmNvalue,"",
			XmNcolumns,10,
                        XmNbackground,Appcolor.pixel,
			NULL);



 dial->flags_frame =
  XtVaCreateManagedWidget("flags_frame",xmFrameWidgetClass,
                          dial->mode_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 0,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 65,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 100,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 100,
                          XmNbackground,Framecolor.pixel,
                          NULL);

 dial->flags_form =
  XtVaCreateManagedWidget("flags_form",xmFormWidgetClass,
                   dial->flags_frame, 
                   XmNfractionBase, 100,
                   XmNbackground,Appcolor.pixel,
                   NULL);


 str=XmStringCreateLocalized("flags:");
 dial->flags_form_label =
  XtVaCreateManagedWidget("flags_form_label",
			xmLabelWidgetClass, 
			dial->flags_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_FORM,
			XmNtopAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNforeground,Framecolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);


 dial->flags_form_opt_button =
  XtVaCreateManagedWidget("options",xmPushButtonWidgetClass,
                          dial->flags_form,
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->flags_form_label,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 15,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 85,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->flags_form_opt_button,
               XmNactivateCallback,
               flags_form_opt_button_callback,
               NULL);


 dial->flags_form_split_button =
  XtVaCreateManagedWidget("splitting strategy",xmPushButtonWidgetClass,
                          dial->flags_form,
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->flags_form_opt_button,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 15,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 85,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->flags_form_split_button,
               XmNactivateCallback,
               flags_form_split_button_callback,
               NULL);

 dial->flags_form_constr_button =
  XtVaCreateManagedWidget("construction order",xmPushButtonWidgetClass,
                          dial->flags_form,
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->flags_form_split_button,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 15,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 85,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->flags_form_constr_button,
               XmNactivateCallback,
               flags_form_constr_button_callback,
               NULL);



 dial->step_form =
  XtVaCreateManagedWidget("step_form",xmFormWidgetClass,
                   dial->param_frame_form,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNtopAttachment, XmATTACH_POSITION,
                   XmNtopPosition, 800,
                   XmNbottomAttachment, XmATTACH_POSITION,
                   XmNbottomPosition, 1000,
                   XmNbackground,Appcolor.pixel,
                   XmNfractionBase, 100,
                   NULL);


 str=XmStringCreateLocalized("steps to store:");
 dial->step_label =
  XtVaCreateManagedWidget("step_label",
			xmLabelWidgetClass, 
			dial->step_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_FORM,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);


 dial->step_text =
  XtVaCreateManagedWidget("step_text",
			xmTextFieldWidgetClass, 
			dial->step_form,
			XmNtraversalOn,      True,
			XmNtopAttachment,XmATTACH_FORM,
			XmNleftAttachment,   XmATTACH_WIDGET,
                        XmNleftWidget, dial->step_label,
			XmNvalue,"10",
			XmNcolumns, 10,
                        XmNbackground,Appcolor.pixel,
			NULL);

 str=XmStringCreateLocalized("time elapsed: 0.0 sec");
 dial->time_label =
  XtVaCreateManagedWidget("time_label",
			xmLabelWidgetClass, 
			dial->step_form,
			XmNlabelString, str,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNleftAttachment, XmATTACH_POSITION,
                        XmNleftPosition, 60,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);
 XmStringFree(str);


 dial->button_form =
  XtVaCreateManagedWidget("button_form",xmFormWidgetClass,
                   dial->all_form,
                   XmNtopAttachment,XmATTACH_WIDGET,
                   XmNtopWidget, dial->param_form,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNfractionBase, 41,
                   XmNbackground,Appcolor.pixel,
                   NULL);

  CreateButtons();

  i = 0;
  XtSetArg(args[i], XmNheight, 200); i++;
  XtSetArg(args[i], XmNeditMode, XmMULTI_LINE_EDIT); i++;
  XtSetArg(args[i], XmNeditable, False); i++;
  XtSetArg(args[i], XmNwordWrap, True); i++;
  XtSetArg(args[i], XmNcursorPositionVisible, False); i++;
  XtSetArg(args[i], XmNvalue, text_default_value); i++;
  XtSetArg(args[i], XmNfontList, gp_font1); i++;
  XtSetArg(args[i], XmNtopAttachment, XmATTACH_WIDGET); i++;
  XtSetArg(args[i], XmNtopWidget, dial->button_form); i++;
  XtSetArg(args[i], XmNleftAttachment, XmATTACH_FORM); i++;
  XtSetArg(args[i], XmNrightAttachment, XmATTACH_FORM); i++;
  XtSetArg(args[i], XmNbottomAttachment, XmATTACH_FORM); i++;
  XtSetArg(args[i], XmNbackground, Appcolor.pixel); i++;
  dial->scrolled_text = 
   XmCreateScrolledText(dial->all_form, "text", args, i);
  XtAddCallback(dial->scrolled_text, XmNactivateCallback,
		(void (* )(Widget, void *, void *) ) XmProcessTraversal, 
		(void *) XmTRAVERSE_NEXT_TAB_GROUP);


  //jetzt die staendig sichtbaren widgets managen


  XtManageChild(dial->scrolled_text);
  
  XtManageChild(dial->quit_button);
  XtManageChild(dial->start_button);
  XtManageChild(dial->stop_button);
  XtManageChild(dial->draw_button);
  XtManageChild(dial->restr_button);
  XtManageChild(dial->button_form);

  
  XtManageChild(dial->dp_label);
  XtManageChild(dial->dp_text);
  XtManageChild(dial->dp_file);
  XtManageChild(dial->dp_form);


  XtManageChild(dial->vertex_toggle);
  XtManageChild(dial->degree_toggle);
  XtManageChild(dial->dp_vert_radiobox);
  XtManageChild(dial->dp_vert_label);
  XtManageChild(dial->dp_vert_form);
  XtManageChild(dial->dp_vert_frame);

  XtManageChild(dial->vert_edge_down_text);
  XtManageChild(dial->vert_edge_down_label);
  XtManageChild(dial->vert_edge_down_form);
  XtManageChild(dial->vert_edge_up_text);
  XtManageChild(dial->vert_edge_up_label);
  XtManageChild(dial->vert_edge_up_form);
  XtManageChild(dial->vert_edge_label);
  XtManageChild(dial->vert_edge_form);
  XtManageChild(dial->vert_edge_frame);

  XtManageChild(dial->flags_form_constr_button);
  XtManageChild(dial->flags_form_split_button);
  XtManageChild(dial->flags_form_opt_button);
  XtManageChild(dial->flags_form_label);
  XtManageChild(dial->flags_form);
  XtManageChild(dial->flags_frame);


  XtManageChild(dial->mode_form);


  XtManageChild(dial->step_label);
  XtManageChild(dial->step_text);
  XtManageChild(dial->time_label);
  XtManageChild(dial->step_form);
  XtManageChild(dial->param_frame_form);
  XtManageChild(dial->param_frame);
  XtManageChild(dial->param_form);
  XtManageChild(dial->all_form);

  return(1);
}


	


void CreateButtons()
{
 int i;
 GP_DIAL *dial;
 dial = gl_gp_dial;

 dial->quit_button =
  XtVaCreateManagedWidget("quit",xmPushButtonWidgetClass,
                          dial->button_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 3,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 2,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 7,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 38,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->quit_button,
               XmNactivateCallback,
               quit_button_callback,
               NULL);

 dial->start_button =
  XtVaCreateManagedWidget("start",xmPushButtonWidgetClass,
                          dial->button_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 3,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 10,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 15,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 38,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->start_button,
               XmNactivateCallback,
               start_button_callback,
               NULL);

 dial->stop_button =
  XtVaCreateManagedWidget("stop",xmPushButtonWidgetClass,
                          dial->button_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 3,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 18,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 23,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 38,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->stop_button,
               XmNactivateCallback,
               stop_button_callback,
               NULL);

 dial->draw_button =
  XtVaCreateManagedWidget("draw",xmPushButtonWidgetClass,
                          dial->button_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 3,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 26,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 31,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 38,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->draw_button,
               XmNactivateCallback,
               draw_button_callback,
               NULL);

 dial->restr_button =
  XtVaCreateManagedWidget("restr",xmPushButtonWidgetClass,
                          dial->button_form,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 3,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 34,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 39,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 38,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->restr_button,
               XmNactivateCallback,
               restr_button_callback,
               NULL);

}




void flags_form_opt_button_callback(Widget w,
                                    XtPointer client_data,
                                    XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

 if(OP_ACTIVE==1)
  return;

 OP_ACTIVE=1;

  dial->options_form_dialog =
   XmCreateFormDialog( wnd_toplevel, "options",
                         NULL,0);

  dial->opt_up_form =
   XtVaCreateManagedWidget("opt_up_form",xmFormWidgetClass,
                   dial->options_form_dialog,
                   XmNtopAttachment,XmATTACH_FORM,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNfractionBase, 100,
                   XmNbackground,Appcolor.pixel,
                   XmNbuttonFontList,fontlist,
                   XmNfontList,fontlist,
                   NULL);

  dial->opt_form_ok =
   XtVaCreateManagedWidget("ok",xmPushButtonWidgetClass,
                          dial->opt_up_form,
                          XmNtopAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 15,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 85,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 20,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 70,
                          XmNbackground,Buttoncolor.pixel,
                          NULL);
 XtAddCallback(dial->opt_form_ok,
               XmNactivateCallback,
               opt_form_ok_callback,
               NULL);

  dial->opt_down_form =
   XtVaCreateManagedWidget("opt_down_form",xmFormWidgetClass,
                          dial->options_form_dialog, 
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->opt_up_form,
                          XmNleftAttachment, XmATTACH_FORM,
                          XmNrightAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNfractionBase, 100,
                          XmNbackground,Appcolor.pixel,
                          NULL);


  dial->opt_frame =
   XtVaCreateManagedWidget("opt_frame",xmFrameWidgetClass,
                          dial->opt_down_form,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 10,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 90,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 10,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 90,
                          XmNbackground,Framecolor.pixel,
                          NULL);


  dial->opt_frame_form =
   XtVaCreateManagedWidget("opt_frame_form",xmFormWidgetClass,
                   dial->opt_frame, 
                   XmNfractionBase, 105,
                   XmNbackground,Appcolor.pixel,
                   NULL);

  str=XmStringCreateLocalized("computation options:");
  dial->opt_prompt_label =
   XtVaCreateManagedWidget("opt_prompt_label",
			xmLabelWidgetClass, 
			dial->opt_frame_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 0,
			XmNtopAttachment,XmATTACH_POSITION,
                        XmNtopPosition, 7,
			XmNbottomAttachment,XmATTACH_POSITION,
                        XmNbottomPosition, 18,
                        XmNbackground,Appcolor.pixel,
                        XmNforeground,Framecolor.pixel,
                        XmNfontList,fontlist,
			NULL);
  XmStringFree(str);



  dial->opt_prompt_split_toggle =
   XtVaCreateManagedWidget("precompute_splits",
                        xmToggleButtonWidgetClass, 
			dial->opt_frame_form,
                        XmNindicatorType, XmN_OF_MANY,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 1,
			XmNtopAttachment,XmATTACH_POSITION,
                        XmNtopPosition, 25,
			XmNbottomAttachment,XmATTACH_POSITION,
                        XmNbottomPosition, 40,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
  if(_PRECOMPUTE_SPLITS_==1)                      
   XmToggleButtonSetState(dial->opt_prompt_split_toggle,TRUE,FALSE);
  else 
   XmToggleButtonSetState(dial->opt_prompt_split_toggle,FALSE,FALSE);

  dial->opt_prompt_verbose_toggle =
   XtVaCreateManagedWidget("verbose",
                        xmToggleButtonWidgetClass, 
			dial->opt_frame_form,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 1,
			XmNtopAttachment,XmATTACH_POSITION,
                        XmNtopPosition, 45,
			XmNbottomAttachment,XmATTACH_POSITION,
                        XmNbottomPosition, 60,
                        XmNindicatorType, XmN_OF_MANY,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
  if(_VERBOSE_==1)                      
   XmToggleButtonSetState(dial->opt_prompt_verbose_toggle,TRUE,FALSE);
  else
   XmToggleButtonSetState(dial->opt_prompt_verbose_toggle,FALSE,FALSE);

  dial->opt_prompt_goimpl_toggle =
   XtVaCreateManagedWidget("go_impl",
                        xmToggleButtonWidgetClass, 
			dial->opt_frame_form,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 1,
			XmNtopAttachment,XmATTACH_POSITION,
                        XmNtopPosition, 65,
			XmNbottomAttachment,XmATTACH_POSITION,
                        XmNbottomPosition, 80,
                        XmNindicatorType, XmN_OF_MANY,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
  if(_GO_IMPL_==1)                      
   XmToggleButtonSetState(dial->opt_prompt_goimpl_toggle,TRUE,FALSE);
  else 
   XmToggleButtonSetState(dial->opt_prompt_goimpl_toggle,FALSE,FALSE);

  dial->opt_prompt_reconstr_toggle =
   XtVaCreateManagedWidget("reconstruct all",
                        xmToggleButtonWidgetClass, 
			dial->opt_frame_form,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 1,
			XmNtopAttachment,XmATTACH_POSITION,
                        XmNtopPosition, 85,
			XmNbottomAttachment,XmATTACH_POSITION,
                        XmNbottomPosition, 100,
                        XmNindicatorType, XmN_OF_MANY,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,  
                        NULL); 
  if(_RECONSTRUCT_ALL_==1)                      
   XmToggleButtonSetState(dial->opt_prompt_reconstr_toggle,TRUE,FALSE);
  else 
   XmToggleButtonSetState(dial->opt_prompt_reconstr_toggle,FALSE,FALSE);
                                    
  XtManageChild(dial->opt_prompt_reconstr_toggle);
  XtManageChild(dial->opt_prompt_goimpl_toggle);
  XtManageChild(dial->opt_prompt_verbose_toggle);
  XtManageChild(dial->opt_prompt_split_toggle);
  XtManageChild(dial->opt_prompt_label);
  XtManageChild(dial->opt_frame_form);
  XtManageChild(dial->opt_frame);
  XtManageChild(dial->opt_down_form);
  XtManageChild(dial->opt_form_ok);
  XtManageChild(dial->opt_up_form);
  XtManageChild(dial->options_form_dialog);
                                                                        
}


void opt_form_ok_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;


 if(XmToggleButtonGetState(dial->opt_prompt_split_toggle)==True) 
  _PRECOMPUTE_SPLITS_=1;
 else 
  _PRECOMPUTE_SPLITS_=0;
 if(XmToggleButtonGetState(dial->opt_prompt_verbose_toggle)==True) 
  _VERBOSE_=1;
 else 
  _VERBOSE_=0;
 if(XmToggleButtonGetState(dial->opt_prompt_goimpl_toggle)==True) 
  _GO_IMPL_=1;
 else 
  _GO_IMPL_=0;
 if(XmToggleButtonGetState(dial->opt_prompt_reconstr_toggle)==True) 
  _RECONSTRUCT_ALL_=1;
 else 
  _RECONSTRUCT_ALL_=0;


 XtDestroyWidget(dial->options_form_dialog);
 XtDestroyWidget(dial->opt_up_form);
 XtDestroyWidget(dial->opt_form_ok);
 XtDestroyWidget(dial->opt_down_form);
 XtDestroyWidget(dial->opt_frame);
 XtDestroyWidget(dial->opt_frame_form);
 XtDestroyWidget(dial->opt_prompt_label);
 XtDestroyWidget(dial->opt_prompt_split_toggle);
 XtDestroyWidget(dial->opt_prompt_verbose_toggle);
 XtDestroyWidget(dial->opt_prompt_goimpl_toggle);
 XtDestroyWidget(dial->opt_prompt_reconstr_toggle);

 OP_ACTIVE=0;
}



void flags_form_split_button_callback(Widget w,
                                    XtPointer client_data,
                                    XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

 if(SPLIT_ACTIVE==1)
  return;

 SPLIT_ACTIVE=1;
  dial->split_form_dialog =
   XmCreateFormDialog( wnd_toplevel, "split",
                         NULL,0);


  dial->split_up_form =
   XtVaCreateManagedWidget("split_up_form",xmFormWidgetClass,
                   dial->split_form_dialog,
                   XmNtopAttachment,XmATTACH_FORM,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNfractionBase, 100,
                   XmNbackground,Appcolor.pixel,
                   NULL);

  dial->split_form_ok =
   XtVaCreateManagedWidget("ok",xmPushButtonWidgetClass,
                          dial->split_up_form,
                          XmNtopAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 15,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 85,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 20,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 70,
                          XmNbackground,Buttoncolor.pixel,
                          XmNfontList,fontlist,
                          NULL);
 XtAddCallback(dial->split_form_ok,
               XmNactivateCallback,
               split_form_ok_callback,
               NULL);

  dial->split_down_form =
   XtVaCreateManagedWidget("split_down_form",xmFormWidgetClass,
                          dial->split_form_dialog, 
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->split_up_form,
                          XmNleftAttachment, XmATTACH_FORM,
                          XmNrightAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNfractionBase, 100,
                          XmNbackground,Appcolor.pixel,
                          NULL);


  dial->split_down_frame =
   XtVaCreateManagedWidget("split_down_frame",xmFrameWidgetClass,
                          dial->split_down_form,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 10,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 90,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 10,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 90,
                          XmNbackground,Framecolor.pixel,
                          NULL);


  dial->split_down_frame_form =
   XtVaCreateManagedWidget("split_down_frame_form",xmFormWidgetClass,
                   dial->split_down_frame, 
                   XmNfractionBase, 105,
                   XmNbackground,Appcolor.pixel,
                   NULL);

  str=XmStringCreateLocalized("splitting strategy:");
  dial->spl_d_fr_f_label =
   XtVaCreateManagedWidget("spl_d_fr_f_label",
			xmLabelWidgetClass, 
			dial->split_down_frame_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 0,
			XmNtopAttachment,XmATTACH_POSITION,
                        XmNtopPosition, 5,
			XmNbottomAttachment,XmATTACH_POSITION,
                        XmNbottomPosition, 18,
                        XmNbackground,Appcolor.pixel,
                        XmNforeground,Framecolor.pixel,
                        XmNfontList,fontlist,
			NULL);
  XmStringFree(str);

 dial->spl_d_fr_f_radiobox =
  XtVaCreateManagedWidget("spl_d_fr_f_radiobox",
                        xmRowColumnWidgetClass, 
                        dial->split_down_frame_form,
			XmNleftAttachment,XmATTACH_FORM,
			XmNrightAttachment,XmATTACH_FORM,
                        XmNtopAttachment,XmATTACH_WIDGET,
                        XmNtopWidget, dial->spl_d_fr_f_label,
                        XmNradioBehavior, True,
                        XmNradioAlwaysOne, True,
                        XmNisHomogeneous, True,
                        XmNentryClass, xmToggleButtonWidgetClass,
                        XmNpacking, XmPACK_COLUMN,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL);

 dial->spl_d_fr_f_split_middle =
  XtVaCreateManagedWidget("split_middle",
                        xmToggleButtonWidgetClass, 
                        dial->spl_d_fr_f_radiobox,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
 if(SPLIT_STRATEGY==1)                       
  XmToggleButtonSetState(dial->spl_d_fr_f_split_middle,TRUE,FALSE);
 else 
  XmToggleButtonSetState(dial->spl_d_fr_f_split_middle,FALSE,FALSE);

 dial->spl_d_fr_f_split_max =
  XtVaCreateManagedWidget("split_max",
                        xmToggleButtonWidgetClass, 
                        dial->spl_d_fr_f_radiobox,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist, 
                        NULL); 
 if(SPLIT_STRATEGY==2)                       
  XmToggleButtonSetState(dial->spl_d_fr_f_split_max,TRUE,FALSE);
 else 
  XmToggleButtonSetState(dial->spl_d_fr_f_split_max,FALSE,FALSE);

 dial->spl_d_fr_f_split_50_50 =
  XtVaCreateManagedWidget("split_50_50",
                        xmToggleButtonWidgetClass, 
                        dial->spl_d_fr_f_radiobox,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
 if(SPLIT_STRATEGY==3)                       
  XmToggleButtonSetState(dial->spl_d_fr_f_split_50_50,TRUE,FALSE);
 else
  XmToggleButtonSetState(dial->spl_d_fr_f_split_50_50,FALSE,FALSE);


  dial->spl_d_fr_f_min_form =
   XtVaCreateManagedWidget("spl_d_fr_f_min_form",xmFormWidgetClass,
                          dial->split_down_frame_form, 
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->spl_d_fr_f_radiobox,
                          XmNleftAttachment, XmATTACH_FORM,
                          XmNrightAttachment, XmATTACH_FORM,
                          XmNfractionBase, 100,
                          XmNbackground,Appcolor.pixel,
                          NULL);

  str=XmStringCreateLocalized("split_min:");
  dial->spl_d_fr_f_min_label =
   XtVaCreateManagedWidget("spl_d_fr_f_min_label",
			xmLabelWidgetClass, 
			dial->spl_d_fr_f_min_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 0,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist, 
			NULL);
  XmStringFree(str);


 char inhalt[50];
 sprintf(inhalt,"%d",_SPLIT_MIN_);
 dial->spl_d_fr_f_min_text =
  XtVaCreateManagedWidget("spl_d_fr_f_min_text",
			xmTextFieldWidgetClass, 
			dial->spl_d_fr_f_min_form,
			XmNtraversalOn,      True,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
			XmNleftAttachment,   XmATTACH_WIDGET,
                        XmNleftWidget, dial->spl_d_fr_f_min_label,
			XmNvalue,inhalt,
			XmNcolumns,5,
			XmNpendingDelete,True,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);


  XtManageChild(dial->spl_d_fr_f_min_text);
  XtManageChild(dial->spl_d_fr_f_min_label);
  XtManageChild(dial->spl_d_fr_f_min_form);
  XtManageChild(dial->spl_d_fr_f_split_50_50);
  XtManageChild(dial->spl_d_fr_f_split_max);
  XtManageChild(dial->spl_d_fr_f_split_middle);
  XtManageChild(dial->spl_d_fr_f_radiobox);
  XtManageChild(dial->spl_d_fr_f_label);
  XtManageChild(dial->split_down_frame_form);
  XtManageChild(dial->split_down_frame);
  XtManageChild(dial->split_down_form);
  XtManageChild(dial->split_form_ok);
  XtManageChild(dial->split_up_form);
  XtManageChild(dial->split_form_dialog);
                                    
                                                                        
}



void split_form_ok_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

 if(XmToggleButtonGetState(dial->spl_d_fr_f_split_middle)==True) 
  SPLIT_STRATEGY=1;
 if(XmToggleButtonGetState(dial->spl_d_fr_f_split_max)==True) 
  SPLIT_STRATEGY=2;
 if(XmToggleButtonGetState(dial->spl_d_fr_f_split_50_50)==True) 
  SPLIT_STRATEGY=3;
  
 char *inhalt;
 int ret,i;
 inhalt=XmTextGetString(dial->spl_d_fr_f_min_text);
 ret=sscanf(inhalt,"%d",&i);
 if(ret != 1)
  {
   //Melde Fehler

   ErrorMessage(0);
  }
 else 
  _SPLIT_MIN_=i;
 XtFree(inhalt);


 XtDestroyWidget(dial->split_form_dialog);
 XtDestroyWidget(dial->split_up_form);
 XtDestroyWidget(dial->split_form_ok);
 XtDestroyWidget(dial->split_down_form);
 XtDestroyWidget(dial->split_down_frame);
 XtDestroyWidget(dial->split_down_frame_form);
 XtDestroyWidget(dial->spl_d_fr_f_label);
 XtDestroyWidget(dial->spl_d_fr_f_radiobox);
 XtDestroyWidget(dial->spl_d_fr_f_split_middle);
 XtDestroyWidget(dial->spl_d_fr_f_split_max);
 XtDestroyWidget(dial->spl_d_fr_f_split_50_50);
 XtDestroyWidget(dial->spl_d_fr_f_min_form);
 XtDestroyWidget(dial->spl_d_fr_f_min_label);
 XtDestroyWidget(dial->spl_d_fr_f_min_text);

 SPLIT_ACTIVE=0;
}




void flags_form_constr_button_callback(Widget w,
                                    XtPointer client_data,
                                    XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

 if(CONSTR_ACTIVE==1)
  return;

 CONSTR_ACTIVE=1;

  dial->constr_form_dialog =
   XmCreateFormDialog( wnd_toplevel, "constr",
                         NULL,0);


  dial->constr_up_form =
   XtVaCreateManagedWidget("constr_up_form",xmFormWidgetClass,
                   dial->constr_form_dialog,
                   XmNtopAttachment,XmATTACH_FORM,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNfractionBase, 100,
                   XmNbackground,Appcolor.pixel,
                   NULL);

  dial->constr_form_ok =
   XtVaCreateManagedWidget("ok",xmPushButtonWidgetClass,
                          dial->constr_up_form,
                          XmNtopAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 15,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 85,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 20,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 70,
                          XmNbackground,Buttoncolor.pixel,
                          XmNfontList,fontlist,
                          NULL);
 XtAddCallback(dial->constr_form_ok,
               XmNactivateCallback,
               constr_form_ok_callback,
               NULL);

  dial->constr_down_form =
   XtVaCreateManagedWidget("constr_down_form",xmFormWidgetClass,
                          dial->constr_form_dialog, 
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->constr_up_form,
                          XmNleftAttachment, XmATTACH_FORM,
                          XmNrightAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNfractionBase, 100,
                          XmNbackground,Appcolor.pixel,
                          NULL);


  dial->constr_down_frame =
   XtVaCreateManagedWidget("constr_down_frame",xmFrameWidgetClass,
                          dial->constr_down_form,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 10,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 90,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 10,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 90,
                          XmNbackground,Framecolor.pixel,
                          NULL);


  dial->constr_down_frame_form =
   XtVaCreateManagedWidget("constr_down_frame_form",xmFormWidgetClass,
                   dial->constr_down_frame, 
                   XmNfractionBase, 105,
                   XmNbackground,Appcolor.pixel,
                   NULL);

  str=XmStringCreateLocalized("construction order:");
  dial->con_d_f_label =
   XtVaCreateManagedWidget("con_d_f_label",
			xmLabelWidgetClass, 
			dial->constr_down_frame_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 0,
			XmNtopAttachment,XmATTACH_POSITION,
                        XmNtopPosition, 5,
			XmNbottomAttachment,XmATTACH_POSITION,
                        XmNbottomPosition, 18,
                        XmNbackground,Appcolor.pixel,
                        XmNforeground,Framecolor.pixel,
                        XmNfontList,fontlist,
			NULL);
  XmStringFree(str);

  dial->con_d_fr_f_fr1 =
   XtVaCreateManagedWidget("con_d_fr_f_fr1",xmFrameWidgetClass,
                          dial->constr_down_frame_form,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 0,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 105,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 25,
                          XmNbackground,Framecolor.pixel,
                          NULL);

 dial->con_d_fr_f_radiobox1 =
  XtVaCreateManagedWidget("con_d_fr_f_radiobox1",
                        xmRowColumnWidgetClass, 
                        dial->con_d_fr_f_fr1,
                        XmNradioBehavior, True,
                        XmNradioAlwaysOne, True,
                        XmNisHomogeneous, True,
                        XmNentryClass, xmToggleButtonWidgetClass,
                        XmNpacking, XmPACK_COLUMN,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL);

 dial->con_d_fr_f_smblfi =
  XtVaCreateManagedWidget("small blocks first",
                        xmToggleButtonWidgetClass, 
                        dial->con_d_fr_f_radiobox1,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 

 dial->con_d_fr_f_lablfi =
  XtVaCreateManagedWidget("large blocks first",
                        xmToggleButtonWidgetClass, 
                        dial->con_d_fr_f_radiobox1,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,  
                        NULL); 

 if(_SPLIT_KLEIN_==1)    
  {                   
   XmToggleButtonSetState(dial->con_d_fr_f_smblfi,TRUE,FALSE);
   XmToggleButtonSetState(dial->con_d_fr_f_lablfi,FALSE,FALSE);
  }
 else
  {                   
   XmToggleButtonSetState(dial->con_d_fr_f_smblfi,FALSE,FALSE);
   XmToggleButtonSetState(dial->con_d_fr_f_lablfi,TRUE,FALSE);
  }


  dial->con_d_fr_f_fr2 =
   XtVaCreateManagedWidget("con_d_fr_f_fr2",xmFrameWidgetClass,
                          dial->constr_down_frame_form,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 0,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 105,
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->con_d_fr_f_fr1,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNbackground,Framecolor.pixel,
                          NULL);

 dial->con_d_fr_f_radiobox2 =
  XtVaCreateManagedWidget("con_d_fr_f_radiobox2",
                        xmRowColumnWidgetClass, 
                        dial->con_d_fr_f_fr2,
                        XmNradioBehavior, True,
                        XmNradioAlwaysOne, True,
                        XmNisHomogeneous, True,
                        XmNentryClass, xmToggleButtonWidgetClass,
                        XmNpacking, XmPACK_COLUMN,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL);


 dial->con_d_fr_f_maincfi =
  XtVaCreateManagedWidget("many incidences first",
                        xmToggleButtonWidgetClass, 
                        dial->con_d_fr_f_radiobox2,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel, 
                        XmNfontList,fontlist,
                        NULL); 
 if(_SHIFT_PARTITIONS_==0)                       
  XmToggleButtonSetState(dial->con_d_fr_f_maincfi,TRUE,FALSE);
 else 
  XmToggleButtonSetState(dial->con_d_fr_f_maincfi,FALSE,FALSE);

 dial->con_d_fr_f_feincfi =
  XtVaCreateManagedWidget("few incidences first",
                        xmToggleButtonWidgetClass, 
                        dial->con_d_fr_f_radiobox2,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
 if(_SHIFT_PARTITIONS_==2)                       
  XmToggleButtonSetState(dial->con_d_fr_f_feincfi,TRUE,FALSE);
 else 
  XmToggleButtonSetState(dial->con_d_fr_f_feincfi,FALSE,FALSE);

 dial->con_d_fr_f_avincfi =
  XtVaCreateManagedWidget("average incidences first",
                        xmToggleButtonWidgetClass, 
                        dial->con_d_fr_f_radiobox2,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
 if(_SHIFT_PARTITIONS_==1)                       
  XmToggleButtonSetState(dial->con_d_fr_f_avincfi,TRUE,FALSE);
 else 
  XmToggleButtonSetState(dial->con_d_fr_f_avincfi,FALSE,FALSE);


  XtManageChild(dial->con_d_fr_f_avincfi);
  XtManageChild(dial->con_d_fr_f_feincfi);
  XtManageChild(dial->con_d_fr_f_maincfi);
  XtManageChild(dial->con_d_fr_f_radiobox2);
  XtManageChild(dial->con_d_fr_f_fr2);
  XtManageChild(dial->con_d_fr_f_lablfi);
  XtManageChild(dial->con_d_fr_f_smblfi);
  XtManageChild(dial->con_d_fr_f_radiobox1);
  XtManageChild(dial->con_d_fr_f_fr1);
  XtManageChild(dial->con_d_f_label);
  XtManageChild(dial->constr_down_frame_form);
  XtManageChild(dial->constr_down_frame);
  XtManageChild(dial->constr_down_form);
  XtManageChild(dial->constr_form_ok);
  XtManageChild(dial->constr_up_form);
  XtManageChild(dial->constr_form_dialog);
                                                                        
}


void constr_form_ok_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;


 if(XmToggleButtonGetState(dial->con_d_fr_f_smblfi)==True) 
  _SPLIT_KLEIN_=1;
 else 
  _SPLIT_KLEIN_=0;
 if(XmToggleButtonGetState(dial->con_d_fr_f_maincfi)==True) 
  _SHIFT_PARTITIONS_=0;
 if(XmToggleButtonGetState(dial->con_d_fr_f_feincfi)==True) 
  SHIFT_PARTITIONS=2;
 if(XmToggleButtonGetState(dial->con_d_fr_f_avincfi)==True) 
  _SHIFT_PARTITIONS_=1;


 XtDestroyWidget(dial->constr_form_dialog);
 XtDestroyWidget(dial->constr_up_form);
 XtDestroyWidget(dial->constr_form_ok);
 XtDestroyWidget(dial->constr_down_form);
 XtDestroyWidget(dial->constr_down_frame);
 XtDestroyWidget(dial->constr_down_frame_form);
 XtDestroyWidget(dial->con_d_f_label);
 XtDestroyWidget(dial->con_d_fr_f_fr1);
 XtDestroyWidget(dial->con_d_fr_f_radiobox1);
 XtDestroyWidget(dial->con_d_fr_f_smblfi);
 XtDestroyWidget(dial->con_d_fr_f_lablfi);
 XtDestroyWidget(dial->con_d_fr_f_fr2);
 XtDestroyWidget(dial->con_d_fr_f_radiobox2);
 XtDestroyWidget(dial->con_d_fr_f_maincfi);
 XtDestroyWidget(dial->con_d_fr_f_feincfi);
 XtDestroyWidget(dial->con_d_fr_f_avincfi);

 CONSTR_ACTIVE=0;
}


void quit_button_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 if(is_running)
  {
   int grad_pid;
   FILE *h_f=NULL;
   while(h_f==NULL)
     h_f=fopen("HELP_PID","r");
   fscanf(h_f,"%d",&help_pid);
   fclose(h_f);
   kill(help_pid,9);
   XtRemoveTimeOut(PipeId);
   XtRemoveTimeOut(TimeId);
   pclose(erg_pipe);
  } 
 exit(0);                                   
}


void start_button_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 FILE *out;
 char *degpart=NULL,*hilfpart; 
 int maxgrad; 
 short part[100];
 int n,i,j,k,l,m,ret;
 int _n,_k;


 if(is_running)
  {
   ErrorMessage(6);
   return;
  }
 
if(XmToggleButtonGetState(dial->degree_toggle)==True) 
{
 //Gradpartition vorgegeben
     
 degpart=XmTextGetString(dial->dp_text);
 hilfpart=degpart;
 for(i=0;i<100;i++)
  part[i]=0;
 maxgrad=0;

 i=strlen(degpart);
 k=0;
 for(j=0;j<i;j++)
  {
   if(degpart[j]=='x')
    k++;
  }
 //k Eintraege
 for(j=1;j<=k;j++)
  {
   ret=sscanf(degpart,"%dx%d",&i,&l);
   if(ret != 2)
    {
     XtFree(hilfpart);
     ErrorMessage(1);
     return;
    }
   if(maxgrad < l)
    maxgrad=l;
   part[l]=i; 
   if(j < k)
    {
     while(degpart[0] != 'x')
      degpart++;
     degpart++;
     while(isdigit(degpart[0]))
      degpart++;   
     if(! isspace(degpart[0]))
      {
       XtFree(hilfpart);
       ErrorMessage(1);
       return;
      }  
    }  
  }
 //Partition gelesen
 XtFree(hilfpart);

 i=0;
 for(j=1;j<=maxgrad;j++)
  i+=j*part[j];
 if(i%2 != 0)
  {
   ErrorMessage(2);
   return;
  } 

 k=i/2;
 n=0;
 for(i=1;i<=maxgrad;i++)
  n+=part[i];
 if(maxgrad > (n-1)*MAXBOND)
  {
   ErrorMessage(4);
   return;
  }
  
 a_part.Init(n,k,MAXBOND);
 for(i=0;i<=maxgrad;i++)
  a_part.GetVertAnz(i)=part[i];
 for(i=maxgrad+1;i<n;i++)
  a_part.GetVertAnz(i)=0;
 if(! a_part.IsGraphic())
  {
   ErrorMessage(3);
   return;
  }
 if(TREES_ONLY && (MAXBOND > 1))
  {
   ErrorMessage(16);
   return;
  }

  
 out=fopen("GRAD_EIN","w");
 fprintf(out,"TREES_ONLY %d\n",TREES_ONLY);
 fprintf(out,"GIRTH %d\n",GIRTH);
 fprintf(out,"MAXBOND %d\n",MAXBOND);
 fprintf(out,"CONN %d\n",CONN_GRAPHS);
 fprintf(out,"MAXGRAD %d\n",maxgrad);
 for(i=0;i<=maxgrad;i++)
  fprintf(out,"%d ",part[i]);
 fprintf(out,"\n");
 fclose(out); 

 //Gradpartition ist geschrieben
}
else
{
 char *knot,*kant;
 
 knot=XmTextGetString(dial->vert_edge_up_text);
 ret=sscanf(knot,"%d",&_n);
 XtFree(knot);
 if(ret != 1)
  {
   ErrorMessage(8);
   return;
  }
 kant=XmTextGetString(dial->vert_edge_down_text);
 if(strcmp(kant,"")==0)
  _k=-1;
 else
  { 
   ret=sscanf(kant,"%d",&_k);
   XtFree(kant);
   if(ret != 1)
    {
     ErrorMessage(9);
     return;
    }
  }
 if(TREES_ONLY && (MAXBOND > 1))
  {
   ErrorMessage(16);
   return;
  }

 out=fopen("GRAD_EIN","w");
 fprintf(out,"TREES_ONLY %d\n",TREES_ONLY);
 fprintf(out,"GIRTH %d\n",GIRTH);
 fprintf(out,"MAXBOND %d\n",MAXBOND);
 fprintf(out,"CONN %d\n",CONN_GRAPHS);
 if(_k == -1)
  fprintf(out,"VERTICES %d\n",_n);
 else
  fprintf(out,"VERTICES %d EDGES %d\n",_n,_k); 
 fclose(out);
} 

 char *stepanz;
 int _steps;
 stepanz=XmTextGetString(dial->step_text);
 ret=sscanf(stepanz,"%d",&_steps);
 XtFree(stepanz);
 if(ret != 1)
  {
   ErrorMessage(5);
   return;
  }
 
 out=fopen("FLAGS","w");
 fprintf(out,"VERBOSE %d\n",_VERBOSE_);
 fprintf(out,"HASH_LENGTH 1000\n");
 fprintf(out,"GALE_LIMIT 100\n");
 fprintf(out,"SPLIT_KLEIN %d\n",_SPLIT_KLEIN_);
 fprintf(out,"SPLIT_MIN %d\n",_SPLIT_MIN_);
 fprintf(out,"GO_IMPL %d\n",_GO_IMPL_);
 fprintf(out,"RECONSTRUCT_ALL %d\n",_RECONSTRUCT_ALL_);
 fprintf(out,"PRECOMPUTE_SPLITS %d\n",_PRECOMPUTE_SPLITS_);
 if(SPLIT_STRATEGY==1)
  fprintf(out,"SPLIT_MIDDLE\n");
 if(SPLIT_STRATEGY==2)
  fprintf(out,"SPLIT_MAX\n");
 if(SPLIT_STRATEGY==3)
  fprintf(out,"SPLIT_50_50\n");
 fprintf(out,"SHIFT_PARTITIONS %d\n",_SHIFT_PARTITIONS_);
 fprintf(out,"STEPS_TO_SAVE %d\n",_steps);
 fclose(out);

 XmTextReplace(dial->scrolled_text,0,
               XmTextGetLastPosition(dial->scrolled_text),
                text_default_value); 
 
 XmTextSetInsertionPosition(dial->scrolled_text,
                            XmTextGetLastPosition(dial->scrolled_text)); 

 unlink("HELP_PID");
 erg_pipe=popen("Gradpart < GRAD_EIN","r");
 #ifndef DEC_ALPHA
  fcntl(fileno(erg_pipe),F_SETFL,O_NONBLOCK);
 #endif

 is_running=1;

 PipeId =
  XtAppAddTimeOut(XtWidgetToApplicationContext(dial->scrolled_text),
                  200,get_pipe_input,dial->scrolled_text);
 days=0;hours=0;minutes=0;seconds=0;seconds_10=0;
 delay=100;
 TimeId =
  XtAppAddTimeOut(XtWidgetToApplicationContext(dial->time_label),
                  100,time_output,(XtPointer)NULL);

}




void stop_button_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 char command[100];        
 int grad_pid;

 if(is_running==0)
  {
   ErrorMessage(7);
   return;
  }
  
 FILE *h_f=NULL;
 while(h_f==NULL)
   h_f=fopen("HELP_PID","r");
 fscanf(h_f,"%d",&help_pid);
 fclose(h_f);
 kill(help_pid,9);
 XtRemoveTimeOut(PipeId);
 XtRemoveTimeOut(TimeId);
 pclose(erg_pipe);
 is_running=0;
 insert_text("\ncomputation stopped !!\n");
}


void draw_button_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 FILE *test;
 test=fopen("Z","r");
 if(test != NULL)
  return; 
 fclose(test);

 system("draw.out ERG &");                                    
}


void restr_button_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

 if(RESTR_ACTIVE==1)
  return;

 RESTR_ACTIVE=1;

  dial->restr_form_dialog =
   XmCreateFormDialog( wnd_toplevel, "restr",
                         NULL,0);


  dial->restr_up_form =
   XtVaCreateManagedWidget("restr_up_form",xmFormWidgetClass,
                   dial->restr_form_dialog,
                   XmNtopAttachment,XmATTACH_FORM,
                   XmNleftAttachment,XmATTACH_FORM,
                   XmNrightAttachment,XmATTACH_FORM,
                   XmNfractionBase, 100,
                   XmNbackground,Appcolor.pixel,
                   NULL);

  dial->restr_form_ok =
   XtVaCreateManagedWidget("ok",xmPushButtonWidgetClass,
                          dial->restr_up_form,
                          XmNtopAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 15,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 85,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 20,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 70,
                          XmNbackground,Buttoncolor.pixel,
                          XmNfontList,fontlist,
                          NULL);
 XtAddCallback(dial->restr_form_ok,
               XmNactivateCallback,
               restr_form_ok_callback,
               NULL);

  dial->restr_down_form =
   XtVaCreateManagedWidget("restr_down_form",xmFormWidgetClass,
                          dial->restr_form_dialog, 
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->restr_up_form,
                          XmNleftAttachment, XmATTACH_FORM,
                          XmNrightAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNfractionBase, 100,
                          XmNbackground,Appcolor.pixel,
                          NULL);


  dial->restr_down_frame =
   XtVaCreateManagedWidget("restr_down_frame",xmFrameWidgetClass,
                          dial->restr_down_form,
                          XmNleftAttachment, XmATTACH_POSITION,
                          XmNleftPosition, 10,
                          XmNrightAttachment, XmATTACH_POSITION,
                          XmNrightPosition, 90,
                          XmNtopAttachment, XmATTACH_POSITION,
                          XmNtopPosition, 10,
                          XmNbottomAttachment, XmATTACH_POSITION,
                          XmNbottomPosition, 90,
                          XmNbackground,Framecolor.pixel,
                          NULL);


  dial->restr_down_frame_form =
   XtVaCreateManagedWidget("restr_down_frame_form",xmFormWidgetClass,
                   dial->restr_down_frame, 
                   XmNfractionBase, 105,
                   XmNbackground,Appcolor.pixel,
                   NULL);


  dial->restr_conn_toggle =
   XtVaCreateManagedWidget("only connected graphs",
                        xmToggleButtonWidgetClass, 
			dial->restr_down_frame_form,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 1,
			XmNtopAttachment,XmATTACH_FORM,
                        XmNindicatorType, XmN_OF_MANY,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
  if(CONN_GRAPHS == 0)
   XmToggleButtonSetState(dial->restr_conn_toggle,FALSE,FALSE);
  else
   XmToggleButtonSetState(dial->restr_conn_toggle,TRUE,FALSE);


  dial->restr_tree_toggle =
   XtVaCreateManagedWidget("only trees",
                        xmToggleButtonWidgetClass, 
			dial->restr_down_frame_form,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 1,
                        XmNtopAttachment, XmATTACH_WIDGET,
                        XmNtopWidget, dial->restr_conn_toggle,
                        XmNindicatorType, XmN_OF_MANY,
                        XmNbackground,Appcolor.pixel,
                        XmNselectColor,Selectcolor.pixel,
                        XmNfontList,fontlist,
                        NULL); 
  if(TREES_ONLY == 0)
   XmToggleButtonSetState(dial->restr_tree_toggle,FALSE,FALSE);
  else
   XmToggleButtonSetState(dial->restr_tree_toggle,TRUE,FALSE);


  dial->restr_girth_form =
   XtVaCreateManagedWidget("restr_girth_form",xmFormWidgetClass,
                          dial->restr_down_frame_form, 
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->restr_tree_toggle,
                          XmNleftAttachment, XmATTACH_FORM,
                          XmNrightAttachment, XmATTACH_FORM,
                          XmNfractionBase, 100,
                          XmNbackground,Appcolor.pixel,
                          XmNfontList,fontlist,
                          NULL);


  str=XmStringCreateLocalized("girth:     ");
  dial->restr_girth_label =
   XtVaCreateManagedWidget("restr_girth_label",
			xmLabelWidgetClass, 
			dial->restr_girth_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 0,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist, 
			NULL);
  XmStringFree(str);


 char inhalt[50];
 sprintf(inhalt,"%d",GIRTH);
 dial->restr_girth_text =
  XtVaCreateManagedWidget("restr_girth_text",
			xmTextFieldWidgetClass, 
			dial->restr_girth_form,
			XmNtraversalOn,      True,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
			XmNleftAttachment,   XmATTACH_WIDGET,
                        XmNleftWidget, dial->restr_girth_label,
			XmNvalue,inhalt,
			XmNcolumns,5,
			XmNpendingDelete,True,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);



  dial->restr_bond_form =
   XtVaCreateManagedWidget("restr_bond_form",xmFormWidgetClass,
                          dial->restr_down_frame_form, 
                          XmNtopAttachment, XmATTACH_WIDGET,
                          XmNtopWidget, dial->restr_girth_form,
                          XmNleftAttachment, XmATTACH_FORM,
                          XmNrightAttachment, XmATTACH_FORM,
                          XmNbottomAttachment, XmATTACH_FORM,
                          XmNfractionBase, 100,
                          XmNbackground,Appcolor.pixel,
                          NULL);

  str=XmStringCreateLocalized("max. bond: ");
  dial->restr_bond_label =
   XtVaCreateManagedWidget("restr_bond_label",
			xmLabelWidgetClass, 
			dial->restr_bond_form,
			XmNlabelString, str,
			XmNleftAttachment,XmATTACH_POSITION,
                        XmNleftPosition, 0,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);
  XmStringFree(str);


 sprintf(inhalt,"%d",MAXBOND);
 dial->restr_bond_text =
  XtVaCreateManagedWidget("restr_bond_text",
			xmTextFieldWidgetClass, 
			dial->restr_bond_form,
			XmNtraversalOn,      True,
			XmNtopAttachment,XmATTACH_FORM,
			XmNbottomAttachment,XmATTACH_FORM,
			XmNleftAttachment,   XmATTACH_WIDGET,
                        XmNleftWidget, dial->restr_bond_label,
			XmNvalue,inhalt,
			XmNcolumns,5,
			XmNpendingDelete,True,
                        XmNbackground,Appcolor.pixel,
                        XmNfontList,fontlist,
			NULL);

  XtManageChild(dial->restr_bond_text);
  XtManageChild(dial->restr_bond_label);
  XtManageChild(dial->restr_bond_form);
  XtManageChild(dial->restr_girth_text);
  XtManageChild(dial->restr_girth_label);
  XtManageChild(dial->restr_girth_form);
  XtManageChild(dial->restr_conn_toggle);
  XtManageChild(dial->restr_tree_toggle);
  XtManageChild(dial->restr_down_frame_form);
  XtManageChild(dial->restr_down_frame);
  XtManageChild(dial->restr_down_form);
  XtManageChild(dial->restr_form_ok);
  XtManageChild(dial->restr_up_form);
  XtManageChild(dial->restr_form_dialog);

}



void restr_form_ok_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

 if(XmToggleButtonGetState(dial->restr_tree_toggle)==True) 
  TREES_ONLY = 1;
 else
  TREES_ONLY = 0;

 if(XmToggleButtonGetState(dial->restr_conn_toggle)==True) 
  CONN_GRAPHS = 1;
 else
  CONN_GRAPHS = 0;

 char *inhalt;
 int ret,i;
 inhalt=XmTextGetString(dial->restr_girth_text);
 ret=sscanf(inhalt,"%d",&i);
 if(ret != 1)
   ErrorMessage(14);
 else 
  GIRTH=i;
 XtFree(inhalt);

 inhalt=XmTextGetString(dial->restr_bond_text);
 ret=sscanf(inhalt,"%d",&i);
 if(ret != 1)
   ErrorMessage(15);
 else 
  MAXBOND=i;
 XtFree(inhalt);


 XtDestroyWidget(dial->restr_form_dialog);
 XtDestroyWidget(dial->restr_up_form);
 XtDestroyWidget(dial->restr_form_ok);
 XtDestroyWidget(dial->restr_down_form);
 XtDestroyWidget(dial->restr_down_frame);
 XtDestroyWidget(dial->restr_down_frame_form);
 XtDestroyWidget(dial->restr_conn_toggle);
 XtDestroyWidget(dial->restr_tree_toggle);
 XtDestroyWidget(dial->restr_girth_form);
 XtDestroyWidget(dial->restr_girth_label);
 XtDestroyWidget(dial->restr_girth_text);
 XtDestroyWidget(dial->restr_bond_form);
 XtDestroyWidget(dial->restr_bond_label);
 XtDestroyWidget(dial->restr_bond_text);

 RESTR_ACTIVE=0;
}




void dp_file_callback(Widget w,
                          XtPointer client_data,
                          XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;


  dial->file_sel_shell =
   XmCreateDialogShell(wnd_toplevel,"file_sel_shell",NULL,0);
  
  dial->file_sel_box =
   XtVaCreateManagedWidget("file_sel_box",
                            xmFileSelectionBoxWidgetClass,
                            dial->file_sel_shell,
                            XmNbackground,Appcolor.pixel,
                            XmNfontList,fontlist,
                            NULL);
  
  XmChangeColor(XmFileSelectionBoxGetChild(dial->file_sel_box,
                                           XmDIALOG_FILTER_TEXT),
                Appcolor.pixel);                           
  XmChangeColor(XmFileSelectionBoxGetChild(dial->file_sel_box,
                                           XmDIALOG_DIR_LIST),
                Appcolor.pixel);                           
  XmChangeColor(XmFileSelectionBoxGetChild(dial->file_sel_box,
                                           XmDIALOG_TEXT),
                Appcolor.pixel);                           
  XmChangeColor(XmFileSelectionBoxGetChild(dial->file_sel_box,
                                           XmDIALOG_LIST),
                Appcolor.pixel);                           
  XmChangeColor(XmFileSelectionBoxGetChild(dial->file_sel_box,
                                           XmDIALOG_SEPARATOR),
                Appcolor.pixel);                           


  XtAddCallback(dial->file_sel_box,XmNcancelCallback,file_sel_cancel,NULL); 
  XtAddCallback(dial->file_sel_box,XmNokCallback,file_sel_ok,NULL); 

}


void file_sel_cancel(Widget w,
                     XtPointer client_data,
                     XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;


 XtDestroyWidget(dial->file_sel_box);
 XtDestroyWidget(dial->file_sel_shell);
}


void file_sel_ok(Widget w,
                 XtPointer client_data,
                 XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;


 char *filename;
 XmFileSelectionBoxCallbackStruct *cbs=
   (XmFileSelectionBoxCallbackStruct*) call_data;
 if(! XmStringGetLtoR(cbs->value,XmFONTLIST_DEFAULT_TAG,
     &filename))
  {
   ErrorMessage(10);
   XtDestroyWidget(dial->file_sel_box);
   XtDestroyWidget(dial->file_sel_shell);
   return;
  }
 FILE *in;
 in=fopen(filename,"r");
 if(in==NULL)
  {
   ErrorMessage(11);
   XtFree(filename);
   XtDestroyWidget(dial->file_sel_box);
   XtDestroyWidget(dial->file_sel_shell);
   return;
  }
 int maxgrad,_TREES_ONLY,_GIRTH,_MAXBOND,_CONN_GRAPHS;;
 short part[100];
 int ret,i,j;
 for(i=0;i<100;i++)
  part[i]=0;


 ret=fscanf(in,"TREES_ONLY %d\n",&_TREES_ONLY);
 if(ret != 1)
  {
   ErrorMessage(12);
   XtFree(filename);
   XtDestroyWidget(dial->file_sel_box);
   XtDestroyWidget(dial->file_sel_shell);
   return;
  }

 ret=fscanf(in,"GIRTH %d\n",&_GIRTH);
 if(ret != 1)
  {
   ErrorMessage(12);
   XtFree(filename);
   XtDestroyWidget(dial->file_sel_box);
   XtDestroyWidget(dial->file_sel_shell);
   return;
  }
 ret=fscanf(in,"MAXBOND %d\n",&_MAXBOND);
 if(ret != 1)
  {
   ErrorMessage(12);
   XtFree(filename);
   XtDestroyWidget(dial->file_sel_box);
   XtDestroyWidget(dial->file_sel_shell);
   return;
  }
 ret=fscanf(in,"CONN %d\n",&_CONN_GRAPHS);
 if(ret != 1)
  {
   ErrorMessage(12);
   XtFree(filename);
   XtDestroyWidget(dial->file_sel_box);
   XtDestroyWidget(dial->file_sel_shell);
   return;
  }

 ret=fscanf(in,"MAXGRAD %d",&j);
 if((ret != 1)||(j > 99)||(j < 0))
  {
   ErrorMessage(12);
   XtFree(filename);
   XtDestroyWidget(dial->file_sel_box);
   XtDestroyWidget(dial->file_sel_shell);
   return;
  }
 maxgrad=j;

 for(i=0;i<=maxgrad;i++)
  {
   ret=fscanf(in,"%d",&j);
   if(ret != 1)
    {
     ErrorMessage(12);
     XtFree(filename);
     XtDestroyWidget(dial->file_sel_box);
     XtDestroyWidget(dial->file_sel_shell);
     return;
    }
   part[i]=j;
  }

 GIRTH = _GIRTH;
 MAXBOND = _MAXBOND;
 CONN_GRAPHS = _CONN_GRAPHS;
 char dep_part[300];
 char dummy[10];
 strcpy(dep_part,"");
 i=0;
 for(j=0;j<=maxgrad;j++)
  {
   if(part[j] > 0)
    {
     sprintf(dummy,"%dx%d ",part[j],j);
     strcat(dep_part,dummy);
    }
  } 

 XmTextSetString(dial->dp_text,dep_part);

 XtFree(filename);
 XtDestroyWidget(dial->file_sel_box);
 XtDestroyWidget(dial->file_sel_shell);
}



void error_dialog_callback(Widget w,
                 XtPointer client_data,
                 XtPointer call_data)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;

 XtDestroyWidget(dial->error_dialog);
 XtDestroyWidget(dial->error_dialog_shell);

}


void ErrorMessage(int i)
{
 GP_DIAL *dial;
 dial = gl_gp_dial;
 XmString str = (XmString) NULL;

  dial->error_dialog_shell=
   XtCreateWidget("Input Error",
                  xmDialogShellWidgetClass,
                  wnd_toplevel,
                  NULL,0);
  str=XmStringCreateLocalized(err_string[i]);
  dial->error_dialog =
   XtVaCreateManagedWidget("error_dialog",xmMessageBoxWidgetClass,
                   dial->error_dialog_shell,
                   XmNdialogType,XmDIALOG_ERROR,
                   XmNbackground,ErrorColor.pixel,
                   XmNmessageString,str,
                   NULL);
   XmStringFree(str);

   XtManageChild(dial->error_dialog);
   XtManageChild(dial->error_dialog_shell);
   XtUnmanageChild(XmMessageBoxGetChild(dial->error_dialog,
                                        XmDIALOG_CANCEL_BUTTON));
   XtUnmanageChild(XmMessageBoxGetChild(dial->error_dialog,
                                        XmDIALOG_HELP_BUTTON));
   XtAddCallback(dial->error_dialog,XmNokCallback,
                 error_dialog_callback,NULL);    
}

                                                  


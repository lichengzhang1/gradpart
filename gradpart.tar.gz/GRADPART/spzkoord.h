#ifndef ORD_SP_Z_KOORD_H

#include "ordSpZ.h"
#include "koord.h"
#include "div.h"



class ORD_SP_Z_KOORD : public ORD_KOORD
{
 protected:
  VEKTOR < short >      z_soll; 
  VEKTOR < short >      sp_soll; 
  //Prescribed row- and columnsums for the whole matrix
  //These structures have to be allocated from the outside

  VEKTOR < short >      z_sums; 
  VEKTOR < short >      sp_sums; 
  //actual row- and columnsums

  VEKTOR < short >      next_s_u;
  VEKTOR < short >      next_s_o;
  VEKTOR < short >      next_z_u;
  VEKTOR < short >      next_z_o;

  GALE                  a_gale;
  BITVEK                gale_vek;

  char                  COLUMN_WISE_NUMBERING;
  PERMUT < short >      spaltenorder;
  //falls UNTERTEILE==0 und COLUMN_WISE_NUMBERING==1
  //so gibt diese Permutation die Reihenfolge der Spalten

 public:
                        ORD_SP_Z_KOORD();
                        ~ORD_SP_Z_KOORD();

  void                  FREE();
  void                  Init();
  int              BerechneEingabeData(int i);
  //returns 1, if no contradiction was discovered

  void                  SetCOLUMN_NUMBERING(PERMUT < short >& P)
                         {COLUMN_WISE_NUMBERING=1;spaltenorder= P;UNTERTEILE=0;}
  VEKTOR < short >&     Get_z_soll()  { return(z_soll); }
  VEKTOR < short >&     Get_sp_soll() { return(sp_soll); }

};


#define ORD_SP_Z_KOORD_H
#endif



/* draw.h */

#include "impldata.h"

#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/types.h>

#include <StringDefs.h>
#include <Intrinsic.h>
#include <Protocols.h>
#include <Shell.h>
#include <Xutil.h>
#include <cursorfont.h>
#include <Xlib.h>
#include <Xatom.h>
#include <BulletinB.h>
#include <CascadeB.h>
#include <DrawingA.h>
#include <Label.h>
#include <FileSB.h>
#include <PushB.h>
#include <PushBG.h>
#include <RowColumn.h>
#include <SelectioB.h>
#include <Separator.h>
#include <ScrolledW.h>
#include <ScrollBar.h>
#include <Text.h>

//#include <X11/Intrinsic.h>
//#include <X11/IntrinsicP.h>

extern "C" void XtMoveWidget(
    Widget 		/* widget */,
    _XtPosition		/* x */,
    _XtPosition		/* y */
);


#include <Xm.h>
#include <Xm/Scale.h>
#include <Xm/MessageB.h>


#include <Xm/DialogS.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/LabelG.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>

#include <Xm/MainW.h>


typedef struct gp_dial GP_DIAL;



struct gp_dial 
{
  Widget all_form;
     Widget input_form;
        Widget dp_frame;
           Widget dp_form;
              Widget dp_label;
        Widget anz_frame;
           Widget anz_form;
              Widget anz_label;
        Widget select_frame;
           Widget select_form;
              Widget select_label;
              Widget number_text;
        Widget button_frame;
           Widget button_fr_form; 
              Widget quit_button;
              Widget depth_label;
              Widget draw_button; 
              Widget split_line_button; 
              Widget split_tree_button;
              Widget up_button;
              Widget down_button;
     Widget draw_form;     
        Widget scroll_win;
           Widget draw_win;


  Widget split_tree_dialog;
     Widget tree_form;
        Widget scale_form;
           Widget h_scale;
           Widget w_scale;
        Widget tree_draw_form;
           Widget tree_draw_scroll;
              Widget tree_draw_area;
                 Widget *tree_buttons;


  Widget error_dialog_shell;
       Widget error_dialog;

};


char split_tree_visible;
short tree_button_anz,tree_button_length;
short old_tree_area_w,old_tree_area_h;
short tree_vater[150];
SPLITINFO **inf_point;
int SplitNr;

int main(int argc, char **argv);

Widget wnd_toplevel;
GP_DIAL *gl_gp_dial;

XFontStruct *gp_fnt;
XmFontList gp_font1, gp_curfont;

XtIntervalId TimeId;
XtAppContext gl_app;
GC gc;
XGCValues gcv;
Pixmap pixmap;
/* dimensions of drawing area (pixmap) */
Dimension width, height;
XtActionsRec actions;

void draw(Widget W,XEvent *event,String *args, unsigned int *num_args);

String translations = /* for the DrawingArea widget */
             "<Btn1Down>:   draw(down)\n\
              <Btn1Up>:     draw(up)  \n\
              <Btn1Motion>: draw(motion)";
                               

char ergdir[50];
LANGZAHL L1,L2,L3,L4;
IMPL_DATA *imp;
FILE *fp;
char SHOW_LINES;
char TIEFE,MAXTIEFE;
short *xcoords,*ycoords;
int vertex_nr;

XColor Appcolor,Framecolor,Buttoncolor,Selectcolor,
       ErrorColor,DrawBackColor,exact;
char AppCol[] = "wheat1";
char FrameCol[] = "RoyalBlue4";
char ButtonCol[] = "wheat2";
char SelectCol[] = "red"; 
char ErrCol[] = "LightSkyBlue";
char DrawBackCol[] = "grey87";


void CreateWidgets();
void GetColors();
void ErrorMessage(int i);
void ErrorMessage(char *mess);


char* err_string[] = 
 {"no number selected !!",
  "Please enter a numer between 1 and\n'number of stored graphs' ",
  "the selected number is too large !!",
  "only digits allowed !!" };


void Lese_anz_und_degree_part(int i);

void error_dialog_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void quit_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void up_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void down_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void split_line_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void split_tree_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void draw_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void tree_button_callback(Widget w,XtPointer client_data,
                               XtPointer call_data);
void ZeichneGraph(int tiefe);
void ZeichneGraphLocal();                              
void configure(Widget shell,XtPointer client_data,
               XEvent *event,char *p);                               








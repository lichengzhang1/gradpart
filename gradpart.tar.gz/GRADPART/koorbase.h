#ifndef KOORD_BASE_H

#include "ordtreu.h"


class KOORD_BASE
{
 protected:

  ORDTREU**                   ords;
  //array of classes with orderly generation
  short                       ords_anz;
  short                       MAX_VAL;
  short                       Zei;
  //number of rows
  LABRA_TG                    G;
  //operating group
  char                        GROUP_IS_ID;
  //==1, if G == id
  char                        AUT_IS_ID;
  char                        PRINT_SOLUTIONS;
  short                       schritte;
  //number of homomorphism steps
  BITVEK                      is_first;
  //is_first[i]==1, if we come into the i-th box for the
  //first time.

 public:

                              KOORD_BASE()
                               { ords_anz=0; ords=NULL; Zei=0; }

                              ~KOORD_BASE()
                               {
                                if(ords != NULL)
                                 {
                                  for(int i=1;i<=ords_anz;i++)
                                   delete ords[i];
                                  free(ords);
                                 } 
                               }

  void                        FREE();
  virtual void                Del(int z,int sp)=0;
  virtual int                 Set(int z,int sp,int wert)=0;
  virtual void                Init() = 0;
  //initialize all data-structures
  virtual int            BerechneEingabeData(int i) = 0;
  //computes the input data for ords[i] and initializes ords[i]
  virtual int            NextRep();
  //returns 1, if the next representative is found.
  virtual void                BerechneAufteilung()=0;
  //computes the partition of the matrix
  virtual void                NotiereLoesung()=0;
  virtual void                NotiereTeilLoesung(int index)=0;
  virtual void                PrintLoesung()=0;
  virtual LABRA_TG&           GetAut()=0;

  char&                       GetGROUP_IS_ID() { return(GROUP_IS_ID); }
  char&                       GetAUT_IS_ID() { return(AUT_IS_ID); }
  char&                       GetPRINT_SOLUTIONS()
                               { return(PRINT_SOLUTIONS); }
  LABRA_TG&                   GetGroup() { return(G); }
  short&                      GetZei()   { return(Zei); }
  short&                      GetMAX_VAL() { return(MAX_VAL); }

};


#define KOORD_BASE_H
#endif



#include "chem_num.h"

static void LOG(char *s)
{
 FILE *outf;
 outf = fopen("LOG.out","a");
 fprintf(outf,"%s",s);
 fclose(outf);
}


CHEM_NUM::CHEM_NUM(int _dim) : CAN_NUM(_dim)
{
 Init(_dim);
}


CHEM_NUM::CHEM_NUM() : CAN_NUM()
{
 return;
}


void CHEM_NUM::Init(int _dim)
{
 if((dim > 0)&&(dim != _dim))
  FREE();
 CAN_NUM::Init(_dim);
 typ_nr.ReAlloc(dim);
}


void CHEM_NUM::FREE()
{
 CAN_NUM::FREE();
 typ_nr.FREE();
}


void CHEM_NUM::Init(Molecule& molecule)
{
 int i,j,k,l,m;

 MAX_VAL = 8L;
 for(i=1;i<=dim;i++)
  for(j=i+1;j<=dim;j++)
    matrix[i][j] = matrix[j][i] = molecule.Ctab(i-1,j-1).symbol;
 for(i=1;i<=dim;i++)
  matrix[i][i] = 0;


 for(i=1;i<=dim;i++)
  typ_nr[i] = molecule.atom(i-1).typenum;

 typ_nr.Used() = dim;
 typ_nr.Sort();
 
 klassen[1].Used()=0;
 eins_el[1].Used()=0;
 new_eins_el[1].Used()=0;
 i=1;
 while(i <= dim)
  {
   if((i < dim)&&(typ_nr[i]==typ_nr[i+1]))
    {
     j = ++klassen[1].Used();
     klassen[1][j].Used()=0;
     for(l=1;l<=dim;l++)
      if(molecule.atom(l-1).typenum == typ_nr[i])
	klassen[1][j][++klassen[1][j].Used()] = l;
     while((i < dim)&&(typ_nr[i+1]==typ_nr[i]))
      i++;
     i++;
    }
   else
    {
     for(l=1;l<=dim;l++)
      if(molecule.atom(l-1).typenum == typ_nr[i])
       {
        eins_el[1][++eins_el[1].Used()] = l;
        new_eins_el[1][++new_eins_el[1].Used()] = l;
        break;
       } 
     i++;
    }
  }

}





#include "ordgraph.h"
#include <time.h>



MULTGRAPH::~MULTGRAPH()
{
}


//partition, maxgrad and max_val must be initialized 
//before 
void MULTGRAPH::Init()
{
 int i,j,k;
 
 LOESUNG_ANZ=0;
 zaehler=0;
 is_first=1;
 dim_gr_0=0;
 edge_soll=0;
 if(max_val == 1)
  IS_REGULAR=1;
 for(i=1;i<=maxgrad;i++)
  {
   if((i < maxgrad)&&(partition[i] > 0))
    IS_REGULAR=0;
   dim_gr_0+=partition[i];
   edge_soll+=i*partition[i];
  }
 if(edge_soll % 2 != 0)
  {
   FatalMess("degree-sum isn't divisible by 2\n");
   exit(0); 
  }  
 edge_soll/=2;
 edge_anz=0;

 AUT.Init(dim);
 NBlist.REALLOC(dim,2*maxgrad+1);
 NBwert.REALLOC(dim,2*maxgrad+1);

 if(dim_gr_0 > 0)
  {
   K.REALLOC(dim_gr_0,dim_gr_0);
   for(i=1;i<=dim_gr_0;i++)
    K[i].Clear();
   platz_zei.ReAlloc(dim_gr_0*dim_gr_0);
   platz_sp.ReAlloc(dim_gr_0*dim_gr_0);
   platz_wert.ReAlloc(dim_gr_0*dim_gr_0);
   platz_wert.Used()=0;

   z_soll.ReAlloc(dim_gr_0);
   z_sum.ReAlloc(dim_gr_0);

   j=0;
   for(i=1;i<=maxgrad;i++)
    for(k=1;k<=partition[i];k++)
      z_soll[++j]=i;


   lambda_blocks.REALLOC(dim_gr_0,dim_gr_0);
   j=1;
   lambda_blocks[1].Used()=0;
   for(i=1;i<=maxgrad;i++)
    {
     if(partition[i] > 1)
      {
       lambda_blocks[1].Used()++;
       k=lambda_blocks[1].Used();
       lambda_blocks[1][(2*k)-1]=j;
       lambda_blocks[1][2*k]=j+partition[i]-1;
      }
     j+=partition[i];
    }

   z_sum.Clear();

   test_ind.ReAlloc(dim_gr_0);
   test_bis.ReAlloc(dim_gr_0);
   MinInds.SetAb0();
   MinInds.REALLOC(dim_gr_0,dim_gr_0);
   MinInds.REALLOC(max_val,max_val);
   if(inv_trans.Dim() > 0)
    inv_trans.FREE();
   inv_trans.ReAlloc(dim_gr_0);
   transpos_left.REALLOC(dim_gr_0,dim_gr_0);
   transpos_right.REALLOC(dim_gr_0,dim_gr_0);

   z_idx=1;
   sp_idx=1;

   if(IS_REGULAR || (girth > 3) ||
      ((ZSHG)&&(! IS_REGULAR)))
    {
     BV1.ReAlloc(dim_gr_0);
     BV.REALLOC(dim_gr_0,dim_gr_0);
     nblist.REALLOC(dim_gr_0,dim_gr_0);
     for(i=1;i<=dim_gr_0;i++)
      nblist[i].Used()=0;

     kr_anz.ReAlloc(edge_soll+2);
     kr_anz[1]=0;
     Zshg_vec.REALLOC(edge_soll+2,dim_gr_0);
     Zshg_vec[1].Clear();
     Zshg_vec[1].Set(1);
    }

   KAND_ANZ=0;
   last_comp_lambda=1;

   if(ENABLE_AUT)
    { 
     if(auts.Dim() > 0) 
      auts.FREE();
     auts.REALLOC(10,dim_gr_0);
     auts_trans_nr.ReAlloc(10);
    }
  }

 ONLY_CANDS = 0;
 z_p.ReAlloc(dim);
 z_p.Id();
 s_p.REALLOC(dim,dim);
 for(i=1;i<=dim;i++)
  {
   s_p[i].Used() = 0;
   for(j=i+1;j<=dim;j++)
    s_p[i][++s_p[i].Used()] = j;
  }

}


void MULTGRAPH::SetONLY_CANDS(PERMUT < short >& P)
{
 int i,j,k;

 z_p = P; 
 ONLY_CANDS=1; 
 s_p.REALLOC(dim,dim);
 
 for(i=1;i<dim;i++)
  {
   s_p[i].Used() = 0;
   for(j=i+1;j<=dim;j++)
    s_p[i][++s_p[i].Used()] = z_p[j];
   s_p[i].Sort();
  }
}



int MULTGRAPH::PartitionCheck(int z_m,int sp_m)
{
 int i;

 return(1);

 if(max_val > 1) 
  {
   for(i=z_idx;i<=dim_gr_0;i++)
    {
     if(z_soll[i]-z_sum[i] >= (dim_gr_0-z_idx+1)*max_val )
      {
       z_idx=z_m;
       sp_idx=sp_m;
       return(0);
      }
    }  
   return(1);
  }  
 a_GRAPH_PART.Init(dim_gr_0-z_idx+1,edge_soll-edge_anz,max_val);
 for(i=z_idx;i<=dim_gr_0;i++)
  {
   if(z_soll[i]-z_sum[i] >= dim_gr_0-z_idx+1)
    {
     z_idx=z_m;
     sp_idx=sp_m;
     return(0);
    }
   a_GRAPH_PART.GetVertAnz(z_soll[i]-z_sum[i])++;
  }
 if(! a_GRAPH_PART.IsGraphic())
  {
   z_idx=z_m;
   sp_idx=sp_m;
   return(0);
  }
 return(1);
}




inline int MULTGRAPH::NextInd()
{
 int z_m,sp_m;

 if((z_idx == dim_gr_0-1)&&(sp_idx == dim_gr_0))
   return(0);
 if((z_idx > 1)&&(z_soll[z_p[z_idx-1]] != z_sum[z_p[z_idx-1]]))
   return(0);

 z_m=z_idx;
 sp_m=sp_idx; 
 if((sp_idx==dim_gr_0)||(z_sum[z_p[z_idx]] == z_soll[z_p[z_idx]]))
  {
   z_idx++;
   sp_idx=z_idx+1;
   if(z_idx < dim_gr_0)
    {
     BerechneNextLambda(z_idx);
     last_comp_lambda=z_idx; 
    } 
  }
 else
  {
   sp_idx++;
   if(sp_idx > z_idx+1)
    {
     if( (dim_gr_0-z_idx)*max_val < 
         (z_soll[s_p[z_idx][sp_idx-1-z_idx]]-z_sum[s_p[z_idx][sp_idx-1-z_idx]])) 
      { z_idx = z_m; sp_idx = sp_m; return(0); }
    }
  }

 while(1)
  {
   if(z_soll[z_p[z_idx]] == z_sum[z_p[z_idx]])
    {
     if(z_idx == dim_gr_0-1)
      { z_idx = z_m; sp_idx = sp_m; return(0); }  
     z_idx++;
     sp_idx=z_idx+1;
     if(z_idx < dim_gr_0)
      {
       BerechneNextLambda(z_idx);
       last_comp_lambda=z_idx; 
      } 
    }   
   else
    {
     if((dim_gr_0-sp_idx+1)*max_val < z_soll[z_p[z_idx]]-z_sum[z_p[z_idx]])
      { z_idx=z_m; sp_idx=sp_m; return(0); }
     if(z_sum[s_p[z_idx][sp_idx-z_idx]] == z_soll[s_p[z_idx][sp_idx-z_idx]])
      {
       if(sp_idx < dim_gr_0)
        sp_idx++;
       else
	       { z_idx=z_m; sp_idx=sp_m; return(0); } 
      }
     return(1);
    }
  }
}






inline void MULTGRAPH::Del()
{
 int used=platz_wert.Used();
 int wert=platz_wert[platz_wert.Used()];

 platz_wert.Used()--;
 z_idx=platz_zei[used];
 sp_idx=platz_sp[used];
 
 z_sum[z_p[z_idx]]-=wert;
 z_sum[s_p[z_idx][sp_idx-z_idx]]-=wert;
 edge_anz-=wert;
 K[z_p[z_idx]][s_p[z_idx][sp_idx-z_idx]] =
  K[s_p[z_idx][sp_idx-z_idx]][z_p[z_idx]]=0;

 if(IS_REGULAR || (girth > 3) ||
    ((ZSHG)&&(! IS_REGULAR)))
  {
   nblist[z_p[z_idx]].Used()--;
   nblist[s_p[z_idx][sp_idx-z_idx]].Used()--;
  }
  
// printf("K[%d][%d] = 0\n",z_p[z_idx],s_p[z_idx][sp_idx-z_idx]);
}





int MULTGRAPH::Abstand(int a,int b)
{
 int i,j,k,ret;

 BV1.Clear();
 BV1.Set(a);
 BV[1].Used()=1;
 BV[1][1]=a;

 i=1;
 while(1)
  {
   if(BV[i].Used() == 0)
    return(-1);
   BV[i+1].Used()=0;
   for(j=1;j<=BV[i].Used();j++)
    {
     for(k=1;k<=nblist[BV[i][j]].Used();k++)
      {
       if(BV1[nblist[BV[i][j]][k]] == 0)
        {
         if(nblist[BV[i][j]][k] == b)
           return(i); 
         BV1.Set(nblist[BV[i][j]][k]);
         BV[i+1][++BV[i+1].Used()]=nblist[BV[i][j]][k];
        }
      }
    }
   i++;
  }
}




int MULTGRAPH::IsMaxAbstand(int a,int b,int l)
{
 int j,k,i,ret;

 BV1.Clear();
 BV1.Set(a);
 BV[1].Used()=1;
 BV[1][1]=a;
 i=1;
 while(i <= l)
  {
   BV[i+1].Used()=0;
   for(j=1;j<=BV[i].Used();j++)
    {
     for(k=1;k<=nblist[BV[i][j]].Used();k++)
      {
       if(BV1[nblist[BV[i][j]][k]] == 0)
        {
         if(nblist[BV[i][j]][k] == b)
           return(1); 
         BV1.Set(nblist[BV[i][j]][k]);
         BV[i+1][++BV[i+1].Used()]=nblist[BV[i][j]][k];
        }
      }
    }
   i++;
  }
 return(0);
} 




int MULTGRAPH::GirthCheck(int l)
{
 int i,j,k,m,min;

 if(ONLY_CANDS)return(1);

 i=1;
 j=2;
 m=0;
 while(1)
  {
   min=1000;
   for(k=1;k<=nblist[j].Used();k++)
    {
     if((nblist[j][k] < min)&&(nblist[j][k] != i))
      min=nblist[j][k];
    }
   if((z_idx==j)&&(sp_idx < min)&&(sp_idx != i))
    min=sp_idx;
   if((sp_idx==j)&&(z_idx < min)&&(sp_idx != i))
    min=z_idx;
   if(min==1000)return(0);
   if(min==3)m=1;
   if(min==1)
    {
     if(m==1)return(1);
     else return(0);
    }
   i=j;
   j=min;
  }
}




inline int MULTGRAPH::ZshgTest(int wert)
{
 if(ONLY_CANDS)return(1);


 if(IS_REGULAR && ZSHG && (Zshg_vec[platz_wert.Used()+1][z_idx] == 0))
   return(0);

 if(ZSHG && IS_REGULAR)
  {
   Zshg_vec[platz_wert.Used()+2]=Zshg_vec[platz_wert.Used()+1];
   Zshg_vec[platz_wert.Used()+2].Set(sp_idx);
  }

 if(ZSHG && (! IS_REGULAR))
  {
   //pruefe, ob Zusammenhangskomponenten, die noch
   //nicht gleich dem Gesamtgraphen sind, noch freie Bindungen 
   //besitzen

   int i,j,k; 
   BITVEK bits;
   bits.Init(dim);
   bits.Clear();
   bits.Set(z_idx);
   bits.Set(sp_idx);

   VEKTOR < short > keller;
   keller.Init(dim);
   keller.Used() = 2;
   keller[1] = z_idx;
   keller[2] = sp_idx;
   i = 2;
   while(keller.Used() > 0)
    {
     j = keller[keller.Used()--];
     for(k = 1;k<=nblist[j].Used();k++)
      if(bits[nblist[j][k]] == 0)
       {
        i++;
        bits.Set(nblist[j][k]);
        keller[++keller.Used()] = nblist[j][k];
       }  
    }
   if(i < dim)
    { 
     //pruefe, ob es noch Bindungen nach aussen gibt
     k = 0;
     for(j = 1;j <= dim;j++)
      {
       if(bits[j] == 1)
        {
         if((j==z_idx)||(j==sp_idx))
          {
           if(z_soll[j] > z_sum[j]+wert)
            {
             k = 1;
             break; 
            }
          }
         else
          { 
           if(z_soll[j] > z_sum[j])
            {
             k = 1;
             break; 
            }
          }  
        }  
      }
     if(k==0)
      return(0); 
    }
  }

 return(1);
} 



inline int MULTGRAPH::RingTest()
{
 int i,j;

 if(ONLY_CANDS)
  {
   j=girth-2;
   i=IsMaxAbstand(z_p[z_idx],s_p[z_idx][sp_idx-z_idx],j);
   if(i == 1)
     return(0);
   else
     return(1);
  }

 if(IS_REGULAR || (girth > 3))
  {
   if(kr_anz[platz_wert.Used()+1] == 0)
    {
     i=Abstand(z_idx,sp_idx);

     // => Kreis der Laenge i+1
     if(i != -1)
      {
       if(i+1 < girth)
        return(0);
       if(IS_REGULAR && (max_val == 1) && !GirthCheck(i+1))
        return(0);
       kr_anz[platz_wert.Used()+2]=1;
       eins_kr_l=i+1;      
      } 
     else
      kr_anz[platz_wert.Used()+2]=0;
    }
   else
    { 
     if(IS_REGULAR)
      j=eins_kr_l-2;
     else
      j=girth-2;
     kr_anz[platz_wert.Used()+2]=kr_anz[platz_wert.Used()+1];
     i=IsMaxAbstand(z_idx,sp_idx,j);
     
     if(i == 1)
      return(0); 
    }
  }
 return(1);
}





inline int MULTGRAPH::Lambda(int i,int j)
{
 for(int k=1;k<=lambda_blocks[i].Used();k++)
  {
   if(lambda_blocks[i][2*k-1] <= s_p[i][j-i])
    {
     if(lambda_blocks[i][2*k] >= s_p[i][j-i])
      return(k);
    }
   else
    return(-1);
  }
 return(-1);
}


void MULTGRAPH::BerechneNextLambda(int zeile)
{
 int i,k,r,_l,l,m;

 lambda_blocks[zeile].Used()=0;
 for(i=1;i<=lambda_blocks[zeile-1].Used();i++)
  {
   l=lambda_blocks[zeile-1][(2*i)-1];
   if(l < s_p[zeile-1][1])l=s_p[zeile-1][1];
   r=lambda_blocks[zeile-1][2*i];
   if(r > s_p[zeile-1][s_p[zeile-1].Used()])r=s_p[zeile-1][s_p[zeile-1].Used()];
   _l = l;
   //der Block geht von l bis r. _l laeuft von
   //l bis r.
   while(_l <= r)
    {
     k = _l;
     //_l merken
     while((_l < r)&&(K[z_p[zeile-1]][_l] == K[z_p[zeile-1]][_l+1]))
      _l++;
     //Von k bis _l sind gleiche Eintraege
     if(_l-k+1 > 1)
      {
       lambda_blocks[zeile].Used()++;
       m=lambda_blocks[zeile].Used();
       //in s_p[zeile] ist z_p[zeile] nicht mehr dabei.
       //wir nehmen an, dass es entweder hinten oder vorne weggenommen 
       //wurde.
       lambda_blocks[zeile][2*m-1] = k;
       lambda_blocks[zeile][2*m] = _l;
      }
     _l++; 
    }
  }
/*
 printf("lambda[%d] = ",zeile);
 for(i=1;i<=2*lambda_blocks[zeile].Used();i++)
  printf("%d ",lambda_blocks[zeile][i]);
 printf("\n");
 */

}



inline int MULTGRAPH::IsErlaubt(int wert)
{

 if((z_idx > 1)&&(z_sum[z_p[z_idx-1]] != z_soll[z_p[z_idx-1]]))
  return(-1);
  
 if(z_sum[z_p[z_idx]]+wert > z_soll[z_p[z_idx]])
   return(0);
 if(z_sum[s_p[z_idx][sp_idx-z_idx]]+wert > z_soll[s_p[z_idx][sp_idx-z_idx]])
   return(0);

 int i,j;

// printf("IsErlaubt mit z_idx=%d sp_idx=%d\n",z_idx,sp_idx);

 i=Lambda(z_idx,sp_idx);
 if((i != -1)&&(sp_idx > z_idx+1))
  {
   j=Lambda(z_idx,sp_idx-1);
   if((i == j)&&(K[z_p[z_idx]][s_p[z_idx][sp_idx-1-z_idx]] < wert))
    return(0);
  }
 if(! ZshgTest(wert))
  return(0);

 if(! RingTest())
  return(0);

 platz_wert[++platz_wert.Used()]=wert;
 edge_anz+=wert;
 platz_zei[platz_wert.Used()]=z_idx;
 platz_sp[platz_wert.Used()]=sp_idx;
 z_sum[z_p[z_idx]]+=wert;
 z_sum[s_p[z_idx][sp_idx-z_idx]]+=wert;
 K[z_p[z_idx]][s_p[z_idx][sp_idx-z_idx]] =
  K[s_p[z_idx][sp_idx-z_idx]][z_p[z_idx]] = wert;

// printf("K[%d][%d] = 1\n",z_p[z_idx],s_p[z_idx][sp_idx-z_idx]);

 if(IS_REGULAR || (girth > 3) ||
    ((ZSHG)&&(! IS_REGULAR)))
  {
   nblist[z_p[z_idx]][++nblist[z_p[z_idx]].Used()]=s_p[z_idx][sp_idx-z_idx];
   nblist[s_p[z_idx][sp_idx-z_idx]][++nblist[s_p[z_idx][sp_idx-z_idx]].Used()]=z_p[z_idx];
  }

 if(edge_anz == edge_soll)
  return(2);
 else
  return(1);
}


inline void MULTGRAPH::MalTranspos(int li,int re)
{
 inv_trans.swap(li,re);
}




void MULTGRAPH::BerechneZURUECK(int tiefe,int min_gr)
{
 int i,j,k,l;

 ZURUECK_Z=inv_trans[tiefe];
 ZURUECK_SP=inv_trans[min_gr];
 if(ZURUECK_Z > ZURUECK_SP)
  {
   i=ZURUECK_Z;
   ZURUECK_Z=ZURUECK_SP;
   ZURUECK_SP=i;
  }

 if((platz_zei[1] < tiefe)||
    ((platz_zei[1]==tiefe)&&(platz_sp[1] < min_gr)))
  l=1;
 else
  l=0;
 k=1;
 while(l)
  {
   if(inv_trans[platz_zei[k]] < inv_trans[platz_sp[k]])
    {
     i=inv_trans[platz_zei[k]];
     j=inv_trans[platz_sp[k]];
    }
   else
    {
     j=inv_trans[platz_zei[k]];
     i=inv_trans[platz_sp[k]];
    } 
   if((i>ZURUECK_Z)||((i == ZURUECK_Z)&&(j>ZURUECK_SP)))
    {
     ZURUECK_Z=i;
     ZURUECK_SP=j;
    } 
   k++;
   if((platz_zei[k] < tiefe)||
      ((platz_zei[k]==tiefe)&&(platz_sp[k] < min_gr)))
    l=1;
   else
    l=0;
  }

 i=platz_zei[k];
 j=platz_sp[k]; 
 if((i>ZURUECK_Z)||((i == ZURUECK_Z)&&(j>ZURUECK_SP)))
  {
   ZURUECK_Z=i;
   ZURUECK_SP=j;
  } 

}





int MULTGRAPH::MinTest()
{
 KAND_ANZ++;

 int io,jo,ko,i,j,k,l,_j,_k;
 int tiefe=1;
 int transv_nr=1000;

 for(i=last_comp_lambda+1;i <= dim_gr_0-1;i++)
  BerechneNextLambda(i);

 auts.Used()=0;
 inv_trans.Id();
 test_ind[1]=0;

 for(i=1;i<=dim_gr_0;i++)
  {
   if(lambda_blocks[i].Used() == 0)
    test_bis[i]=i;
   else
    {
     if(lambda_blocks[i][1] == i)
      test_bis[i]=lambda_blocks[i][2];
     else
      test_bis[i]=i;
    }
  }      

 DOWN:
  test_ind[tiefe]++;
  
  transpos_left[tiefe].Used()=0;
  if(test_ind[tiefe] <= test_bis[tiefe])
   {
    if((tiefe < transv_nr)&&(test_ind[tiefe] != tiefe))
     transv_nr = tiefe;
    if(test_ind[tiefe] != tiefe)    
     MalTranspos(tiefe,test_ind[tiefe]);

    i=tiefe+1;
    k=1;
    while(i <= dim_gr_0)
     {   
      if((k > lambda_blocks[tiefe].Used())||
	 (i < lambda_blocks[tiefe][2*k-1]))
       {
	//d.h. Block der Laenge 1
	if(K[inv_trans[tiefe]][inv_trans[i]] > K[tiefe][i])
	 {
	  BerechneZURUECK(tiefe,i);
	  return(0);
	 }   
	if(K[inv_trans[tiefe]][inv_trans[i]] < K[tiefe][i])
	  goto NEXT;
	i++;
       } 
      else
       {
	//d.h. Block > 1 gefunden
	if(max_val > 1)
	 {
	  for(j=0;j<=max_val;j++)
	    MinInds[j].Used() = 0;
	  for(j = i;j <= lambda_blocks[tiefe][2*k];j++)
	   {
	    io = K[inv_trans[tiefe]][inv_trans[j]];
	    MinInds[io][++MinInds[io].Used()] = inv_trans[j]; 
	   }  
	  for(j=i;j<=lambda_blocks[tiefe][2*k];j++)
	   {
	    io = K[tiefe][j];
	    //nachschauen, ob noch ein groesserer Wert frei ist
	    for(jo = io+1;jo <= max_val;jo++)
	     {
	      if(MinInds[jo].Used() > 0)
	       {
		if(MinInds[jo][1] != j)
		 {
		  transpos_left[tiefe].Used()++;
		  l = transpos_left[tiefe].Used();
		  transpos_left[tiefe][l] = j;
		  _j = 1;
		  while(inv_trans[_j] != MinInds[jo][1])
		   _j++;
		  transpos_right[tiefe][l] = _j;
		  MalTranspos(j,_j);
		 }   
		BerechneZURUECK(tiefe,j);
		return(0); 
	       }
	     }
	    //es ist also kein groesserer Wert mehr frei
	    if(MinInds[io].Used() == 0)
	     goto NEXT;
	    if(K[inv_trans[tiefe]][inv_trans[j]] == io)
             {
              //inv_trans[j] aus MinInds streichen
              jo = 1;
              while(MinInds[io][jo] != inv_trans[j])
               jo++;
              MinInds[io][jo] = MinInds[io][MinInds[io].Used()--]; 
             }
            else
             {
              _j = 1;
              while( MinInds[io][1] != inv_trans[_j])
               _j++;
	      transpos_left[tiefe].Used()++;
	      l = transpos_left[tiefe].Used();
	      transpos_left[tiefe][l] = j;
              transpos_right[tiefe][l] = _j;
              MalTranspos(j,_j);
              //MinInds[io][1] streichen 
              MinInds[io][1] = MinInds[io][MinInds[io].Used()--];
             }  
	   }
         }
        else
         {  
	  j=lambda_blocks[tiefe][2*k];
	  while(i <= j)
	   { 
	    if(K[inv_trans[tiefe]][inv_trans[i]]==1)
	     {
	      if(K[tiefe][i]==0)
	       {
		BerechneZURUECK(tiefe,i);
		return(0);
	       }
	      i++;
	     }
	    else
	     {
	      if(K[inv_trans[tiefe]][inv_trans[j]]==0)
	       {
		if(K[tiefe][j]==1)
		 goto NEXT;
		j--;
	       }
	      else
	       {
		transpos_left[tiefe].Used()++;
		l=transpos_left[tiefe].Used();
		transpos_left[tiefe][l]=i;
		transpos_right[tiefe][l]=j;
		MalTranspos(i,j);
		if(K[tiefe][i]==0)
		 {
		  BerechneZURUECK(tiefe,i);
		  return(0);
		 }
		if(K[tiefe][j]==1)
		 goto NEXT;
		i++;
		j--;
	       }
	     }
	   }
         }
	i=lambda_blocks[tiefe][2*k]+1;
	k++;
       }      
     } 

    //row tiefe is equal
    if(tiefe == dim_gr_0-1)
     {
      if(transv_nr < 1000)
       goto AUTO;
      else
       goto DOWN;
     } 
    tiefe++;
    test_ind[tiefe]=tiefe-1;
    goto DOWN;
   }
  else
    goto UP;
   
 NEXT:
  i=tiefe;   
  for(j=transpos_left[i].Used();j >= 1; j--)
    MalTranspos(transpos_left[i][j],transpos_right[i][j]);
  if((test_ind[i] != i)&&(test_ind[tiefe] <= dim_gr_0)) 
    MalTranspos(i,test_ind[i]);
  goto DOWN;

 UP:
  //go one step up
  tiefe--;   
  if(tiefe == 0)
   {
    return(1);  
   }
   
  i=tiefe;   
  for(j=transpos_left[i].Used();j >= 1; j--)
    MalTranspos(transpos_left[i][j],transpos_right[i][j]);
  if((test_ind[i] != i)&&(test_ind[tiefe] <= dim_gr_0)) 
    MalTranspos(i,test_ind[i]);
  goto DOWN;

 AUTO:
  //automorphism found
  if(transv_nr < 1000)
   {
    if(ENABLE_AUT)
     {
      auts.Used()++;
      auts.REALLOC(auts.Used(),dim_gr_0);
      auts[auts.Used()]=inv_trans;
      auts_trans_nr.ReAlloc(auts.Used());
      auts_trans_nr[auts.Used()]=transv_nr;  
     }

    //go up until depth transv_nr              
    for(i=dim_gr_0-1;i >= transv_nr; i--)
     {
      for(j=transpos_left[i].Used();j >= 1; j--)
       MalTranspos(transpos_left[i][j],transpos_right[i][j]);
      if(test_ind[i] != i)
       MalTranspos(i,test_ind[i]);
     }
    tiefe = transv_nr;
    goto DOWN;            
   }
  else
   goto UP;    

}




void MULTGRAPH::BerechneAut()
{
 int i,j,k,l;


 for(i=1;i<=dim;i++)
  {
   AUT.pi(i)=i;
   AUT.HV(i)=i;
  }
 for(i=1;i<=auts.Used();i++)
  {
   j=auts[i][auts_trans_nr[i]];  
   if(AUT.HV(j) == j)  
    {
     AUT.HV(j) = auts_trans_nr[i];
     for(k=1;k<=dim_gr_0;k++)
      AUT.KM(j)[k]=auts[i][k];
     for(k=dim_gr_0+1;k<=dim;k++)
      AUT.KM(j)[k]=k;
    }
  }

 //append S(dim-dim_gr_0) at the end of AUT
 for(i=dim_gr_0+2;i<=dim;i++)
  {
   AUT.HV(i)=i-1;
   AUT.KM(i).Id();
   AUT.KM(i)[i]=i-1;
   AUT.KM(i)[i-1]=i;
  } 
 AUT_IS_ID=1;
 for(i=1;i<=dim;i++)
  if(AUT.HV(i) != i)
   { 
    AUT_IS_ID=0;
    break;
   }
 if(AUT_IS_ID == 0)
  AUT.update_eckenmarken();
}





int MULTGRAPH::NextRep()
{
 int i,j,y,ret;
 clock_t t1,t2;

 if(ZSHG && (dim_gr_0 < dim) && (dim > 1))
  return(0);


 if(dim_gr_0 == 0)
  {
   if(is_first)
    {
     AUT.SetSym();
     if(dim > 1)
      AUT_IS_ID=0;
     else 
      AUT_IS_ID=1;
     is_first=0;
     NotiereNBlist();  
     return(1);
    }
   else
    return(0);
  }

 if(is_first)
  goto VOR;

 RUECK:
  if(platz_wert.Used() == 0)
    return(0);
  j=platz_wert[platz_wert.Used()];
  Del();
  for(i=j-1;i>=1;i--)
   {
    if(IsErlaubt(i))
     goto VOR;
   }

 VOR:
  if(NextInd() == 0)
   goto RUECK;
  j=max_val;
  if(z_soll[z_p[z_idx]] - z_sum[z_p[z_idx]] < j)
   j=z_soll[z_p[z_idx]] - z_sum[z_p[z_idx]];
  if(z_soll[s_p[z_idx][sp_idx-z_idx]] - z_sum[s_p[z_idx][sp_idx-z_idx]] < j)
   j=z_soll[s_p[z_idx][sp_idx-z_idx]] - z_sum[s_p[z_idx][sp_idx-z_idx]];
  for(i=j;i>=1;i--)
   {
    if((ret=IsErlaubt(i)))
     {
      if(ret==2)
       {
        int minret;
        if(ONLY_CANDS==0)
         minret = MinTest();
        else
         minret = 1;
        if(minret)
         {
          is_first=0;
          if((ENABLE_AUT)&&(ONLY_CANDS==0))
           BerechneAut();  
          NotiereNBlist();  
          return(1);
         }
        else
          goto LERNE;
       }
      if(ret==1)
       goto VOR; 
      if(ret == -1)
       goto RUECK;      
     }
   }
  goto VOR;

 LERNE:
  y = 0;
  while((platz_zei[platz_wert.Used()] > ZURUECK_Z)||
        ((platz_zei[platz_wert.Used()] == ZURUECK_Z)&&
         (platz_sp[platz_wert.Used()] > ZURUECK_SP)))
   {
    if(platz_wert.Used() == 0)
      return(0);
    Del();
    y++;
   }
   
  if(y == 0)Del();
  goto VOR;

}




void MULTGRAPH::PrintLoesung()
{
 int i,j;

 for(i=1;i<=dim_gr_0;i++)
  {
   for(j=1;j<=dim_gr_0;j++)
    printf("%d ",K[i][j]);
   printf("\n");
  }

 printf("\n");
 printf("\n");
}




int MULTGRAPH::GetZ_SP_SUM(int i)
{
 #ifdef DEBUG_TG
  if((i < 1)||(i > dim))
   {
    FatalMess("Wrong parameter i in MULTGRAPH::GetSp_Z_SUM\n");
    exit(0);
   }
 #endif

 if(i > dim_gr_0)
  return(0);

 return(z_soll[i]);
}



int MULTGRAPH::GetErg(int i,int j)
{
 #ifdef DEBUG_TG
  if(((i < 1)||(i > dim))||((j < 1)||(j > dim)))
   {
    FatalMess("wrong parameters in MULTGRAPH::GetErg\n");
    exit(0);
   }
 #endif

 if((i > dim_gr_0)||(j > dim_gr_0))
  return(0);

 return(K[i][j]);
}



void MULTGRAPH::NotiereNBlist()
{
 int i,j;

 NBlist.Used()=dim;
 NBwert.Used()=dim;
 for(i=1;i<=dim;i++)
  {
   NBlist[i].Used()=0;
   NBwert[i].Used()=0;
   for(j=i+1;j<=dim;j++)
    {
     if(GetErg(i,j) > 0)
      {
       NBlist[i][++NBlist[i].Used()] = j;
       NBwert[i][++NBwert[i].Used()] = GetErg(i,j);
      } 
    }  
  }
}




void MULTGRAPH::FREE()
{
 partition.FREE();
 AUT.FREE();
 BV1.FREE();
 BV.FREE();
 nblist.FREE();
 kr_anz.FREE();
 Zshg_vec.FREE();
 K.FREE();
 platz_zei.FREE();
 platz_sp.FREE();
 platz_wert.FREE();
 z_soll.FREE();
 z_sum.FREE();
 lambda_blocks.FREE();
 test_ind.FREE();
 test_bis.FREE();
 inv_trans.FREE();
 transpos_left.FREE();
 transpos_right.FREE();
 auts.FREE();
 auts_trans_nr.FREE();
}





